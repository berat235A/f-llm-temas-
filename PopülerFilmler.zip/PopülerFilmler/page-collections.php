<?php
/**
 * Koleksiyonlar ana sayfası template
 */

get_header(); ?>

<div class="CollectionsPage">
    <div class="Container">
        <!-- Hero Section -->
        <div class="CollectionsHero">
            <div class="HeroContent">
                <h1 class="HeroTitle"><?php _e('Koleksiyonlar', 'torofilm'); ?></h1>
                <p class="HeroSubtitle"><?php _e('En sevdiğiniz filmleri ve dizileri keşfedin', 'torofilm'); ?></p>
                
                <div class="HeroSearch">
                    <form role="search" method="get" action="<?php echo home_url('/'); ?>">
                        <div class="SearchBox">
                            <input type="search" placeholder="<?php _e('Koleksiyon ara...', 'torofilm'); ?>" value="<?php echo get_search_query(); ?>" name="s" />
                            <input type="hidden" name="post_type" value="collections" />
                            <button type="submit" class="SearchBtn">
                                <i class="fa fa-search"></i>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
            <div class="HeroBackground">
                <div class="HeroOverlay"></div>
            </div>
        </div>

        <!-- Featured Collections -->
        <?php
        $featured_collections = TOROFILM_Collections::get_featured_collections(6);
        
        if (!empty($featured_collections)) :
        ?>
        <section class="FeaturedSection">
            <div class="SectionHeader">
                <h2 class="SectionTitle">
                    <i class="fa fa-star"></i>
                    <?php _e('Öne Çıkan Koleksiyonlar', 'torofilm'); ?>
                </h2>
                <p class="SectionSubtitle"><?php _e('En popüler ve özel koleksiyonlarımız', 'torofilm'); ?></p>
            </div>
            
            <div class="FeaturedGrid">
                <?php foreach ($featured_collections as $index => $collection) : ?>
                <div class="FeaturedCard <?php echo $index == 0 ? 'Large' : ''; ?>">
                    <div class="CardImage">
                        <a href="<?php echo get_permalink($collection->ID); ?>">
                            <?php if (has_post_thumbnail($collection->ID)) : ?>
                                <?php echo get_the_post_thumbnail($collection->ID, $index == 0 ? 'large' : 'medium'); ?>
                            <?php else : ?>
                                <img src="<?php echo TOROFILM_DIR_URI . 'public/img/cnt/dvr300.png'; ?>" alt="<?php echo get_the_title($collection->ID); ?>" />
                            <?php endif; ?>
                            
                            <div class="CardOverlay">
                                <div class="PlayButton">
                                    <i class="fa fa-play"></i>
                                </div>
                            </div>
                            
                            <div class="CardBadge">
                                <i class="fa fa-star"></i>
                                <?php _e('Öne Çıkan', 'torofilm'); ?>
                            </div>
                        </a>
                    </div>
                    
                    <div class="CardContent">
                        <h3 class="CardTitle">
                            <a href="<?php echo get_permalink($collection->ID); ?>">
                                <?php echo get_the_title($collection->ID); ?>
                            </a>
                        </h3>
                        
                        <div class="CardMeta">
                            <span class="MetaItem">
                                <i class="fa fa-film"></i>
                                <?php 
                                $items = get_post_meta($collection->ID, '_collection_items', true);
                                $count = is_array($items) ? count($items) : 0;
                                echo $count . ' ' . ($count == 1 ? __('İçerik', 'torofilm') : __('İçerik', 'torofilm'));
                                ?>
                            </span>
                            
                            <span class="MetaItem">
                                <i class="fa fa-calendar"></i>
                                <?php echo get_the_date('d.m.Y', $collection->ID); ?>
                            </span>
                        </div>
                        
                        <div class="CardDescription">
                            <p><?php echo wp_trim_words(get_the_excerpt($collection->ID), 20); ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </section>
        <?php endif; ?>

        <!-- All Collections -->
        <section class="AllCollectionsSection">
            <div class="SectionHeader">
                <h2 class="SectionTitle">
                    <i class="fa fa-th-large"></i>
                    <?php _e('Tüm Koleksiyonlar', 'torofilm'); ?>
                </h2>
                
                <div class="SectionFilters">
                    <div class="FilterTabs">
                        <button class="FilterTab active" data-filter="all"><?php _e('Tümü', 'torofilm'); ?></button>
                        <button class="FilterTab" data-filter="featured"><?php _e('Öne Çıkan', 'torofilm'); ?></button>
                        <button class="FilterTab" data-filter="movies"><?php _e('Filmler', 'torofilm'); ?></button>
                        <button class="FilterTab" data-filter="series"><?php _e('Diziler', 'torofilm'); ?></button>
                    </div>
                    
                    <div class="SortOptions">
                        <select class="SortSelect">
                            <option value="date_desc"><?php _e('En Yeni', 'torofilm'); ?></option>
                            <option value="date_asc"><?php _e('En Eski', 'torofilm'); ?></option>
                            <option value="title_asc"><?php _e('A-Z', 'torofilm'); ?></option>
                            <option value="title_desc"><?php _e('Z-A', 'torofilm'); ?></option>
                            <option value="items_desc"><?php _e('En Çok İçerik', 'torofilm'); ?></option>
                        </select>
                    </div>
                </div>
            </div>
            
            <div class="CollectionsGrid" id="collections-grid">
                <?php
                $args = array(
                    'post_type' => 'collections',
                    'posts_per_page' => 12,
                    'post_status' => 'publish',
                    'paged' => get_query_var('paged') ? get_query_var('paged') : 1
                );
                
                $collections_query = new WP_Query($args);
                
                if ($collections_query->have_posts()) :
                    while ($collections_query->have_posts()) : $collections_query->the_post();
                        $collection_type = get_post_meta(get_the_ID(), '_collection_type', true);
                        $is_featured = get_post_meta(get_the_ID(), '_collection_featured', true);
                        $items = get_post_meta(get_the_ID(), '_collection_items', true);
                        $item_count = is_array($items) ? count($items) : 0;
                ?>
                <div class="CollectionCard" 
                     data-type="<?php echo $collection_type ?: 'mixed'; ?>"
                     data-featured="<?php echo $is_featured ? '1' : '0'; ?>"
                     data-items="<?php echo $item_count; ?>"
                     data-date="<?php echo get_the_date('Y-m-d'); ?>"
                     data-title="<?php echo get_the_title(); ?>">
                    
                    <div class="CardImage">
                        <a href="<?php the_permalink(); ?>">
                            <?php if (has_post_thumbnail()) : ?>
                                <?php the_post_thumbnail('medium'); ?>
                            <?php else : ?>
                                <img src="<?php echo TOROFILM_DIR_URI . 'public/img/cnt/dvr300.png'; ?>" alt="<?php the_title(); ?>" />
                            <?php endif; ?>
                            
                            <div class="CardOverlay">
                                <div class="PlayButton">
                                    <i class="fa fa-play"></i>
                                </div>
                            </div>
                            
                            <?php if ($is_featured) : ?>
                            <div class="CardBadge">
                                <i class="fa fa-star"></i>
                                <?php _e('Öne Çıkan', 'torofilm'); ?>
                            </div>
                            <?php endif; ?>
                        </a>
                    </div>
                    
                    <div class="CardContent">
                        <h3 class="CardTitle">
                            <a href="<?php the_permalink(); ?>">
                                <?php the_title(); ?>
                            </a>
                        </h3>
                        
                        <div class="CardMeta">
                            <span class="MetaItem">
                                <i class="fa fa-film"></i>
                                <?php echo $item_count . ' ' . ($item_count == 1 ? __('İçerik', 'torofilm') : __('İçerik', 'torofilm')); ?>
                            </span>
                            
                            <span class="MetaItem">
                                <i class="fa fa-calendar"></i>
                                <?php echo get_the_date('d.m.Y'); ?>
                            </span>
                            
                            <?php if ($collection_type && $collection_type != 'mixed') : ?>
                            <span class="MetaItem">
                                <i class="fa fa-tag"></i>
                                <?php echo $collection_type == 'movies' ? __('Filmler', 'torofilm') : __('Diziler', 'torofilm'); ?>
                            </span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="CardDescription">
                            <p><?php echo wp_trim_words(get_the_excerpt(), 15); ?></p>
                        </div>
                    </div>
                </div>
                <?php 
                    endwhile;
                    wp_reset_postdata();
                else :
                ?>
                <div class="NoCollections">
                    <div class="NoCollectionsIcon">
                        <i class="fa fa-folder-open"></i>
                    </div>
                    <h3><?php _e('Henüz koleksiyon bulunmuyor', 'torofilm'); ?></h3>
                    <p><?php _e('Yakında harika koleksiyonlar eklenecek!', 'torofilm'); ?></p>
                </div>
                <?php endif; ?>
            </div>
            
            <?php if ($collections_query->max_num_pages > 1) : ?>
            <div class="Pagination">
                <?php
                echo paginate_links(array(
                    'total' => $collections_query->max_num_pages,
                    'current' => max(1, get_query_var('paged')),
                    'prev_text' => '<i class="fa fa-chevron-left"></i> ' . __('Önceki', 'torofilm'),
                    'next_text' => __('Sonraki', 'torofilm') . ' <i class="fa fa-chevron-right"></i>',
                    'type' => 'list'
                ));
                ?>
            </div>
            <?php endif; ?>
        </section>
    </div>
</div>

<style>
.CollectionsPage {
    min-height: 100vh;
    background: var(--body);
    color: var(--text);
}

/* Hero Section */
.CollectionsHero {
    position: relative;
    height: 60vh;
    min-height: 500px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, var(--gray) 0%, var(--gray-light) 100%);
    overflow: hidden;
    margin-bottom: 60px;
}

.HeroContent {
    text-align: center;
    z-index: 2;
    position: relative;
    max-width: 800px;
    margin: 0 auto;
    padding: 0 20px;
}

.HeroTitle {
    font-size: 3.5rem;
    font-weight: 700;
    margin-bottom: 20px;
    background: linear-gradient(45deg, var(--primary), var(--secondary));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.HeroSubtitle {
    font-size: 1.2rem;
    color: var(--light-7);
    margin-bottom: 40px;
    line-height: 1.6;
}

.HeroSearch {
    max-width: 500px;
    margin: 0 auto;
}

.SearchBox {
    display: flex;
    background: rgba(255, 255, 255, 0.1);
    border-radius: 50px;
    padding: 5px;
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.2);
}

.SearchBox input[type="search"] {
    flex: 1;
    padding: 15px 20px;
    background: transparent;
    border: none;
    color: var(--text);
    font-size: 1rem;
    outline: none;
}

.SearchBox input[type="search"]::placeholder {
    color: var(--light-7);
}

.SearchBtn {
    padding: 15px 25px;
    background: var(--primary);
    color: var(--text);
    border: none;
    border-radius: 50px;
    cursor: pointer;
    transition: all 0.3s ease;
    font-size: 1rem;
}

.SearchBtn:hover {
    background: var(--secondary);
    transform: scale(1.05);
}

.HeroBackground {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: url('<?php echo TOROFILM_DIR_URI . 'public/img/cnt/dvr300.png'; ?>') center/cover;
    opacity: 0.1;
}

.HeroOverlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(45deg, rgba(3, 193, 239, 0.1), rgba(140, 53, 150, 0.1));
}

/* Section Styles */
.FeaturedSection,
.AllCollectionsSection {
    margin-bottom: 80px;
}

.SectionHeader {
    text-align: center;
    margin-bottom: 50px;
}

.SectionTitle {
    font-size: 2.5rem;
    font-weight: 600;
    margin-bottom: 15px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 15px;
}

.SectionTitle i {
    color: var(--primary);
}

.SectionSubtitle {
    font-size: 1.1rem;
    color: var(--light-7);
    max-width: 600px;
    margin: 0 auto;
}

/* Featured Grid */
.FeaturedGrid {
    display: grid;
    grid-template-columns: 2fr 1fr 1fr;
    grid-template-rows: 1fr 1fr;
    gap: 20px;
    height: 500px;
}

.FeaturedCard.Large {
    grid-row: 1 / 3;
}

.FeaturedCard {
    position: relative;
    border-radius: 15px;
    overflow: hidden;
    background: var(--gray);
    transition: all 0.3s ease;
    cursor: pointer;
}

.FeaturedCard:hover {
    transform: translateY(-5px);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
}

.CardImage {
    position: relative;
    height: 100%;
    overflow: hidden;
}

.CardImage img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.3s ease;
}

.FeaturedCard:hover .CardImage img {
    transform: scale(1.1);
}

.CardOverlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(to bottom, transparent 0%, rgba(0, 0, 0, 0.7) 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.FeaturedCard:hover .CardOverlay {
    opacity: 1;
}

.PlayButton {
    width: 60px;
    height: 60px;
    background: var(--primary);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    color: var(--text);
    transition: all 0.3s ease;
}

.PlayButton:hover {
    background: var(--secondary);
    transform: scale(1.1);
}

.CardBadge {
    position: absolute;
    top: 15px;
    right: 15px;
    background: rgba(255, 215, 0, 0.9);
    color: var(--dark);
    padding: 5px 10px;
    border-radius: 20px;
    font-size: 0.8rem;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 5px;
}

.CardContent {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    padding: 20px;
    background: linear-gradient(to top, rgba(0, 0, 0, 0.9), transparent);
}

.CardTitle {
    font-size: 1.2rem;
    font-weight: 600;
    margin-bottom: 10px;
}

.CardTitle a {
    color: var(--text);
    text-decoration: none;
    transition: color 0.3s ease;
}

.CardTitle a:hover {
    color: var(--primary);
}

.CardMeta {
    display: flex;
    gap: 15px;
    margin-bottom: 10px;
    flex-wrap: wrap;
}

.MetaItem {
    display: flex;
    align-items: center;
    gap: 5px;
    font-size: 0.9rem;
    color: var(--light-7);
}

.MetaItem i {
    font-size: 0.8rem;
    color: var(--primary);
}

.CardDescription {
    font-size: 0.9rem;
    color: var(--light-7);
    line-height: 1.4;
}

.CardDescription p {
    margin: 0;
}

/* Filters */
.SectionFilters {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 40px;
    flex-wrap: wrap;
    gap: 20px;
}

.FilterTabs {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.FilterTab {
    padding: 10px 20px;
    background: var(--gray);
    color: var(--text);
    border: 1px solid var(--gray-light);
    border-radius: 25px;
    cursor: pointer;
    transition: all 0.3s ease;
    font-size: 0.9rem;
}

.FilterTab:hover,
.FilterTab.active {
    background: var(--primary);
    border-color: var(--primary);
    color: var(--text);
}

.SortOptions {
    display: flex;
    align-items: center;
    gap: 10px;
}

.SortSelect {
    padding: 10px 15px;
    background: var(--gray);
    color: var(--text);
    border: 1px solid var(--gray-light);
    border-radius: 8px;
    cursor: pointer;
    outline: none;
}

/* Collections Grid */
.CollectionsGrid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
    gap: 30px;
    margin-bottom: 50px;
}

.CollectionCard {
    background: var(--gray);
    border-radius: 15px;
    overflow: hidden;
    transition: all 0.3s ease;
    cursor: pointer;
    border: 1px solid var(--gray-light);
}

.CollectionCard:hover {
    transform: translateY(-5px);
    box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2);
    border-color: var(--primary);
}

.CollectionCard .CardImage {
    height: 200px;
}

.CollectionCard .CardContent {
    position: relative;
    padding: 20px;
    background: var(--gray);
}

/* No Collections */
.NoCollections {
    grid-column: 1 / -1;
    text-align: center;
    padding: 80px 20px;
    color: var(--light-7);
}

.NoCollectionsIcon {
    font-size: 4rem;
    margin-bottom: 20px;
    color: var(--tertiary);
}

.NoCollections h3 {
    font-size: 1.5rem;
    margin-bottom: 10px;
    color: var(--text);
}

/* Pagination */
.Pagination {
    text-align: center;
    margin-top: 50px;
}

.Pagination .page-numbers {
    display: inline-block;
    padding: 12px 18px;
    margin: 0 5px;
    background: var(--gray);
    color: var(--text);
    text-decoration: none;
    border-radius: 8px;
    transition: all 0.3s ease;
    border: 1px solid var(--gray-light);
}

.Pagination .page-numbers:hover,
.Pagination .page-numbers.current {
    background: var(--primary);
    border-color: var(--primary);
    color: var(--text);
}

.Pagination .page-numbers.prev,
.Pagination .page-numbers.next {
    background: var(--gray-light);
}

.Pagination .page-numbers.prev:hover,
.Pagination .page-numbers.next:hover {
    background: var(--primary);
}

/* Responsive */
@media (max-width: 768px) {
    .HeroTitle {
        font-size: 2.5rem;
    }
    
    .FeaturedGrid {
        grid-template-columns: 1fr;
        grid-template-rows: auto;
        height: auto;
    }
    
    .FeaturedCard.Large {
        grid-row: auto;
    }
    
    .SectionFilters {
        flex-direction: column;
        align-items: stretch;
    }
    
    .FilterTabs {
        justify-content: center;
    }
    
    .CollectionsGrid {
        grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
        gap: 20px;
    }
}
</style>

<script>
jQuery(document).ready(function($) {
    // Filter functionality
    $('.FilterTab').on('click', function() {
        $('.FilterTab').removeClass('active');
        $(this).addClass('active');
        
        var filter = $(this).data('filter');
        filterCollections(filter);
    });
    
    // Sort functionality
    $('.SortSelect').on('change', function() {
        var sortBy = $(this).val();
        sortCollections(sortBy);
    });
    
    function filterCollections(filter) {
        $('.CollectionCard').each(function() {
            var $card = $(this);
            var type = $card.data('type');
            var featured = $card.data('featured');
            
            var show = false;
            
            switch(filter) {
                case 'all':
                    show = true;
                    break;
                case 'featured':
                    show = featured == 1;
                    break;
                case 'movies':
                    show = type == 'movies';
                    break;
                case 'series':
                    show = type == 'series';
                    break;
            }
            
            if (show) {
                $card.fadeIn(300);
            } else {
                $card.fadeOut(300);
            }
        });
    }
    
    function sortCollections(sortBy) {
        var $grid = $('#collections-grid');
        var $cards = $('.CollectionCard').toArray();
        
        $cards.sort(function(a, b) {
            var $a = $(a);
            var $b = $(b);
            
            switch(sortBy) {
                case 'date_desc':
                    return new Date($b.data('date')) - new Date($a.data('date'));
                case 'date_asc':
                    return new Date($a.data('date')) - new Date($b.data('date'));
                case 'title_asc':
                    return $a.data('title').localeCompare($b.data('title'));
                case 'title_desc':
                    return $b.data('title').localeCompare($a.data('title'));
                case 'items_desc':
                    return $b.data('items') - $a.data('items');
                default:
                    return 0;
            }
        });
        
        $grid.empty().append($cards);
    }
    
    // Smooth scrolling for anchor links
    $('a[href^="#"]').on('click', function(e) {
        e.preventDefault();
        var target = $(this.getAttribute('href'));
        if (target.length) {
            $('html, body').animate({
                scrollTop: target.offset().top - 100
            }, 1000);
        }
    });
});
</script>

<?php get_footer(); ?>
