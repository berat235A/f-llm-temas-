<?php get_header(); ?>
	<div class="bd">
		<div class="dfxc">
			<main class="main-site">
				<!-- Seri Filmler Bölümü -->
				<section class="section series-collections">
					<header class="section-header">
						<div class="rw alg-cr jst-sb">
							<h2 class="section-title">
								<i class="fa fa-film"></i>
								Seri Filmler
							</h2>
							<p class="section-description">Filmlerin ait olduğu seri filmler</p>
						</div>
					</header>
					<div class="series-collections-grid">
						<?php
						// Debug için tüm seri filmleri al (boş olanlar dahil)
						$series_collections = get_terms(array(
							'taxonomy' => 'series_collection',
							'hide_empty' => false, // Boş olanları da göster
							'orderby' => 'count',
							'order' => 'DESC',
							'number' => 12
						));
						
						// Debug: Seri film sayısını göster
						echo '<!-- Debug: ' . count($series_collections) . ' seri film bulundu -->';
						
						// Test için manuel seri film oluştur
						if (empty($series_collections) || is_wp_error($series_collections)) {
							// Test seri filmi oluştur
							$test_series = wp_insert_term(
								'Test Seri Film',
								'series_collection',
								array(
									'description' => 'Bu bir test seri filmidir',
									'slug' => 'test-seri-film'
								)
							);
							
							if (!is_wp_error($test_series)) {
								update_term_meta($test_series['term_id'], 'series_status', 'active');
								// Seri filmleri tekrar al
								$series_collections = get_terms(array(
									'taxonomy' => 'series_collection',
									'hide_empty' => false,
									'orderby' => 'count',
									'order' => 'DESC',
									'number' => 12
								));
							}
						}
						
						if (!empty($series_collections) && !is_wp_error($series_collections)) {
							foreach ($series_collections as $series) {
								$series_image = get_term_meta($series->term_id, 'series_image', true);
								$series_status = get_term_meta($series->term_id, 'series_status', true);
								
								// Status kontrolünü kaldır, tüm seri filmleri göster
								// if ($series_status === 'active') {
									// Seri filmdeki ilk filmi al (kapak resmi için)
									$first_movie = get_posts(array(
										'post_type' => 'movies',
										'posts_per_page' => 1,
										'post_status' => 'publish',
										'tax_query' => array(
											array(
												'taxonomy' => 'series_collection',
												'field' => 'term_id',
												'terms' => $series->term_id,
											),
										),
										'orderby' => 'meta_value_num',
										'meta_key' => 'field_release_year',
										'order' => 'ASC'
									));
									?>
									<div class="series-collection-item">
										<article class="post dfx fcl series-collection">
											<div class="post-thumbnail">
												<figure>
													<?php 
													if ($series_image) {
														echo '<img src="' . esc_url($series_image) . '" alt="' . esc_attr($series->name) . '">';
													} elseif (!empty($first_movie)) {
														echo tr_theme_img($first_movie[0]->ID, 'medium', $first_movie[0]->post_title);
													} else {
														echo '<div class="no-image"><i class="fa fa-film"></i></div>';
													}
													?>
												</figure>
												<div class="post-overlay">
													<span class="series-count">
														<i class="fa fa-video"></i>
														<?php echo $series->count; ?> Film
													</span>
													<span class="play-btn">
														<i class="fa fa-play"></i>
													</span>
													<div class="series-info">
														<h3 class="series-title"><?php echo $series->name; ?></h3>
														<?php if ($series->description) { ?>
															<p class="series-description"><?php echo wp_trim_words($series->description, 15); ?></p>
														<?php } ?>
													</div>
												</div>
											</div>
											<a href="<?php echo get_term_link($series); ?>" class="lnk-blk"></a>
										</article>
									</div>
									<?php
								// }
							}
						} else {
							echo '<p class="no-series">Henüz seri film eklenmemiş.</p>';
							echo '<p class="debug-info">Debug: Seri film bulunamadı. Admin panelden seri film ekleyin.</p>';
						}
						?>
					</div>
				</section>

				<section class="section movies">
					<header class="section-header">
						<div class="rw alg-cr jst-sb">
							<h1 class="section-title"><?php echo lang_torofilm('Movies', 'txt_movies'); ?></h1>
						</div>
					</header>
					<?php 
				    if ( have_posts() ) : ?>
						<div class="aa-cn" id="aa-movies">
							<div id="movies-a" class="aa-tb hdd on">
								<ul class="post-lst rw sm rcl2 rcl3a rcl4b rcl3c rcl4d rcl6e">
									<?php
							        while ( have_posts() ) : the_post();
										get_template_part( 'public/partials/template/movies', 'main' );
							    	endwhile; ?>
								</ul>
							</div>
						</div>
						<nav class="navigation pagination">
							<?php torofilm_pagination() ?>
						</nav>
					<?php endif; wp_reset_query();  ?>
				</section>
			</main>
			<?php get_sidebar(); ?>
		</div>
	</div>
<?php get_footer(); ?>