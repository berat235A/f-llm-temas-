<?php 
/*
Template Name: Seri Filmler Sayfası
*/
get_header(); ?>
<div class="bd">
    <div class="dfxc">
        <main class="main-site">
            <!-- Seri Filmler Sayfası -->
            <section class="section series-page">
                <header class="section-header">
                    <div class="rw alg-cr jst-sb">
                        <div class="header-content">
                            <h1 class="section-title">
                                <i class="fa fa-film"></i>
                                Seri Filmler
                            </h1>
                            <p class="section-description">✨ Tüm film serilerini keşfedin ✨</p>
                        </div>
                    </div>
                </header>
                
                <div class="series-listing">
                    <?php
                    // Sayfalama için
                    $paged = get_query_var('paged') ? get_query_var('paged') : 1;
                    $per_page = 20; // Sayfa başına seri film sayısı
                    
                    // Seri filmleri al
                    $series_collections = get_terms(array(
                        'taxonomy' => 'series_collection',
                        'hide_empty' => false,
                        'orderby' => 'name',
                        'order' => 'ASC',
                        'number' => $per_page,
                        'offset' => ($paged - 1) * $per_page
                    ));
                    
                    // Debug: Seri film sayısını göster
                    echo '<!-- Debug: ' . count($series_collections) . ' seri film bulundu -->';
                    
                    if (!empty($series_collections) && !is_wp_error($series_collections)) {
                        echo '<div class="series-grid">';
                        
                        foreach ($series_collections as $series) {
                            $series_image = get_term_meta($series->term_id, 'series_image', true);
                            $series_status = get_term_meta($series->term_id, 'series_status', true);
                            $series_description = $series->description;
                            
                            // Seri filmdeki ilk filmi al (kapak resmi için)
                            $first_movie = get_posts(array(
                                'post_type' => 'movies',
                                'posts_per_page' => 1,
                                'post_status' => 'publish',
                                'tax_query' => array(
                                    array(
                                        'taxonomy' => 'series_collection',
                                        'field' => 'term_id',
                                        'terms' => $series->term_id,
                                    ),
                                ),
                                'orderby' => 'meta_value_num',
                                'meta_key' => 'field_release_year',
                                'order' => 'ASC'
                            ));
                            ?>
                            <div class="series-item">
                                <article class="post dfx fcl series-collection">
                                    <div class="post-thumbnail">
                                        <figure>
                                            <?php 
                                            if ($series_image) {
                                                echo '<img src="' . esc_url($series_image) . '" alt="' . esc_attr($series->name) . '">';
                                            } elseif (!empty($first_movie)) {
                                                echo tr_theme_img($first_movie[0]->ID, 'medium', $first_movie[0]->post_title);
                                            } else {
                                                echo '<div class="no-image"><i class="fa fa-film"></i></div>';
                                            }
                                            ?>
                                        </figure>
                                        <div class="post-overlay">
                                            <span class="series-count">
                                                <i class="fa fa-video"></i>
                                                <?php echo $series->count; ?> Film
                                            </span>
                                            <span class="play-btn">
                                                <i class="fa fa-play"></i>
                                            </span>
                                            <div class="series-info">
                                                <h3 class="series-title"><?php echo $series->name; ?></h3>
                                                <?php if ($series_description) { ?>
                                                    <p class="series-description"><?php echo wp_trim_words($series_description, 20); ?></p>
                                                <?php } ?>
                                            </div>
                                        </div>
                                    </div>
                                    <a href="<?php echo get_term_link($series); ?>" class="lnk-blk"></a>
                                </article>
                            </div>
                            <?php
                        }
                        
                        echo '</div>';
                        
                        // Sayfalama
                        $total_series = wp_count_terms('series_collection', array('hide_empty' => false));
                        $total_pages = ceil($total_series / $per_page);
                        
                        if ($total_pages > 1) {
                            echo '<nav class="series-pagination">';
                            echo '<div class="pagination-wrapper">';
                            
                            // Önceki sayfa
                            if ($paged > 1) {
                                echo '<a href="' . get_pagenum_link($paged - 1) . '" class="pagination-btn prev">';
                                echo '<i class="fa fa-chevron-left"></i> Önceki';
                                echo '</a>';
                            }
                            
                            // Sayfa numaraları
                            for ($i = 1; $i <= $total_pages; $i++) {
                                if ($i == $paged) {
                                    echo '<span class="pagination-btn current">' . $i . '</span>';
                                } else {
                                    echo '<a href="' . get_pagenum_link($i) . '" class="pagination-btn">' . $i . '</a>';
                                }
                            }
                            
                            // Sonraki sayfa
                            if ($paged < $total_pages) {
                                echo '<a href="' . get_pagenum_link($paged + 1) . '" class="pagination-btn next">';
                                echo 'Sonraki <i class="fa fa-chevron-right"></i>';
                                echo '</a>';
                            }
                            
                            echo '</div>';
                            echo '</nav>';
                        }
                        
                    } else {
                        echo '<div class="no-series-found">';
                        echo '<div class="no-series-content">';
                        echo '<i class="fa fa-film"></i>';
                        echo '<h3>Henüz Seri Film Eklenmemiş</h3>';
                        echo '<p>Admin panelden seri film ekleyerek başlayabilirsiniz.</p>';
                        echo '<a href="' . admin_url('admin.php?page=torofilm-add-series') . '" class="button button-primary">Seri Film Ekle</a>';
                        echo '</div>';
                        echo '</div>';
                    }
                    ?>
                </div>
            </section>
        </main>
        <?php get_sidebar(); ?>
    </div>
</div>
<?php get_footer(); ?>
