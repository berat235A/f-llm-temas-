<?php
Class TOROFILM_Add_Theme_Support {
	public function torofilm_add_support(){
		add_theme_support( 'automatic-feed-links' );
		add_theme_support( 'title-tag' );
		add_theme_support( 'custom-logo' );
		add_theme_support( 'post-thumbnails' );
		add_theme_support( 'custom-header' );
		add_theme_support( 'custom-background');
		add_editor_style(array('assets/css/editor-style.css'));
		
		// Register Series Collection Taxonomy
		$this->register_series_collection_taxonomy();
	}
	
	/**
	 * Initialize taxonomy on init hook
	 */
	public function init_series_collection_taxonomy() {
		$this->register_series_collection_taxonomy();
	}
	
	/**
	 * Register Series Collection Taxonomy
	 */
	public function register_series_collection_taxonomy() {
		$labels = array(
			'name' => 'Seri Filmler',
			'singular_name' => 'Seri Film',
			'menu_name' => 'Seri Filmler',
			'all_items' => 'Tüm Seri Filmler',
			'edit_item' => 'Seri Film Düzenle',
			'view_item' => 'Seri Film Görüntüle',
			'update_item' => 'Seri Film Güncelle',
			'add_new_item' => 'Yeni Seri Film Ekle',
			'new_item_name' => 'Yeni Seri Film Adı',
			'search_items' => 'Seri Film Ara',
			'popular_items' => 'Popüler Seri Filmler',
			'separate_items_with_commas' => 'Seri filmleri virgülle ayırın',
			'add_or_remove_items' => 'Seri film ekle veya çıkar',
			'choose_from_most_used' => 'En çok kullanılanlardan seç',
			'not_found' => 'Seri film bulunamadı',
		);

		$args = array(
			'labels' => $labels,
			'public' => true,
			'publicly_queryable' => true,
			'hierarchical' => true,
			'show_ui' => true,
			'show_in_menu' => true,
			'show_in_nav_menus' => true,
			'show_in_rest' => true,
			'show_tagcloud' => true,
			'show_in_quick_edit' => true,
			'show_admin_column' => true,
			'query_var' => true,
			'rewrite' => array('slug' => 'seri-film'),
			'capabilities' => array(
				'manage_terms' => 'manage_categories',
				'edit_terms' => 'manage_categories',
				'delete_terms' => 'manage_categories',
				'assign_terms' => 'edit_posts',
			),
		);

		register_taxonomy('series_collection', array('movies', 'series'), $args);
	}
	public function torofilm_remove_elements_wordpress(){
		remove_action( 'wp_head', 'feed_links', 2 ); //removes feed links.
		remove_action('wp_head', 'feed_links_extra', 3 );  //removes comments feed. 
		// no cambiar comillas
		//show_admin_bar(false);
		remove_filter('the_content', 'wptexturize');
		remove_filter('the_title', 'wptexturize');
		remove_filter('single_post_title', 'wptexturize');
		remove_filter('comment_text', 'wptexturize');
		remove_filter('the_excerpt', 'wptexturize');
		remove_filter('content_save_pre', 'wp_filter_post_kses');
		remove_filter('content_filtered_save_pre', 'wp_filter_post_kses'); 
		add_filter( 'emoji_svg_url', '__return_false' );
		remove_action( 'wp_head', 'wp_resource_hints' );
		remove_action('wp_head', 'rsd_link');
		remove_action('wp_head', 'wlwmanifest_link');
		remove_action('wp_head', 'wp_generator');
		remove_action('wp_head', 'start_post_rel_link');
		remove_action('wp_head', 'index_rel_link');
		remove_action('wp_head', 'adjacent_posts_rel_link');
		remove_action( 'wp_print_styles', 'print_emoji_styles' );
		remove_action( 'wp_head', 'print_emoji_detection_script');
		if ( !current_user_can( 'manage_options' ) ) { 
			$a = 'show_admin_bar';
			add_filter($a,'__return_false');
		}
		add_filter('the_generator', '__return_false');
		remove_action('wp_head', 'adjacent_posts_rel_link_wp_head');
		remove_action('wp_head', 'wp_shortlink_wp_head');
		remove_action( 'wp_head', 'dns-prefetch' );
		remove_action( 'wp_head', 'rest_output_link_wp_head' );
		remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
		// all actions related to emojis
		remove_action( 'admin_print_styles', 'print_emoji_styles' );
		remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
		remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
		remove_action( 'wp_print_styles', 'print_emoji_styles' );
		remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
		remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
		remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
		remove_action('wp_head', 'wp_oembed_add_host_js');
	}
	public function torofilm_remove_gutemberg(){
		wp_dequeue_style( 'wp-block-library' );
	}
	public function code_analityc(){
		$code     = get_option( 'analityc_code', false );
        echo $code;
	}
}