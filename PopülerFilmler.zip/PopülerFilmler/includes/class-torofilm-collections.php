<?php
class TOROFILM_Collections {
    
    public function __construct() {
        add_action('init', array($this, 'register_collections_post_type'));
        add_action('add_meta_boxes', array($this, 'add_collections_meta_boxes'));
        add_action('save_post', array($this, 'save_collections_meta'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_action('wp_ajax_search_movies_series', array($this, 'ajax_search_movies_series'));
        add_action('wp_ajax_remove_from_collection', array($this, 'ajax_remove_from_collection'));
        add_shortcode('torofilm_collections', array($this, 'collections_shortcode'));
    }
    
    /**
     * Koleksiyonlar için custom post type kaydet
     */
    public function register_collections_post_type() {
        $labels = array(
            'name' => __('Koleksiyonlar', 'torofilm'),
            'singular_name' => __('Koleksiyon', 'torofilm'),
            'menu_name' => __('Koleksiyonlar', 'torofilm'),
            'add_new' => __('Yeni Koleksiyon', 'torofilm'),
            'add_new_item' => __('Yeni Koleksiyon Ekle', 'torofilm'),
            'edit_item' => __('Koleksiyonu Düzenle', 'torofilm'),
            'new_item' => __('Yeni Koleksiyon', 'torofilm'),
            'view_item' => __('Koleksiyonu Görüntüle', 'torofilm'),
            'search_items' => __('Koleksiyon Ara', 'torofilm'),
            'not_found' => __('Koleksiyon bulunamadı', 'torofilm'),
            'not_found_in_trash' => __('Çöp kutusunda koleksiyon bulunamadı', 'torofilm'),
        );

        $args = array(
            'labels' => $labels,
            'public' => true,
            'publicly_queryable' => true,
            'show_ui' => true,
            'show_in_menu' => true,
            'query_var' => true,
            'rewrite' => array('slug' => 'koleksiyon'),
            'capability_type' => 'post',
            'has_archive' => true,
            'hierarchical' => false,
            'menu_position' => 5,
            'menu_icon' => 'dashicons-portfolio',
            'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
            'show_in_rest' => true,
        );

        register_post_type('collections', $args);
    }
    
    /**
     * Meta box'ları ekle
     */
    public function add_collections_meta_boxes() {
        add_meta_box(
            'collections_content',
            __('Koleksiyon İçeriği', 'torofilm'),
            array($this, 'collections_content_meta_box'),
            'collections',
            'normal',
            'high'
        );
        
        add_meta_box(
            'collections_settings',
            __('Koleksiyon Ayarları', 'torofilm'),
            array($this, 'collections_settings_meta_box'),
            'collections',
            'side',
            'default'
        );
    }
    
    /**
     * Koleksiyon içeriği meta box
     */
    public function collections_content_meta_box($post) {
        wp_nonce_field('collections_meta_nonce', 'collections_meta_nonce');
        
        $selected_items = get_post_meta($post->ID, '_collection_items', true);
        if (!is_array($selected_items)) {
            $selected_items = array();
        }
        
        echo '<div id="collections-manager">';
        echo '<div class="collections-search">';
        echo '<input type="text" id="search-movies-series" placeholder="' . __('Film veya dizi ara...', 'torofilm') . '" />';
        echo '<div id="search-results"></div>';
        echo '</div>';
        
        echo '<div class="collections-selected">';
        echo '<h4>' . __('Seçili İçerikler', 'torofilm') . '</h4>';
        echo '<div id="selected-items">';
        
        if (!empty($selected_items)) {
            foreach ($selected_items as $item_id) {
                $post_type = get_post_type($item_id);
                $title = get_the_title($item_id);
                $thumbnail = TOROFLIX_Movies::image($item_id, 'thumbnail');
                
                echo '<div class="selected-item" data-id="' . $item_id . '">';
                echo '<div class="item-thumbnail">' . $thumbnail . '</div>';
                echo '<div class="item-info">';
                echo '<h5>' . $title . '</h5>';
                echo '<span class="item-type">' . ($post_type == 'movies' ? __('Film', 'torofilm') : __('Dizi', 'torofilm')) . '</span>';
                echo '</div>';
                echo '<button type="button" class="remove-item" data-id="' . $item_id . '">×</button>';
                echo '</div>';
            }
        }
        
        echo '</div>';
        echo '</div>';
        echo '</div>';
        
        // Hidden input to store selected items
        echo '<input type="hidden" name="collection_items" value="' . implode(',', $selected_items) . '" />';
    }
    
    /**
     * Koleksiyon ayarları meta box
     */
    public function collections_settings_meta_box($post) {
        $collection_type = get_post_meta($post->ID, '_collection_type', true);
        $featured = get_post_meta($post->ID, '_collection_featured', true);
        $sort_order = get_post_meta($post->ID, '_collection_sort_order', true);
        
        echo '<p>';
        echo '<label for="collection_type">' . __('Koleksiyon Türü:', 'torofilm') . '</label><br>';
        echo '<select name="collection_type" id="collection_type">';
        echo '<option value="mixed" ' . selected($collection_type, 'mixed', false) . '>' . __('Karışık', 'torofilm') . '</option>';
        echo '<option value="movies" ' . selected($collection_type, 'movies', false) . '>' . __('Sadece Filmler', 'torofilm') . '</option>';
        echo '<option value="series" ' . selected($collection_type, 'series', false) . '>' . __('Sadece Diziler', 'torofilm') . '</option>';
        echo '</select>';
        echo '</p>';
        
        echo '<p>';
        echo '<label>';
        echo '<input type="checkbox" name="collection_featured" value="1" ' . checked($featured, 1, false) . ' />';
        echo ' ' . __('Öne Çıkan Koleksiyon', 'torofilm');
        echo '</label>';
        echo '</p>';
        
        echo '<p>';
        echo '<label for="collection_sort_order">' . __('Sıralama:', 'torofilm') . '</label><br>';
        echo '<select name="collection_sort_order" id="collection_sort_order">';
        echo '<option value="date_desc" ' . selected($sort_order, 'date_desc', false) . '>' . __('Tarihe Göre (Yeni)', 'torofilm') . '</option>';
        echo '<option value="date_asc" ' . selected($sort_order, 'date_asc', false) . '>' . __('Tarihe Göre (Eski)', 'torofilm') . '</option>';
        echo '<option value="title_asc" ' . selected($sort_order, 'title_asc', false) . '>' . __('Başlığa Göre (A-Z)', 'torofilm') . '</option>';
        echo '<option value="title_desc" ' . selected($sort_order, 'title_desc', false) . '>' . __('Başlığa Göre (Z-A)', 'torofilm') . '</option>';
        echo '<option value="rating_desc" ' . selected($sort_order, 'rating_desc', false) . '>' . __('Puana Göre (Yüksek)', 'torofilm') . '</option>';
        echo '<option value="views_desc" ' . selected($sort_order, 'views_desc', false) . '>' . __('İzlenmeye Göre (Yüksek)', 'torofilm') . '</option>';
        echo '</select>';
        echo '</p>';
    }
    
    /**
     * Meta verileri kaydet
     */
    public function save_collections_meta($post_id) {
        if (!isset($_POST['collections_meta_nonce']) || !wp_verify_nonce($_POST['collections_meta_nonce'], 'collections_meta_nonce')) {
            return;
        }
        
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        
        if (get_post_type($post_id) != 'collections') {
            return;
        }
        
        // Koleksiyon öğelerini kaydet
        if (isset($_POST['collection_items'])) {
            $items = array_filter(explode(',', $_POST['collection_items']));
            update_post_meta($post_id, '_collection_items', $items);
        }
        
        // Koleksiyon türünü kaydet
        if (isset($_POST['collection_type'])) {
            update_post_meta($post_id, '_collection_type', sanitize_text_field($_POST['collection_type']));
        }
        
        // Öne çıkan koleksiyon
        $featured = isset($_POST['collection_featured']) ? 1 : 0;
        update_post_meta($post_id, '_collection_featured', $featured);
        
        // Sıralama
        if (isset($_POST['collection_sort_order'])) {
            update_post_meta($post_id, '_collection_sort_order', sanitize_text_field($_POST['collection_sort_order']));
        }
    }
    
    /**
     * Admin scriptlerini yükle
     */
    public function enqueue_admin_scripts($hook) {
        global $post_type;
        
        if ($post_type == 'collections' && ($hook == 'post.php' || $hook == 'post-new.php')) {
            wp_enqueue_script('jquery');
            wp_enqueue_script('jquery-ui-sortable');
            
            wp_add_inline_script('jquery', '
                jQuery(document).ready(function($) {
                    var searchTimeout;
                    
                    // Film/dizi arama
                    $("#search-movies-series").on("input", function() {
                        var query = $(this).val();
                        
                        clearTimeout(searchTimeout);
                        searchTimeout = setTimeout(function() {
                            if (query.length >= 2) {
                                searchMoviesSeries(query);
                            } else {
                                $("#search-results").empty();
                            }
                        }, 300);
                    });
                    
                    function searchMoviesSeries(query) {
                        $.ajax({
                            url: ajaxurl,
                            type: "POST",
                            data: {
                                action: "search_movies_series",
                                query: query,
                                nonce: "' . wp_create_nonce('search_movies_series') . '"
                            },
                            success: function(response) {
                                if (response.success) {
                                    displaySearchResults(response.data);
                                }
                            }
                        });
                    }
                    
                    function displaySearchResults(results) {
                        var html = "<div class=\"search-results-list\">";
                        results.forEach(function(item) {
                            html += "<div class=\"search-result-item\" data-id=\"" + item.id + "\">";
                            html += "<div class=\"item-thumbnail\">" + item.thumbnail + "</div>";
                            html += "<div class=\"item-info\">";
                            html += "<h5>" + item.title + "</h5>";
                            html += "<span class=\"item-type\">" + item.type + "</span>";
                            html += "</div>";
                            html += "<button type=\"button\" class=\"add-item\" data-id=\"" + item.id + "\">+</button>";
                            html += "</div>";
                        });
                        html += "</div>";
                        $("#search-results").html(html);
                    }
                    
                    // Öğe ekleme
                    $(document).on("click", ".add-item", function() {
                        var itemId = $(this).data("id");
                        addItemToCollection(itemId);
                        $(this).closest(".search-result-item").remove();
                    });
                    
                    // Öğe kaldırma
                    $(document).on("click", ".remove-item", function() {
                        var itemId = $(this).data("id");
                        removeItemFromCollection(itemId);
                    });
                    
                    function addItemToCollection(itemId) {
                        var currentItems = $("input[name=\"collection_items\"]").val();
                        var items = currentItems ? currentItems.split(",") : [];
                        
                        if (items.indexOf(itemId) === -1) {
                            items.push(itemId);
                            $("input[name=\"collection_items\"]").val(items.join(","));
                            
                            // Seçili öğeler listesine ekle
                            var item = $(".search-result-item[data-id=\"" + itemId + "\"]").clone();
                            item.find(".add-item").removeClass("add-item").addClass("remove-item").text("×");
                            item.removeClass("search-result-item").addClass("selected-item");
                            $("#selected-items").append(item);
                        }
                    }
                    
                    function removeItemFromCollection(itemId) {
                        var currentItems = $("input[name=\"collection_items\"]").val();
                        var items = currentItems ? currentItems.split(",") : [];
                        
                        items = items.filter(function(id) {
                            return id != itemId;
                        });
                        
                        $("input[name=\"collection_items\"]").val(items.join(","));
                        $(".selected-item[data-id=\"" + itemId + "\"]").remove();
                    }
                    
                    // Sıralama
                    $("#selected-items").sortable({
                        update: function(event, ui) {
                            var items = [];
                            $("#selected-items .selected-item").each(function() {
                                items.push($(this).data("id"));
                            });
                            $("input[name=\"collection_items\"]").val(items.join(","));
                        }
                    });
                });
            ');
            
            wp_add_inline_style('wp-admin', '
                #collections-manager {
                    max-width: 100%;
                }
                
                .collections-search {
                    margin-bottom: 20px;
                }
                
                #search-movies-series {
                    width: 100%;
                    padding: 10px;
                    border: 1px solid #ddd;
                    border-radius: 4px;
                }
                
                .search-results-list {
                    max-height: 300px;
                    overflow-y: auto;
                    border: 1px solid #ddd;
                    border-top: none;
                    background: #fff;
                }
                
                .search-result-item, .selected-item {
                    display: flex;
                    align-items: center;
                    padding: 10px;
                    border-bottom: 1px solid #eee;
                    position: relative;
                }
                
                .search-result-item:hover, .selected-item:hover {
                    background: #f9f9f9;
                }
                
                .item-thumbnail {
                    width: 60px;
                    height: 80px;
                    margin-right: 15px;
                    flex-shrink: 0;
                }
                
                .item-thumbnail img {
                    width: 100%;
                    height: 100%;
                    object-fit: cover;
                    border-radius: 4px;
                }
                
                .item-info {
                    flex: 1;
                }
                
                .item-info h5 {
                    margin: 0 0 5px 0;
                    font-size: 14px;
                }
                
                .item-type {
                    font-size: 12px;
                    color: #666;
                }
                
                .add-item, .remove-item {
                    position: absolute;
                    right: 10px;
                    top: 50%;
                    transform: translateY(-50%);
                    width: 30px;
                    height: 30px;
                    border: none;
                    border-radius: 50%;
                    background: #0073aa;
                    color: white;
                    font-size: 18px;
                    cursor: pointer;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                }
                
                .remove-item {
                    background: #dc3232;
                }
                
                .add-item:hover {
                    background: #005a87;
                }
                
                .remove-item:hover {
                    background: #a00;
                }
                
                .collections-selected h4 {
                    margin-bottom: 15px;
                }
                
                #selected-items {
                    min-height: 100px;
                    border: 2px dashed #ddd;
                    padding: 10px;
                }
                
                #selected-items:empty::before {
                    content: "Henüz içerik eklenmedi";
                    color: #999;
                    font-style: italic;
                }
            ');
        }
    }
    
    /**
     * AJAX: Film/dizi arama
     */
    public function ajax_search_movies_series() {
        if (!wp_verify_nonce($_POST['nonce'], 'search_movies_series')) {
            wp_die('Güvenlik hatası!');
        }
        
        $query = sanitize_text_field($_POST['query']);
        $results = array();
        
        $args = array(
            'post_type' => array('movies', 'series'),
            'post_status' => 'publish',
            'posts_per_page' => 10,
            's' => $query,
            'meta_query' => array(
                array(
                    'key' => 'poster_hotlink',
                    'compare' => 'EXISTS'
                )
            )
        );
        
        $posts = get_posts($args);
        
        foreach ($posts as $post) {
            $results[] = array(
                'id' => $post->ID,
                'title' => $post->post_title,
                'type' => $post->post_type == 'movies' ? __('Film', 'torofilm') : __('Dizi', 'torofilm'),
                'thumbnail' => TOROFLIX_Movies::image($post->ID, 'thumbnail')
            );
        }
        
        wp_send_json_success($results);
    }
    
    /**
     * Koleksiyon öğelerini al
     */
    public static function get_collection_items($collection_id, $limit = -1) {
        $items = get_post_meta($collection_id, '_collection_items', true);
        if (!is_array($items)) {
            return array();
        }
        
        $sort_order = get_post_meta($collection_id, '_collection_sort_order', true);
        $collection_type = get_post_meta($collection_id, '_collection_type', true);
        
        $args = array(
            'post_type' => array('movies', 'series'),
            'post__in' => $items,
            'posts_per_page' => $limit,
            'post_status' => 'publish'
        );
        
        // Sıralama
        switch ($sort_order) {
            case 'date_asc':
                $args['orderby'] = 'date';
                $args['order'] = 'ASC';
                break;
            case 'title_asc':
                $args['orderby'] = 'title';
                $args['order'] = 'ASC';
                break;
            case 'title_desc':
                $args['orderby'] = 'title';
                $args['order'] = 'DESC';
                break;
            case 'rating_desc':
                $args['orderby'] = 'meta_value_num';
                $args['meta_key'] = 'rating';
                $args['order'] = 'DESC';
                break;
            case 'views_desc':
                $args['orderby'] = 'meta_value_num';
                $args['meta_key'] = 'views';
                $args['order'] = 'DESC';
                break;
            default: // date_desc
                $args['orderby'] = 'date';
                $args['order'] = 'DESC';
        }
        
        // Koleksiyon türüne göre filtrele
        if ($collection_type == 'movies') {
            $args['post_type'] = 'movies';
        } elseif ($collection_type == 'series') {
            $args['post_type'] = 'series';
        }
        
        return get_posts($args);
    }
    
    /**
     * Öne çıkan koleksiyonları al
     */
    public static function get_featured_collections($limit = 5) {
        $args = array(
            'post_type' => 'collections',
            'posts_per_page' => $limit,
            'post_status' => 'publish',
            'meta_query' => array(
                array(
                    'key' => '_collection_featured',
                    'value' => 1,
                    'compare' => '='
                )
            )
        );
        
        return get_posts($args);
    }
    
    /**
     * Koleksiyonlar shortcode
     */
    public function collections_shortcode($atts) {
        $atts = shortcode_atts(array(
            'limit' => 6,
            'featured' => 'false',
            'type' => 'all', // all, movies, series
            'layout' => 'grid', // grid, list, carousel
            'show_title' => 'true',
            'show_excerpt' => 'true',
            'show_meta' => 'true'
        ), $atts);
        
        $args = array(
            'post_type' => 'collections',
            'posts_per_page' => intval($atts['limit']),
            'post_status' => 'publish'
        );
        
        if ($atts['featured'] === 'true') {
            $args['meta_query'] = array(
                array(
                    'key' => '_collection_featured',
                    'value' => 1,
                    'compare' => '='
                )
            );
        }
        
        if ($atts['type'] !== 'all') {
            $args['meta_query'][] = array(
                'key' => '_collection_type',
                'value' => $atts['type'],
                'compare' => '='
            );
        }
        
        $collections = get_posts($args);
        
        if (empty($collections)) {
            return '<div class="no-collections">' . __('Henüz koleksiyon bulunmuyor.', 'torofilm') . '</div>';
        }
        
        ob_start();
        
        $layout_class = 'collections-' . $atts['layout'];
        $show_title = $atts['show_title'] === 'true';
        $show_excerpt = $atts['show_excerpt'] === 'true';
        $show_meta = $atts['show_meta'] === 'true';
        
        echo '<div class="torofilm-collections-shortcode ' . $layout_class . '">';
        
        foreach ($collections as $collection) {
            $collection_type = get_post_meta($collection->ID, '_collection_type', true);
            $is_featured = get_post_meta($collection->ID, '_collection_featured', true);
            $items = get_post_meta($collection->ID, '_collection_items', true);
            $item_count = is_array($items) ? count($items) : 0;
            
            echo '<div class="collection-item">';
            
            // Thumbnail
            echo '<div class="collection-thumbnail">';
            echo '<a href="' . get_permalink($collection->ID) . '">';
            if (has_post_thumbnail($collection->ID)) {
                echo get_the_post_thumbnail($collection->ID, 'medium');
            } else {
                echo '<img src="' . TOROFILM_DIR_URI . 'public/img/cnt/dvr300.png" alt="' . get_the_title($collection->ID) . '" />';
            }
            
            if ($is_featured) {
                echo '<span class="featured-badge"><i class="fa fa-star"></i></span>';
            }
            echo '</a>';
            echo '</div>';
            
            // Content
            echo '<div class="collection-content">';
            
            if ($show_title) {
                echo '<h3 class="collection-title">';
                echo '<a href="' . get_permalink($collection->ID) . '">' . get_the_title($collection->ID) . '</a>';
                echo '</h3>';
            }
            
            if ($show_meta) {
                echo '<div class="collection-meta">';
                echo '<span class="meta-item"><i class="fa fa-film"></i> ' . $item_count . ' ' . ($item_count == 1 ? __('İçerik', 'torofilm') : __('İçerik', 'torofilm')) . '</span>';
                echo '<span class="meta-item"><i class="fa fa-calendar"></i> ' . get_the_date('d.m.Y', $collection->ID) . '</span>';
                if ($collection_type && $collection_type != 'mixed') {
                    echo '<span class="meta-item"><i class="fa fa-tag"></i> ' . ($collection_type == 'movies' ? __('Filmler', 'torofilm') : __('Diziler', 'torofilm')) . '</span>';
                }
                echo '</div>';
            }
            
            if ($show_excerpt) {
                echo '<div class="collection-excerpt">';
                echo '<p>' . wp_trim_words(get_the_excerpt($collection->ID), 15) . '</p>';
                echo '</div>';
            }
            
            echo '</div>';
            echo '</div>';
        }
        
        echo '</div>';
        
        // CSS for shortcode
        echo '<style>
        .torofilm-collections-shortcode {
            display: grid;
            gap: 20px;
        }
        
        .torofilm-collections-shortcode.collections-grid {
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
        }
        
        .torofilm-collections-shortcode.collections-list {
            grid-template-columns: 1fr;
        }
        
        .torofilm-collections-shortcode.collections-list .collection-item {
            display: flex;
            gap: 15px;
        }
        
        .torofilm-collections-shortcode.collections-list .collection-thumbnail {
            width: 120px;
            height: 160px;
            flex-shrink: 0;
        }
        
        .collection-item {
            background: var(--gray);
            border-radius: 10px;
            overflow: hidden;
            transition: transform 0.3s ease;
        }
        
        .collection-item:hover {
            transform: translateY(-3px);
        }
        
        .collection-thumbnail {
            position: relative;
            height: 200px;
            overflow: hidden;
        }
        
        .collection-thumbnail img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .featured-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            background: rgba(255, 215, 0, 0.9);
            color: var(--dark);
            padding: 5px 8px;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .collection-content {
            padding: 15px;
        }
        
        .collection-title {
            margin: 0 0 10px 0;
            font-size: 1.1rem;
        }
        
        .collection-title a {
            color: var(--text);
            text-decoration: none;
            transition: color 0.3s ease;
        }
        
        .collection-title a:hover {
            color: var(--primary);
        }
        
        .collection-meta {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 10px;
        }
        
        .meta-item {
            display: flex;
            align-items: center;
            gap: 5px;
            font-size: 0.85rem;
            color: var(--light-7);
        }
        
        .meta-item i {
            font-size: 0.8rem;
            color: var(--primary);
        }
        
        .collection-excerpt {
            font-size: 0.9rem;
            color: var(--light-7);
            line-height: 1.4;
        }
        
        .collection-excerpt p {
            margin: 0;
        }
        
        .no-collections {
            text-align: center;
            padding: 40px;
            color: var(--tertiary);
            font-style: italic;
        }
        </style>';
        
        return ob_get_clean();
    }
}
