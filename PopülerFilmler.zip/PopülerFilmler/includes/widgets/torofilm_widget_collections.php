<?php
class TOROFILM_Widget_Collections extends WP_Widget {
    
    public function __construct() {
        parent::__construct(
            'torofilm_widget_collections',
            __('ToroFilm - Koleksiyonlar', 'torofilm'),
            array('description' => __('Öne çıkan koleksiyonları gösterir', 'torofilm'))
        );
    }
    
    public function widget($args, $instance) {
        $title = apply_filters('widget_title', $instance['title']);
        $number = !empty($instance['number']) ? absint($instance['number']) : 5;
        $show_featured = !empty($instance['show_featured']) ? 1 : 0;
        
        echo $args['before_widget'];
        
        if (!empty($title)) {
            echo $args['before_title'] . $title . $args['after_title'];
        }
        
        $query_args = array(
            'post_type' => 'collections',
            'posts_per_page' => $number,
            'post_status' => 'publish'
        );
        
        if ($show_featured) {
            $query_args['meta_query'] = array(
                array(
                    'key' => '_collection_featured',
                    'value' => 1,
                    'compare' => '='
                )
            );
        }
        
        $collections = get_posts($query_args);
        
        if (!empty($collections)) :
        ?>
        <div class="WidgetCollections">
            <?php foreach ($collections as $collection) : ?>
            <div class="CollectionItem">
                <div class="CollectionThumbnail">
                    <a href="<?php echo get_permalink($collection->ID); ?>">
                        <?php if (has_post_thumbnail($collection->ID)) : ?>
                            <?php echo get_the_post_thumbnail($collection->ID, 'thumbnail'); ?>
                        <?php else : ?>
                            <img src="<?php echo TOROFILM_DIR_URI . 'public/img/cnt/dvr300.png'; ?>" alt="<?php echo get_the_title($collection->ID); ?>" />
                        <?php endif; ?>
                    </a>
                </div>
                
                <div class="CollectionInfo">
                    <h4 class="CollectionTitle">
                        <a href="<?php echo get_permalink($collection->ID); ?>">
                            <?php echo get_the_title($collection->ID); ?>
                        </a>
                    </h4>
                    
                    <div class="CollectionMeta">
                        <span class="CollectionItems">
                            <i class="fa fa-film"></i>
                            <?php 
                            $items = get_post_meta($collection->ID, '_collection_items', true);
                            $count = is_array($items) ? count($items) : 0;
                            echo $count . ' ' . ($count == 1 ? __('İçerik', 'torofilm') : __('İçerik', 'torofilm'));
                            ?>
                        </span>
                        
                        <span class="CollectionDate">
                            <i class="fa fa-calendar"></i>
                            <?php echo get_the_date('d.m.Y', $collection->ID); ?>
                        </span>
                    </div>
                    
                    <div class="CollectionExcerpt">
                        <p><?php echo wp_trim_words(get_the_excerpt($collection->ID), 10); ?></p>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
            
            <div class="WidgetFooter">
                <a href="<?php echo get_post_type_archive_link('collections'); ?>" class="ViewAll">
                    <?php _e('Tüm Koleksiyonları Gör', 'torofilm'); ?>
                    <i class="fa fa-arrow-right"></i>
                </a>
            </div>
        </div>
        <?php else : ?>
        <div class="NoCollections">
            <p><?php _e('Henüz koleksiyon bulunmuyor.', 'torofilm'); ?></p>
        </div>
        <?php endif;
        
        echo $args['after_widget'];
    }
    
    public function form($instance) {
        $title = !empty($instance['title']) ? $instance['title'] : __('Koleksiyonlar', 'torofilm');
        $number = !empty($instance['number']) ? $instance['number'] : 5;
        $show_featured = !empty($instance['show_featured']) ? $instance['show_featured'] : 0;
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Başlık:', 'torofilm'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>">
        </p>
        
        <p>
            <label for="<?php echo $this->get_field_id('number'); ?>"><?php _e('Gösterilecek koleksiyon sayısı:', 'torofilm'); ?></label>
            <input class="tiny-text" id="<?php echo $this->get_field_id('number'); ?>" name="<?php echo $this->get_field_name('number'); ?>" type="number" step="1" min="1" value="<?php echo esc_attr($number); ?>" size="3">
        </p>
        
        <p>
            <input class="checkbox" type="checkbox" <?php checked($show_featured); ?> id="<?php echo $this->get_field_id('show_featured'); ?>" name="<?php echo $this->get_field_name('show_featured'); ?>" />
            <label for="<?php echo $this->get_field_id('show_featured'); ?>"><?php _e('Sadece öne çıkan koleksiyonları göster', 'torofilm'); ?></label>
        </p>
        <?php
    }
    
    public function update($new_instance, $old_instance) {
        $instance = array();
        $instance['title'] = (!empty($new_instance['title'])) ? strip_tags($new_instance['title']) : '';
        $instance['number'] = (!empty($new_instance['number'])) ? absint($new_instance['number']) : 5;
        $instance['show_featured'] = (!empty($new_instance['show_featured'])) ? 1 : 0;
        
        return $instance;
    }
}

// Widget'ı kaydet
function register_torofilm_collections_widget() {
    register_widget('TOROFILM_Widget_Collections');
}
add_action('widgets_init', 'register_torofilm_collections_widget');
