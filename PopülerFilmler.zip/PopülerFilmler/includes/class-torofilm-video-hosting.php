<?php
/**
 * Torofilm Video Hosting Support
 * 
 * @package Torofilm
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class TOROFILM_Video_Hosting {
    
    /**
     * Desteklenen video hosting servisleri
     */
    private $supported_hosts = array(
        'youtube' => array(
            'name' => 'YouTube',
            'domain' => 'youtube.com',
            'embed_url' => 'https://www.youtube.com/embed/',
            'regex' => '/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([a-zA-Z0-9_-]+)/',
            'type' => 'iframe'
        ),
        'mediafire' => array(
            'name' => 'Mediafire',
            'domain' => 'mediafire.com',
            'embed_url' => '',
            'regex' => '/mediafire\.com\/file\/([a-zA-Z0-9]+)/',
            'type' => 'direct'
        ),
        'vidmoly' => array(
            'name' => 'Vidmoly',
            'domain' => 'vidmoly.net',
            'embed_url' => 'https://vidmoly.net/embed-',
            'regex' => '/vidmoly\.net\/([a-zA-Z0-9]+)/',
            'type' => 'iframe'
        ),
        'filemoon' => array(
            'name' => 'FileMoon',
            'domain' => 'filemoon.sx',
            'embed_url' => 'https://filemoon.sx/e/',
            'regex' => '/filemoon\.sx\/e\/([a-zA-Z0-9]+)/',
            'type' => 'iframe'
        ),
        'streamwish' => array(
            'name' => 'StreamWish',
            'domain' => 'davioad.com',
            'embed_url' => 'https://davioad.com/e/',
            'regex' => '/davioad\.com\/e\/([a-zA-Z0-9]+)/',
            'type' => 'iframe'
        ),
        'uptobox' => array(
            'name' => 'Uptobox',
            'domain' => 'uptobox.com',
            'embed_url' => '',
            'regex' => '/uptobox\.com\/([a-zA-Z0-9]+)/',
            'type' => 'direct'
        ),
        'okru' => array(
            'name' => 'OK.RU',
            'domain' => 'ok.ru',
            'embed_url' => 'https://ok.ru/videoembed/',
            'regex' => '/ok\.ru\/video\/([a-zA-Z0-9]+)/',
            'type' => 'iframe'
        ),
        'sendvid' => array(
            'name' => 'SendVid',
            'domain' => 'sendvid.com',
            'embed_url' => 'https://sendvid.com/embed/',
            'regex' => '/sendvid\.com\/([a-zA-Z0-9]+)/',
            'type' => 'iframe'
        ),
        'fembed' => array(
            'name' => 'Fembed',
            'domain' => 'fembed.com',
            'embed_url' => 'https://www.fembed.com/v/',
            'regex' => '/fembed\.com\/v\/([a-zA-Z0-9]+)/',
            'type' => 'iframe'
        ),
        'doodstream' => array(
            'name' => 'Doodstream',
            'domain' => 'doodstream.com',
            'embed_url' => 'https://doodstream.com/e/',
            'regex' => '/doodstream\.com\/e\/([a-zA-Z0-9]+)/',
            'type' => 'iframe'
        ),
        'streamtap' => array(
            'name' => 'Streamtap',
            'domain' => 'streamtap.net',
            'embed_url' => 'https://streamtap.net/embed/',
            'regex' => '/streamtap\.net\/embed\/([a-zA-Z0-9]+)/',
            'type' => 'iframe'
        ),
        'voe' => array(
            'name' => 'Voe.sx',
            'domain' => 'voe.sx',
            'embed_url' => 'https://voe.sx/e/',
            'regex' => '/voe\.sx\/e\/([a-zA-Z0-9]+)/',
            'type' => 'iframe'
        ),
        'streamhub' => array(
            'name' => 'Streamhub',
            'domain' => 'streamhub.gg',
            'embed_url' => 'https://streamhub.mn/e/',
            'regex' => '/streamhub\.gg\/e\/([a-zA-Z0-9]+)/',
            'type' => 'iframe'
        ),
        'filemoon' => array(
            'name' => 'Filemoon',
            'domain' => 'filemoon.sx',
            'embed_url' => 'https://filemoon.sx/e/',
            'regex' => '/filemoon\.sx\/e\/([a-zA-Z0-9]+)/',
            'type' => 'iframe'
        ),
        'userscloud' => array(
            'name' => 'Userscloud',
            'domain' => 'userscloud.com',
            'embed_url' => '',
            'regex' => '/userscloud\.com\/([a-zA-Z0-9]+)/',
            'type' => 'direct'
        ),
        'savefiles' => array(
            'name' => 'Savefiles',
            'domain' => 'savefiles.com',
            'embed_url' => '',
            'regex' => '/savefiles\.com\/([a-zA-Z0-9]+)/',
            'type' => 'direct'
        ),
        'lulustream' => array(
            'name' => 'Lulustream',
            'domain' => 'lulustream.com',
            'embed_url' => 'https://lulustream.com/embed/',
            'regex' => '/lulustream\.com\/embed\/([a-zA-Z0-9]+)/',
            'type' => 'iframe'
        ),
        'bigwarp' => array(
            'name' => 'Bigwarp.io',
            'domain' => 'bigwarp.io',
            'embed_url' => 'https://bigwarp.io/e/',
            'regex' => '/bigwarp\.io\/e\/([a-zA-Z0-9]+)/',
            'type' => 'iframe'
        ),
        'vidguard' => array(
            'name' => 'Vidguard.to',
            'domain' => 'vidguard.to',
            'embed_url' => 'https://vidguard.to/e/',
            'regex' => '/vidguard\.to\/e\/([a-zA-Z0-9]+)/',
            'type' => 'iframe'
        ),
        'goodstream' => array(
            'name' => 'Goodstream',
            'domain' => 'goodstream.uno',
            'embed_url' => 'https://goodstream.uno/e/',
            'regex' => '/goodstream\.uno\/e\/([a-zA-Z0-9]+)/',
            'type' => 'iframe'
        ),
        'dropload' => array(
            'name' => 'Dropload',
            'domain' => 'dropload.io',
            'embed_url' => 'https://dropload.io/e/',
            'regex' => '/dropload\.io\/e\/([a-zA-Z0-9]+)/',
            'type' => 'iframe'
        ),
        'vidhide' => array(
            'name' => 'Vidhide',
            'domain' => 'vidhide.com',
            'embed_url' => 'https://vidhide.com/e/',
            'regex' => '/vidhide\.com\/e\/([a-zA-Z0-9]+)/',
            'type' => 'iframe'
        )
    );
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('init', array($this, 'init'));
    }
    
    /**
     * Initialize
     */
    public function init() {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_shortcode('torofilm_video', array($this, 'video_shortcode'));
        add_action('wp_ajax_get_video_embed', array($this, 'ajax_get_video_embed'));
        add_action('wp_ajax_nopriv_get_video_embed', array($this, 'ajax_get_video_embed'));
    }
    
    /**
     * Enqueue scripts and styles
     */
    public function enqueue_scripts() {
        wp_enqueue_style('torofilm-video-player', get_template_directory_uri() . '/public/css/video-player.css', array(), TOROFILM_VERSION);
        wp_enqueue_script('torofilm-video-player', get_template_directory_uri() . '/public/js/video-player.js', array('jquery'), TOROFILM_VERSION, true);
        
        wp_localize_script('torofilm-video-player', 'torofilm_video', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('torofilm_video_nonce'),
            'supported_hosts' => array_keys($this->supported_hosts)
        ));
    }
    
    /**
     * Video shortcode
     */
    public function video_shortcode($atts) {
        $atts = shortcode_atts(array(
            'url' => '',
            'title' => '',
            'poster' => '',
            'autoplay' => 'false',
            'controls' => 'true'
        ), $atts);
        
        if (empty($atts['url'])) {
            return '<p>Video URL gerekli!</p>';
        }
        
        return $this->generate_video_player($atts['url'], $atts);
    }
    
    /**
     * Generate video player HTML
     */
    public function generate_video_player($url, $options = array()) {
        $host_info = $this->detect_host($url);
        
        if (!$host_info) {
            return '<p>Desteklenmeyen video hosting servisi!</p>';
        }
        
        $video_id = $this->extract_video_id($url, $host_info);
        
        if (!$video_id) {
            return '<p>Video ID çıkarılamadı!</p>';
        }
        
        $embed_url = $this->generate_embed_url($host_info, $video_id);
        
        $player_html = '<div class="torofilm-video-player" data-host="' . esc_attr($host_info['name']) . '">';
        
        if ($host_info['type'] === 'iframe') {
            $player_html .= '<iframe src="' . esc_url($embed_url) . '" ';
            $player_html .= 'frameborder="0" allowfullscreen ';
            $player_html .= 'allow="autoplay; encrypted-media; picture-in-picture" ';
            $player_html .= 'class="video-iframe"></iframe>';
        } else {
            $player_html .= '<video controls class="video-direct" ';
            if (!empty($options['poster'])) {
                $player_html .= 'poster="' . esc_url($options['poster']) . '" ';
            }
            if ($options['autoplay'] === 'true') {
                $player_html .= 'autoplay ';
            }
            $player_html .= '><source src="' . esc_url($url) . '" type="video/mp4">';
            $player_html .= 'Tarayıcınız video etiketini desteklemiyor.</video>';
        }
        
        $player_html .= '</div>';
        
        return $player_html;
    }
    
    /**
     * Detect video host from URL
     */
    public function detect_host($url) {
        foreach ($this->supported_hosts as $host_key => $host_info) {
            if (strpos($url, $host_info['domain']) !== false) {
                return $host_info;
            }
        }
        return false;
    }
    
    /**
     * Extract video ID from URL
     */
    public function extract_video_id($url, $host_info) {
        if (preg_match($host_info['regex'], $url, $matches)) {
            return $matches[1];
        }
        return false;
    }
    
    /**
     * Generate embed URL
     */
    public function generate_embed_url($host_info, $video_id) {
        if ($host_info['type'] === 'iframe' && !empty($host_info['embed_url'])) {
            return $host_info['embed_url'] . $video_id;
        }
        return false;
    }
    
    /**
     * AJAX handler for video embed
     */
    public function ajax_get_video_embed() {
        check_ajax_referer('torofilm_video_nonce', 'nonce');
        
        $url = sanitize_url($_POST['url']);
        $options = array(
            'title' => sanitize_text_field($_POST['title'] ?? ''),
            'poster' => sanitize_url($_POST['poster'] ?? ''),
            'autoplay' => sanitize_text_field($_POST['autoplay'] ?? 'false')
        );
        
        $player_html = $this->generate_video_player($url, $options);
        
        wp_send_json_success(array(
            'html' => $player_html,
            'host' => $this->detect_host($url)
        ));
    }
    
    /**
     * Get supported hosts list
     */
    public function get_supported_hosts() {
        return $this->supported_hosts;
    }
    
    /**
     * Check if URL is supported
     */
    public function is_supported($url) {
        return $this->detect_host($url) !== false;
    }
}

// Initialize the class
new TOROFILM_Video_Hosting();
