<?php get_header(); ?>

<div class="bd">
	<?php get_template_part( 'public/partials/template/home', 'search' ); ?>
	
	<!-- Platform Header Section -->
	<div class="platform-header-section">
		<div class="platform-header-content">
			<?php
			$platform_id = get_query_var('platform_id');
			$platforms = get_option('torofilm_platforms', array());
			$platform = isset($platforms[$platform_id]) ? $platforms[$platform_id] : null;
			
			if ($platform):
				$platform_name = $platform['name'];
				$platform_color = $platform['color'];
				$platform_logo = isset($platform['logo']) ? $platform['logo'] : '';
				$platform_icon = $platform['icon'];
				$platform_description = isset($platform['description']) ? $platform['description'] : '';
			?>
				<div class="platform-info">
					<div class="platform-logo-large">
						<?php if ($platform_logo): ?>
							<img src="<?php echo esc_url($platform_logo); ?>" alt="<?php echo esc_attr($platform_name); ?>" class="platform-logo-img">
						<?php else: ?>
							<div class="platform-icon-large" style="background: <?php echo esc_attr($platform_color); ?>">
								<i class="fa <?php echo esc_attr($platform_icon); ?>"></i>
							</div>
						<?php endif; ?>
					</div>
					<div class="platform-details">
						<h1 class="platform-title"><?php echo esc_html($platform_name); ?></h1>
						<?php if ($platform_description): ?>
							<p class="platform-description"><?php echo esc_html($platform_description); ?></p>
						<?php endif; ?>
						<div class="platform-stats">
							<?php
							// Bu platformda bulunan film ve dizi sayılarını hesapla
							$movies_count = 0;
							$series_count = 0;
							
							// Filmler
							$movies_query = new WP_Query(array(
								'post_type' => 'movies',
								'posts_per_page' => -1,
								'meta_query' => array(
									array(
										'key' => '_torofilm_platforms',
										'value' => $platform_id,
										'compare' => 'LIKE'
									)
								)
							));
							$movies_count = $movies_query->found_posts;
							
							// Diziler
							$series_query = new WP_Query(array(
								'post_type' => 'series',
								'posts_per_page' => -1,
								'meta_query' => array(
									array(
										'key' => '_torofilm_platforms',
										'value' => $platform_id,
										'compare' => 'LIKE'
									)
								)
							));
							$series_count = $series_query->found_posts;
							
							// Koleksiyonlar
							$collections_count = 0;
							$collections_query = new WP_Query(array(
								'post_type' => 'collections',
								'posts_per_page' => -1,
								'post_status' => 'publish'
							));
							
							if ($collections_query->have_posts()) {
								while ($collections_query->have_posts()) {
									$collections_query->the_post();
									$items = get_post_meta(get_the_ID(), '_collection_items', true);
									if (is_array($items)) {
										foreach ($items as $item_id) {
											$item_platforms = get_post_meta($item_id, '_torofilm_platforms', true);
											if (is_array($item_platforms) && in_array($platform_id, $item_platforms)) {
												$collections_count++;
												break; // Bu koleksiyonda en az bir içerik bu platformda, sayıyı artır ve döngüden çık
											}
										}
									}
								}
								wp_reset_postdata();
							}
							?>
							<div class="stat-item">
								<span class="stat-number"><?php echo $movies_count; ?></span>
								<span class="stat-label">Film</span>
							</div>
							<div class="stat-item">
								<span class="stat-number"><?php echo $series_count; ?></span>
								<span class="stat-label">Dizi</span>
							</div>
							<div class="stat-item">
								<span class="stat-number"><?php echo $collections_count; ?></span>
								<span class="stat-label">Koleksiyon</span>
							</div>
							<div class="stat-item">
								<span class="stat-number"><?php echo $movies_count + $series_count; ?></span>
								<span class="stat-label">Toplam İçerik</span>
							</div>
						</div>
						<?php if (current_user_can('manage_options')): ?>
					</div>
				</div>
			<?php else: ?>
				<div class="platform-not-found">
					<h1>Platform Bulunamadı</h1>
					<p>Aradığınız platform bulunamadı.</p>
					<a href="<?php echo home_url('/'); ?>" class="btn btn-primary">Ana Sayfaya Dön</a>
				</div>
			<?php endif; ?>
		</div>
		<div class="platform-header-background">
			<div class="platform-header-overlay"></div>
		</div>
	</div>

	<div class="dfxc">
		<main class="main-site">
			<?php if ($platform): ?>
				<!-- Platform Filmleri Section -->
				<section class="section platform-movies-section">
					<header class="section-header">
						<div class="rw alg-cr jst-sb">
							<h2 class="section-title">
								<i class="fa fa-film"></i>
								<?php echo esc_html($platform_name); ?> Filmleri
							</h2>
							<a href="<?php echo home_url('/movies/?platform=' . $platform_id); ?>" class="btn lnk more">Tümünü Gör <i class="fa fa-arrow-right"></i></a>
						</div>
					</header>
					<div class="movies-grid">
						<?php
						$movies_query = new WP_Query(array(
							'post_type' => 'movies',
							'posts_per_page' => 12,
							'meta_query' => array(
								array(
									'key' => '_torofilm_platforms',
									'value' => $platform_id,
									'compare' => 'LIKE'
								)
							)
						));
						
						if ($movies_query->have_posts()) :
							while ($movies_query->have_posts()) : $movies_query->the_post();
								$poster_hotlink = get_post_meta(get_the_ID(), 'poster_hotlink', true);
								$poster_field = get_post_meta(get_the_ID(), 'field_poster', true);
								$year = get_post_meta(get_the_ID(), 'field_release_year', true);
								$rating = get_post_meta(get_the_ID(), 'rating', true);
								
								// Poster URL'sini belirle
								$poster_url = '';
								if ($poster_field) {
									$poster_url = wp_get_attachment_image_src($poster_field, 'medium')[0];
								} elseif ($poster_hotlink) {
									if (filter_var($poster_hotlink, FILTER_VALIDATE_URL) === FALSE) {
										$poster_url = '//image.tmdb.org/t/p/w342' . $poster_hotlink;
									} else {
										$poster_url = $poster_hotlink;
									}
								}
								?>
								<div class="movie-card">
									<div class="movie-poster">
										<?php if ($poster_url): ?>
											<img src="<?php echo esc_url($poster_url); ?>" alt="<?php the_title(); ?>" loading="lazy">
										<?php else: ?>
											<div class="no-poster">
												<i class="fa fa-film"></i>
											</div>
										<?php endif; ?>
										<div class="movie-overlay">
											<div class="movie-info">
												<h3><?php the_title(); ?></h3>
												<div class="movie-meta">
													<?php if ($year) echo '<span class="year">' . $year . '</span>'; ?>
													<?php if ($rating) echo '<span class="rating">' . $rating . '</span>'; ?>
												</div>
											</div>
										</div>
									</div>
									<a href="<?php the_permalink(); ?>" class="lnk-blk"></a>
								</div>
							<?php 
							endwhile;
						else:
							echo '<p>Bu platformda henüz film bulunmuyor.</p>';
						endif;
						wp_reset_query(); ?>
					</div>
				</section>

				<!-- Platform Dizileri Section -->
				<section class="section platform-series-section">
					<header class="section-header">
						<div class="rw alg-cr jst-sb">
							<h2 class="section-title">
								<i class="fa fa-tv"></i>
								<?php echo esc_html($platform_name); ?> Dizileri
							</h2>
							<a href="<?php echo home_url('/series/?platform=' . $platform_id); ?>" class="btn lnk more">Tümünü Gör <i class="fa fa-arrow-right"></i></a>
						</div>
					</header>
					<div class="movies-grid">
						<?php
						$series_query = new WP_Query(array(
							'post_type' => 'series',
							'posts_per_page' => 12,
							'meta_query' => array(
								array(
									'key' => '_torofilm_platforms',
									'value' => $platform_id,
									'compare' => 'LIKE'
								)
							)
						));
						
						if ($series_query->have_posts()) :
							while ($series_query->have_posts()) : $series_query->the_post();
								$poster_hotlink = get_post_meta(get_the_ID(), 'poster_hotlink', true);
								$poster_field = get_post_meta(get_the_ID(), 'field_poster', true);
								$year = get_post_meta(get_the_ID(), 'field_release_year', true);
								$rating = get_post_meta(get_the_ID(), 'rating', true);
								
								// Poster URL'sini belirle
								$poster_url = '';
								if ($poster_field) {
									$poster_url = wp_get_attachment_image_src($poster_field, 'medium')[0];
								} elseif ($poster_hotlink) {
									if (filter_var($poster_hotlink, FILTER_VALIDATE_URL) === FALSE) {
										$poster_url = '//image.tmdb.org/t/p/w342' . $poster_hotlink;
									} else {
										$poster_url = $poster_hotlink;
									}
								}
								?>
								<div class="movie-card">
									<div class="movie-poster">
										<?php if ($poster_url): ?>
											<img src="<?php echo esc_url($poster_url); ?>" alt="<?php the_title(); ?>" loading="lazy">
										<?php else: ?>
											<div class="no-poster">
												<i class="fa fa-tv"></i>
											</div>
										<?php endif; ?>
										<div class="movie-overlay">
											<div class="movie-info">
												<h3><?php the_title(); ?></h3>
												<div class="movie-meta">
													<?php if ($year) echo '<span class="year">' . $year . '</span>'; ?>
													<?php if ($rating) echo '<span class="rating">' . $rating . '</span>'; ?>
												</div>
											</div>
										</div>
									</div>
									<a href="<?php the_permalink(); ?>" class="lnk-blk"></a>
								</div>
							<?php 
							endwhile;
						else:
							echo '<p>Bu platformda henüz dizi bulunmuyor.</p>';
						endif;
						wp_reset_query(); ?>
					</div>
				</section>

				<!-- Platform Koleksiyonları Section -->
				<section class="section platform-collections-section">
					<header class="section-header">
						<div class="rw alg-cr jst-sb">
							<h2 class="section-title">
								<i class="fa fa-folder-open"></i>
								<?php echo esc_html($platform_name); ?> Koleksiyonları
							</h2>
							<a href="<?php echo get_post_type_archive_link('collections'); ?>" class="btn lnk more">Tümünü Gör <i class="fa fa-arrow-right"></i></a>
						</div>
					</header>
					<div class="collections-grid">
						<?php
						// Bu platformla ilgili koleksiyonları bul
						$collections_query = new WP_Query(array(
							'post_type' => 'collections',
							'posts_per_page' => 8,
							'post_status' => 'publish',
							'meta_query' => array(
								'relation' => 'OR',
								array(
									'key' => '_collection_items',
									'value' => $platform_id,
									'compare' => 'LIKE'
								)
							)
						));
						
						if ($collections_query->have_posts()) :
							while ($collections_query->have_posts()) : $collections_query->the_post();
								$collection_type = get_post_meta(get_the_ID(), '_collection_type', true);
								$is_featured = get_post_meta(get_the_ID(), '_collection_featured', true);
								$items = get_post_meta(get_the_ID(), '_collection_items', true);
								$item_count = is_array($items) ? count($items) : 0;
								
								// Bu koleksiyonda bu platformdan kaç içerik var kontrol et
								$platform_items_count = 0;
								if (is_array($items)) {
									foreach ($items as $item_id) {
										$item_platforms = get_post_meta($item_id, '_torofilm_platforms', true);
										if (is_array($item_platforms) && in_array($platform_id, $item_platforms)) {
											$platform_items_count++;
										}
									}
								}
								
								// Eğer bu platformdan hiç içerik yoksa koleksiyonu gösterme
								if ($platform_items_count == 0) continue;
								?>
								<div class="collection-card">
									<div class="collection-poster">
										<a href="<?php the_permalink(); ?>">
											<?php if (has_post_thumbnail()) : ?>
												<?php the_post_thumbnail('medium'); ?>
											<?php else : ?>
												<img src="<?php echo TOROFILM_DIR_URI . 'public/img/cnt/dvr300.png'; ?>" alt="<?php the_title(); ?>" />
											<?php endif; ?>
											
											<div class="collection-overlay">
												<div class="collection-info">
													<h3><?php the_title(); ?></h3>
													<div class="collection-meta">
														<span class="items-count">
															<i class="fa fa-film"></i>
															<?php echo $platform_items_count . ' ' . ($platform_items_count == 1 ? __('İçerik', 'torofilm') : __('İçerik', 'torofilm')); ?>
														</span>
														<span class="collection-date">
															<i class="fa fa-calendar"></i>
															<?php echo get_the_date('d.m.Y'); ?>
														</span>
													</div>
												</div>
											</div>
											
											<?php if ($is_featured) : ?>
											<div class="collection-badge">
												<i class="fa fa-star"></i>
												<?php _e('Öne Çıkan', 'torofilm'); ?>
											</div>
											<?php endif; ?>
										</a>
									</div>
									<div class="collection-content">
										<h3 class="collection-title">
											<a href="<?php the_permalink(); ?>">
												<?php the_title(); ?>
											</a>
										</h3>
										<div class="collection-description">
											<p><?php echo wp_trim_words(get_the_excerpt(), 15); ?></p>
										</div>
										<div class="collection-stats">
											<span class="stat-item">
												<i class="fa fa-film"></i>
												<?php echo $platform_items_count . ' ' . ($platform_items_count == 1 ? __('İçerik', 'torofilm') : __('İçerik', 'torofilm')); ?>
											</span>
											<?php if ($collection_type && $collection_type != 'mixed') : ?>
											<span class="stat-item">
												<i class="fa fa-tag"></i>
												<?php echo $collection_type == 'movies' ? __('Filmler', 'torofilm') : __('Diziler', 'torofilm'); ?>
											</span>
											<?php endif; ?>
										</div>
									</div>
								</div>
							<?php 
							endwhile;
						else:
							echo '<div class="no-collections">';
							echo '<div class="no-collections-icon"><i class="fa fa-folder-open"></i></div>';
							echo '<h3>' . __('Henüz koleksiyon bulunmuyor', 'torofilm') . '</h3>';
							echo '<p>' . __('Bu platform için özel koleksiyonlar yakında eklenecek!', 'torofilm') . '</p>';
							echo '</div>';
						endif;
						wp_reset_query(); ?>
					</div>
				</section>
			<?php endif; ?>
		</main>
		<?php get_sidebar(); ?>
	</div>
</div>




<?php get_footer(); ?>
