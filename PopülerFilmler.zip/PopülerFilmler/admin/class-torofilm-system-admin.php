<?php
/**
 * Torofilm System Tools Admin
 * 
 * @package Torofilm
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class TOROFILM_System_Admin {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_action('wp_ajax_clear_cache', array($this, 'ajax_clear_cache'));
        add_action('wp_ajax_optimize_database', array($this, 'ajax_optimize_database'));
        add_action('wp_ajax_create_backup', array($this, 'ajax_create_backup'));
        add_action('wp_ajax_restore_backup', array($this, 'ajax_restore_backup'));
        add_action('wp_ajax_system_info', array($this, 'ajax_system_info'));
        add_action('wp_ajax_cleanup_files', array($this, 'ajax_cleanup_files'));
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        // Menü ana stats sınıfında eklendi
        // Bu sınıf sadece sayfa içeriğini sağlar
    }
    
    /**
     * Enqueue admin scripts
     */
    public function enqueue_admin_scripts($hook) {
        if ($hook !== 'statistics_page_torofilm-system') {
            return;
        }
        
        wp_enqueue_style('torofilm-system-admin', get_template_directory_uri() . '/admin/css/system-admin.css', array(), TOROFILM_VERSION);
        wp_enqueue_script('torofilm-system-admin', get_template_directory_uri() . '/admin/js/system-admin.js', array('jquery'), TOROFILM_VERSION, true);
        
        wp_localize_script('torofilm-system-admin', 'torofilm_system', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('torofilm_system_nonce')
        ));
    }
    
    /**
     * Admin page
     */
    public function admin_page() {
        ?>
        <div class="wrap">
            <h1>Sistem Araçları</h1>
            <p class="description">Sistem performansını optimize edin ve bakım işlemlerini gerçekleştirin.</p>
            
            <div class="system-container">
                <!-- System Status -->
                <div class="system-section">
                    <h2>📊 Sistem Durumu</h2>
                    <div class="status-grid">
                        <div class="status-card">
                            <div class="status-icon">💾</div>
                            <div class="status-content">
                                <h3>Veritabanı Boyutu</h3>
                                <div class="status-value" id="db-size">-</div>
                                <div class="status-detail" id="db-detail">-</div>
                            </div>
                        </div>
                        
                        <div class="status-card">
                            <div class="status-icon">📁</div>
                            <div class="status-content">
                                <h3>Dosya Boyutu</h3>
                                <div class="status-value" id="file-size">-</div>
                                <div class="status-detail" id="file-detail">-</div>
                            </div>
                        </div>
                        
                        <div class="status-card">
                            <div class="status-icon">⚡</div>
                            <div class="status-content">
                                <h3>PHP Versiyonu</h3>
                                <div class="status-value" id="php-version">-</div>
                                <div class="status-detail" id="php-detail">-</div>
                            </div>
                        </div>
                        
                        <div class="status-card">
                            <div class="status-icon">🔧</div>
                            <div class="status-content">
                                <h3>WordPress</h3>
                                <div class="status-value" id="wp-version">-</div>
                                <div class="status-detail" id="wp-detail">-</div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Cache Management -->
                <div class="system-section">
                    <h2>🗂️ Cache Yönetimi</h2>
                    <div class="cache-section">
                        <div class="cache-info">
                            <p>Cache dosyalarını temizleyerek site performansını artırın.</p>
                        </div>
                        
                        <div class="cache-actions">
                            <button type="button" id="clear-cache-btn" class="button button-primary">
                                <i class="fa fa-trash"></i> Cache Temizle
                            </button>
                            
                            <button type="button" id="clear-transients-btn" class="button button-secondary">
                                <i class="fa fa-clock"></i> Transients Temizle
                            </button>
                            
                            <button type="button" id="clear-uploads-btn" class="button button-secondary">
                                <i class="fa fa-image"></i> Kullanılmayan Medya
                            </button>
                        </div>
                        
                        <div class="cache-progress" id="cache-progress" style="display: none;">
                            <div class="progress-bar">
                                <div class="progress-fill" id="cache-progress-fill"></div>
                            </div>
                            <div class="progress-text" id="cache-progress-text">0%</div>
                        </div>
                    </div>
                </div>
                
                <!-- Database Optimization -->
                <div class="system-section">
                    <h2>🗄️ Veritabanı Optimizasyonu</h2>
                    <div class="db-section">
                        <div class="db-info">
                            <p>Veritabanını optimize ederek performansı artırın.</p>
                        </div>
                        
                        <div class="db-actions">
                            <button type="button" id="optimize-db-btn" class="button button-primary">
                                <i class="fa fa-database"></i> Veritabanını Optimize Et
                            </button>
                            
                            <button type="button" id="repair-db-btn" class="button button-secondary">
                                <i class="fa fa-wrench"></i> Veritabanını Onar
                            </button>
                            
                            <button type="button" id="cleanup-db-btn" class="button button-secondary">
                                <i class="fa fa-broom"></i> Gereksiz Verileri Temizle
                            </button>
                        </div>
                        
                        <div class="db-progress" id="db-progress" style="display: none;">
                            <div class="progress-bar">
                                <div class="progress-fill" id="db-progress-fill"></div>
                            </div>
                            <div class="progress-text" id="db-progress-text">0%</div>
                        </div>
                    </div>
                </div>
                
                <!-- Backup & Restore -->
                <div class="system-section">
                    <h2>💾 Yedekleme & Geri Yükleme</h2>
                    <div class="backup-section">
                        <div class="backup-actions">
                            <div class="backup-create">
                                <h3>Yedek Oluştur</h3>
                                <div class="form-group">
                                    <label for="backup-type">Yedek Türü:</label>
                                    <select id="backup-type" class="regular-text">
                                        <option value="full">Tam Yedek</option>
                                        <option value="database">Sadece Veritabanı</option>
                                        <option value="files">Sadece Dosyalar</option>
                                    </select>
                                </div>
                                
                                <button type="button" id="create-backup-btn" class="button button-primary">
                                    <i class="fa fa-download"></i> Yedek Oluştur
                                </button>
                            </div>
                            
                            <div class="backup-restore">
                                <h3>Yedek Geri Yükle</h3>
                                <div class="form-group">
                                    <label for="backup-file">Yedek Dosyası:</label>
                                    <input type="file" id="backup-file" accept=".zip,.sql" class="regular-text" />
                                </div>
                                
                                <button type="button" id="restore-backup-btn" class="button button-secondary">
                                    <i class="fa fa-upload"></i> Geri Yükle
                                </button>
                            </div>
                        </div>
                        
                        <div class="backup-list">
                            <h3>Mevcut Yedekler</h3>
                            <div class="backup-items" id="backup-items">
                                <div class="loading">Yedekler yükleniyor...</div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- System Information -->
                <div class="system-section">
                    <h2>ℹ️ Sistem Bilgileri</h2>
                    <div class="info-section">
                        <div class="info-tabs">
                            <button class="tab-btn active" data-tab="server-info">Sunucu Bilgileri</button>
                            <button class="tab-btn" data-tab="wp-info">WordPress Bilgileri</button>
                            <button class="tab-btn" data-tab="theme-info">Tema Bilgileri</button>
                        </div>
                        
                        <div class="tab-content active" id="server-info">
                            <div class="info-content" id="server-info-content">
                                <div class="loading">Bilgiler yükleniyor...</div>
                            </div>
                        </div>
                        
                        <div class="tab-content" id="wp-info">
                            <div class="info-content" id="wp-info-content">
                                <div class="loading">Bilgiler yükleniyor...</div>
                            </div>
                        </div>
                        
                        <div class="tab-content" id="theme-info">
                            <div class="info-content" id="theme-info-content">
                                <div class="loading">Bilgiler yükleniyor...</div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- File Cleanup -->
                <div class="system-section">
                    <h2>🧹 Dosya Temizliği</h2>
                    <div class="cleanup-section">
                        <div class="cleanup-actions">
                            <button type="button" id="cleanup-files-btn" class="button button-primary">
                                <i class="fa fa-broom"></i> Dosyaları Temizle
                            </button>
                            
                            <button type="button" id="scan-files-btn" class="button button-secondary">
                                <i class="fa fa-search"></i> Dosyaları Tara
                            </button>
                        </div>
                        
                        <div class="cleanup-results" id="cleanup-results" style="display: none;">
                            <h3>Temizlik Sonuçları</h3>
                            <div class="results-content" id="cleanup-results-content"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * AJAX clear cache
     */
    public function ajax_clear_cache() {
        check_ajax_referer('torofilm_system_nonce', 'nonce');
        
        $results = array(
            'cache_cleared' => false,
            'transients_cleared' => false,
            'uploads_cleared' => false,
            'files_removed' => 0,
            'size_freed' => 0
        );
        
        // Clear WordPress cache
        if (function_exists('wp_cache_flush')) {
            wp_cache_flush();
            $results['cache_cleared'] = true;
        }
        
        // Clear transients
        global $wpdb;
        $transients = $wpdb->get_results("SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE '_transient_%'");
        foreach ($transients as $transient) {
            delete_option($transient->option_name);
        }
        $results['transients_cleared'] = true;
        
        // Clear unused uploads
        $uploads_dir = wp_upload_dir();
        $unused_files = $this->find_unused_uploads($uploads_dir['basedir']);
        foreach ($unused_files as $file) {
            if (file_exists($file)) {
                $results['size_freed'] += filesize($file);
                unlink($file);
                $results['files_removed']++;
            }
        }
        $results['uploads_cleared'] = true;
        
        wp_send_json_success($results);
    }
    
    /**
     * AJAX optimize database
     */
    public function ajax_optimize_database() {
        check_ajax_referer('torofilm_system_nonce', 'nonce');
        
        global $wpdb;
        
        $results = array(
            'tables_optimized' => 0,
            'tables_repaired' => 0,
            'space_freed' => 0
        );
        
        // Get all tables
        $tables = $wpdb->get_results("SHOW TABLES", ARRAY_N);
        
        foreach ($tables as $table) {
            $table_name = $table[0];
            
            // Optimize table
            $wpdb->query("OPTIMIZE TABLE `{$table_name}`");
            $results['tables_optimized']++;
            
            // Repair table if needed
            $check = $wpdb->get_row("CHECK TABLE `{$table_name}`");
            if ($check && $check->Msg_text !== 'OK') {
                $wpdb->query("REPAIR TABLE `{$table_name}`");
                $results['tables_repaired']++;
            }
        }
        
        // Clean up orphaned data
        $this->cleanup_orphaned_data();
        
        wp_send_json_success($results);
    }
    
    /**
     * AJAX create backup
     */
    public function ajax_create_backup() {
        check_ajax_referer('torofilm_system_nonce', 'nonce');
        
        $type = sanitize_text_field($_POST['type']);
        $backup_file = $this->create_backup($type);
        
        if ($backup_file) {
            wp_send_json_success(array(
                'backup_file' => $backup_file,
                'size' => filesize($backup_file)
            ));
        } else {
            wp_send_json_error('Yedek oluşturulamadı');
        }
    }
    
    /**
     * AJAX restore backup
     */
    public function ajax_restore_backup() {
        check_ajax_referer('torofilm_system_nonce', 'nonce');
        
        if (!isset($_FILES['backup_file'])) {
            wp_send_json_error('Yedek dosyası bulunamadı');
        }
        
        $file = $_FILES['backup_file'];
        $result = $this->restore_backup($file['tmp_name']);
        
        if ($result) {
            wp_send_json_success('Yedek başarıyla geri yüklendi');
        } else {
            wp_send_json_error('Yedek geri yüklenemedi');
        }
    }
    
    /**
     * AJAX system info
     */
    public function ajax_system_info() {
        check_ajax_referer('torofilm_system_nonce', 'nonce');
        
        $type = sanitize_text_field($_POST['type']);
        
        switch ($type) {
            case 'server':
                $info = $this->get_server_info();
                break;
            case 'wordpress':
                $info = $this->get_wordpress_info();
                break;
            case 'theme':
                $info = $this->get_theme_info();
                break;
            default:
                $info = array();
        }
        
        wp_send_json_success($info);
    }
    
    /**
     * AJAX cleanup files
     */
    public function ajax_cleanup_files() {
        check_ajax_referer('torofilm_system_nonce', 'nonce');
        
        $results = $this->cleanup_files();
        
        wp_send_json_success($results);
    }
    
    /**
     * Find unused uploads
     */
    private function find_unused_uploads($uploads_dir) {
        $unused_files = array();
        $files = glob($uploads_dir . '/*');
        
        foreach ($files as $file) {
            if (is_file($file)) {
                $filename = basename($file);
                $attachment = get_posts(array(
                    'post_type' => 'attachment',
                    'post_status' => 'inherit',
                    'meta_query' => array(
                        array(
                            'key' => '_wp_attached_file',
                            'value' => $filename,
                            'compare' => 'LIKE'
                        )
                    )
                ));
                
                if (empty($attachment)) {
                    $unused_files[] = $file;
                }
            }
        }
        
        return $unused_files;
    }
    
    /**
     * Cleanup orphaned data
     */
    private function cleanup_orphaned_data() {
        global $wpdb;
        
        // Clean orphaned post meta
        $wpdb->query("
            DELETE pm FROM {$wpdb->postmeta} pm
            LEFT JOIN {$wpdb->posts} p ON pm.post_id = p.ID
            WHERE p.ID IS NULL
        ");
        
        // Clean orphaned comment meta
        $wpdb->query("
            DELETE cm FROM {$wpdb->commentmeta} cm
            LEFT JOIN {$wpdb->comments} c ON cm.comment_id = c.comment_ID
            WHERE c.comment_ID IS NULL
        ");
        
        // Clean orphaned user meta
        $wpdb->query("
            DELETE um FROM {$wpdb->usermeta} um
            LEFT JOIN {$wpdb->users} u ON um.user_id = u.ID
            WHERE u.ID IS NULL
        ");
    }
    
    /**
     * Create backup
     */
    private function create_backup($type) {
        $backup_dir = WP_CONTENT_DIR . '/backups/';
        if (!file_exists($backup_dir)) {
            wp_mkdir_p($backup_dir);
        }
        
        $filename = 'backup_' . $type . '_' . date('Y-m-d_H-i-s') . '.zip';
        $backup_file = $backup_dir . $filename;
        
        $zip = new ZipArchive();
        if ($zip->open($backup_file, ZipArchive::CREATE) !== TRUE) {
            return false;
        }
        
        switch ($type) {
            case 'full':
                $this->backup_database($zip);
                $this->backup_files($zip);
                break;
            case 'database':
                $this->backup_database($zip);
                break;
            case 'files':
                $this->backup_files($zip);
                break;
        }
        
        $zip->close();
        
        return $backup_file;
    }
    
    /**
     * Backup database
     */
    private function backup_database($zip) {
        global $wpdb;
        
        $tables = $wpdb->get_results("SHOW TABLES", ARRAY_N);
        $sql = '';
        
        foreach ($tables as $table) {
            $table_name = $table[0];
            $sql .= "DROP TABLE IF EXISTS `{$table_name}`;\n";
            
            $create_table = $wpdb->get_row("SHOW CREATE TABLE `{$table_name}`", ARRAY_N);
            $sql .= $create_table[1] . ";\n\n";
            
            $rows = $wpdb->get_results("SELECT * FROM `{$table_name}`", ARRAY_A);
            foreach ($rows as $row) {
                $values = array_map(array($wpdb, 'prepare'), array_fill(0, count($row), '%s'), $row);
                $sql .= "INSERT INTO `{$table_name}` VALUES (" . implode(',', $values) . ");\n";
            }
            $sql .= "\n";
        }
        
        $zip->addFromString('database.sql', $sql);
    }
    
    /**
     * Backup files
     */
    private function backup_files($zip) {
        $this->add_directory_to_zip($zip, ABSPATH, 'wordpress/');
    }
    
    /**
     * Add directory to zip
     */
    private function add_directory_to_zip($zip, $dir, $zip_path) {
        $files = glob($dir . '*');
        
        foreach ($files as $file) {
            if (is_dir($file)) {
                $this->add_directory_to_zip($zip, $file . '/', $zip_path . basename($file) . '/');
            } else {
                $zip->addFile($file, $zip_path . basename($file));
            }
        }
    }
    
    /**
     * Restore backup
     */
    private function restore_backup($backup_file) {
        $zip = new ZipArchive();
        if ($zip->open($backup_file) !== TRUE) {
            return false;
        }
        
        // Extract to temporary directory
        $temp_dir = sys_get_temp_dir() . '/backup_restore_' . time();
        $zip->extractTo($temp_dir);
        $zip->close();
        
        // Restore database if exists
        if (file_exists($temp_dir . '/database.sql')) {
            $this->restore_database($temp_dir . '/database.sql');
        }
        
        // Restore files if exists
        if (is_dir($temp_dir . '/wordpress')) {
            $this->restore_files($temp_dir . '/wordpress');
        }
        
        // Clean up
        $this->remove_directory($temp_dir);
        
        return true;
    }
    
    /**
     * Restore database
     */
    private function restore_database($sql_file) {
        global $wpdb;
        
        $sql = file_get_contents($sql_file);
        $queries = explode(';', $sql);
        
        foreach ($queries as $query) {
            $query = trim($query);
            if (!empty($query)) {
                $wpdb->query($query);
            }
        }
    }
    
    /**
     * Restore files
     */
    private function restore_files($source_dir) {
        $this->copy_directory($source_dir, ABSPATH);
    }
    
    /**
     * Copy directory
     */
    private function copy_directory($source, $destination) {
        if (!is_dir($destination)) {
            mkdir($destination, 0755, true);
        }
        
        $files = glob($source . '/*');
        
        foreach ($files as $file) {
            if (is_dir($file)) {
                $this->copy_directory($file, $destination . '/' . basename($file));
            } else {
                copy($file, $destination . '/' . basename($file));
            }
        }
    }
    
    /**
     * Remove directory
     */
    private function remove_directory($dir) {
        $files = glob($dir . '/*');
        
        foreach ($files as $file) {
            if (is_dir($file)) {
                $this->remove_directory($file);
            } else {
                unlink($file);
            }
        }
        
        rmdir($dir);
    }
    
    /**
     * Get server info
     */
    private function get_server_info() {
        return array(
            'PHP Version' => PHP_VERSION,
            'Server Software' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
            'MySQL Version' => $GLOBALS['wpdb']->db_version(),
            'Memory Limit' => ini_get('memory_limit'),
            'Max Execution Time' => ini_get('max_execution_time'),
            'Upload Max Size' => ini_get('upload_max_filesize'),
            'Post Max Size' => ini_get('post_max_size'),
            'Max Input Vars' => ini_get('max_input_vars'),
            'Server Time' => date('Y-m-d H:i:s'),
            'Timezone' => date_default_timezone_get()
        );
    }
    
    /**
     * Get WordPress info
     */
    private function get_wordpress_info() {
        global $wp_version;
        
        return array(
            'WordPress Version' => $wp_version,
            'Site URL' => get_site_url(),
            'Admin Email' => get_option('admin_email'),
            'Language' => get_locale(),
            'Timezone' => get_option('timezone_string'),
            'Date Format' => get_option('date_format'),
            'Time Format' => get_option('time_format'),
            'Users Count' => count_users()['total_users'],
            'Posts Count' => wp_count_posts()->publish,
            'Pages Count' => wp_count_posts('page')->publish,
            'Comments Count' => wp_count_comments()->approved,
            'Plugins Count' => count(get_plugins()),
            'Active Theme' => wp_get_theme()->get('Name')
        );
    }
    
    /**
     * Get theme info
     */
    private function get_theme_info() {
        $theme = wp_get_theme();
        
        return array(
            'Theme Name' => $theme->get('Name'),
            'Theme Version' => $theme->get('Version'),
            'Theme Author' => $theme->get('Author'),
            'Theme Description' => $theme->get('Description'),
            'Theme URI' => $theme->get('ThemeURI'),
            'Author URI' => $theme->get('AuthorURI'),
            'Text Domain' => $theme->get('TextDomain'),
            'Template' => $theme->get('Template'),
            'Status' => $theme->get('Status'),
            'Tags' => implode(', ', $theme->get('Tags')),
            'Requires WP' => $theme->get('RequiresWP'),
            'Requires PHP' => $theme->get('RequiresPHP')
        );
    }
    
    /**
     * Cleanup files
     */
    private function cleanup_files() {
        $results = array(
            'files_removed' => 0,
            'size_freed' => 0,
            'directories_removed' => 0
        );
        
        // Clean up temporary files
        $temp_files = glob(sys_get_temp_dir() . '/*');
        foreach ($temp_files as $file) {
            if (is_file($file) && filemtime($file) < time() - 3600) { // Older than 1 hour
                $results['size_freed'] += filesize($file);
                unlink($file);
                $results['files_removed']++;
            }
        }
        
        // Clean up WordPress temp files
        $wp_temp_dir = WP_CONTENT_DIR . '/cache/';
        if (is_dir($wp_temp_dir)) {
            $this->cleanup_directory($wp_temp_dir, $results);
        }
        
        return $results;
    }
    
    /**
     * Cleanup directory
     */
    private function cleanup_directory($dir, &$results) {
        $files = glob($dir . '/*');
        
        foreach ($files as $file) {
            if (is_dir($file)) {
                $this->cleanup_directory($file, $results);
                if (count(glob($file . '/*')) === 0) {
                    rmdir($file);
                    $results['directories_removed']++;
                }
            } else {
                $results['size_freed'] += filesize($file);
                unlink($file);
                $results['files_removed']++;
            }
        }
    }
}

// Initialize
new TOROFILM_System_Admin();
