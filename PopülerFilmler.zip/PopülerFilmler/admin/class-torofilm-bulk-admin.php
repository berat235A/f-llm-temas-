<?php
/**
 * Torofilm Bulk Content Admin
 * 
 * @package Torofilm
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class TOROFILM_Bulk_Admin {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_action('wp_ajax_bulk_import_csv', array($this, 'ajax_bulk_import_csv'));
        add_action('wp_ajax_bulk_export_csv', array($this, 'ajax_bulk_export_csv'));
        add_action('wp_ajax_bulk_delete_content', array($this, 'ajax_bulk_delete_content'));
        add_action('wp_ajax_bulk_update_content', array($this, 'ajax_bulk_update_content'));
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        // Menü ana stats sınıfında eklendi
        // Bu sınıf sadece sayfa içeriğini sağlar
    }
    
    /**
     * Enqueue admin scripts
     */
    public function enqueue_admin_scripts($hook) {
        if ($hook !== 'statistics_page_torofilm-bulk') {
            return;
        }
        
        wp_enqueue_style('torofilm-bulk-admin', get_template_directory_uri() . '/admin/css/bulk-admin.css', array(), TOROFILM_VERSION);
        wp_enqueue_script('torofilm-bulk-admin', get_template_directory_uri() . '/admin/js/bulk-admin.js', array('jquery'), TOROFILM_VERSION, true);
        
        wp_localize_script('torofilm-bulk-admin', 'torofilm_bulk', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('torofilm_bulk_nonce')
        ));
    }
    
    /**
     * Admin page
     */
    public function admin_page() {
        ?>
        <div class="wrap">
            <h1>Toplu İçerik Yönetimi</h1>
            <p class="description">Toplu olarak film ve dizi ekleyin, düzenleyin veya silin.</p>
            
            <div class="bulk-container">
                <!-- CSV Import -->
                <div class="bulk-section">
                    <h2>📥 CSV İçe Aktarma</h2>
                    <div class="import-section">
                        <div class="import-form">
                            <div class="form-group">
                                <label for="import-type">İçerik Türü:</label>
                                <select id="import-type" class="regular-text">
                                    <option value="movies">Filmler</option>
                                    <option value="series">Diziler</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="csv-file">CSV Dosyası:</label>
                                <input type="file" id="csv-file" accept=".csv" class="regular-text" />
                                <p class="description">CSV formatında dosya seçin. <a href="#" id="download-template">Örnek şablon indir</a></p>
                            </div>
                            
                            <div class="form-group">
                                <label>
                                    <input type="checkbox" id="skip-duplicates" checked />
                                    Duplikatları atla
                                </label>
                            </div>
                            
                            <button type="button" id="import-btn" class="button button-primary">
                                <i class="fa fa-upload"></i> İçe Aktar
                            </button>
                        </div>
                        
                        <div class="import-progress" id="import-progress" style="display: none;">
                            <div class="progress-bar">
                                <div class="progress-fill" id="progress-fill"></div>
                            </div>
                            <div class="progress-text" id="progress-text">0%</div>
                        </div>
                        
                        <div class="import-results" id="import-results" style="display: none;">
                            <h3>İçe Aktarma Sonuçları</h3>
                            <div class="results-content" id="results-content"></div>
                        </div>
                    </div>
                </div>
                
                <!-- CSV Export -->
                <div class="bulk-section">
                    <h2>📤 CSV Dışa Aktarma</h2>
                    <div class="export-section">
                        <div class="form-group">
                            <label for="export-type">İçerik Türü:</label>
                            <select id="export-type" class="regular-text">
                                <option value="movies">Filmler</option>
                                <option value="series">Diziler</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="export-limit">Kayıt Sayısı:</label>
                            <select id="export-limit" class="regular-text">
                                <option value="100">100</option>
                                <option value="500">500</option>
                                <option value="1000">1000</option>
                                <option value="all">Tümü</option>
                            </select>
                        </div>
                        
                        <button type="button" id="export-btn" class="button button-secondary">
                            <i class="fa fa-download"></i> Dışa Aktar
                        </button>
                    </div>
                </div>
                
                <!-- Bulk Operations -->
                <div class="bulk-section">
                    <h2>🔧 Toplu İşlemler</h2>
                    <div class="bulk-operations">
                        <div class="operation-group">
                            <h3>Toplu Silme</h3>
                            <div class="form-group">
                                <label for="delete-type">İçerik Türü:</label>
                                <select id="delete-type" class="regular-text">
                                    <option value="movies">Filmler</option>
                                    <option value="series">Diziler</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="delete-criteria">Silme Kriteri:</label>
                                <select id="delete-criteria" class="regular-text">
                                    <option value="date">Tarihe Göre</option>
                                    <option value="category">Kategoriye Göre</option>
                                    <option value="rating">Rating'e Göre</option>
                                    <option value="views">Görüntülenmeye Göre</option>
                                </select>
                            </div>
                            
                            <div class="form-group" id="delete-value-group">
                                <label for="delete-value">Değer:</label>
                                <input type="text" id="delete-value" class="regular-text" placeholder="Örn: 2023-01-01" />
                            </div>
                            
                            <button type="button" id="delete-btn" class="button button-danger">
                                <i class="fa fa-trash"></i> Toplu Sil
                            </button>
                        </div>
                        
                        <div class="operation-group">
                            <h3>Toplu Güncelleme</h3>
                            <div class="form-group">
                                <label for="update-type">İçerik Türü:</label>
                                <select id="update-type" class="regular-text">
                                    <option value="movies">Filmler</option>
                                    <option value="series">Diziler</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="update-field">Güncellenecek Alan:</label>
                                <select id="update-field" class="regular-text">
                                    <option value="category">Kategori</option>
                                    <option value="status">Durum</option>
                                    <option value="featured">Öne Çıkan</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="update-value">Yeni Değer:</label>
                                <input type="text" id="update-value" class="regular-text" placeholder="Yeni değer" />
                            </div>
                            
                            <button type="button" id="update-btn" class="button button-primary">
                                <i class="fa fa-edit"></i> Toplu Güncelle
                            </button>
                        </div>
                    </div>
                </div>
                
                <!-- Content List -->
                <div class="bulk-section">
                    <h2>📋 İçerik Listesi</h2>
                    <div class="content-list-section">
                        <div class="list-filters">
                            <select id="list-type" class="regular-text">
                                <option value="movies">Filmler</option>
                                <option value="series">Diziler</option>
                            </select>
                            
                            <select id="list-limit" class="regular-text">
                                <option value="50">50</option>
                                <option value="100">100</option>
                                <option value="200">200</option>
                            </select>
                            
                            <button type="button" id="load-list-btn" class="button">
                                <i class="fa fa-refresh"></i> Listele
                            </button>
                        </div>
                        
                        <div class="content-list" id="content-list">
                            <div class="loading">Liste yükleniyor...</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * AJAX CSV import
     */
    public function ajax_bulk_import_csv() {
        check_ajax_referer('torofilm_bulk_nonce', 'nonce');
        
        if (!isset($_FILES['csv_file'])) {
            wp_send_json_error('CSV dosyası bulunamadı');
        }
        
        $file = $_FILES['csv_file'];
        $type = sanitize_text_field($_POST['type']);
        $skip_duplicates = isset($_POST['skip_duplicates']) ? true : false;
        
        if ($file['error'] !== UPLOAD_ERR_OK) {
            wp_send_json_error('Dosya yükleme hatası');
        }
        
        $csv_data = $this->parse_csv_file($file['tmp_name']);
        if (!$csv_data) {
            wp_send_json_error('CSV dosyası okunamadı');
        }
        
        $results = $this->import_content($csv_data, $type, $skip_duplicates);
        
        wp_send_json_success($results);
    }
    
    /**
     * AJAX CSV export
     */
    public function ajax_bulk_export_csv() {
        check_ajax_referer('torofilm_bulk_nonce', 'nonce');
        
        $type = sanitize_text_field($_POST['type']);
        $limit = sanitize_text_field($_POST['limit']);
        
        $csv_data = $this->export_content($type, $limit);
        
        if (!$csv_data) {
            wp_send_json_error('Dışa aktarma başarısız');
        }
        
        $filename = $type . '_export_' . date('Y-m-d_H-i-s') . '.csv';
        
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        
        echo $csv_data;
        exit;
    }
    
    /**
     * AJAX bulk delete
     */
    public function ajax_bulk_delete_content() {
        check_ajax_referer('torofilm_bulk_nonce', 'nonce');
        
        $type = sanitize_text_field($_POST['type']);
        $criteria = sanitize_text_field($_POST['criteria']);
        $value = sanitize_text_field($_POST['value']);
        
        $results = $this->bulk_delete_content($type, $criteria, $value);
        
        wp_send_json_success($results);
    }
    
    /**
     * AJAX bulk update
     */
    public function ajax_bulk_update_content() {
        check_ajax_referer('torofilm_bulk_nonce', 'nonce');
        
        $type = sanitize_text_field($_POST['type']);
        $field = sanitize_text_field($_POST['field']);
        $value = sanitize_text_field($_POST['value']);
        
        $results = $this->bulk_update_content($type, $field, $value);
        
        wp_send_json_success($results);
    }
    
    /**
     * Parse CSV file
     */
    private function parse_csv_file($file_path) {
        $data = array();
        $handle = fopen($file_path, 'r');
        
        if (!$handle) {
            return false;
        }
        
        $headers = fgetcsv($handle);
        if (!$headers) {
            fclose($handle);
            return false;
        }
        
        while (($row = fgetcsv($handle)) !== false) {
            $data[] = array_combine($headers, $row);
        }
        
        fclose($handle);
        return $data;
    }
    
    /**
     * Import content
     */
    private function import_content($data, $type, $skip_duplicates) {
        $results = array(
            'success' => 0,
            'failed' => 0,
            'skipped' => 0,
            'errors' => array()
        );
        
        foreach ($data as $index => $row) {
            try {
                // Check for duplicates
                if ($skip_duplicates) {
                    $existing = get_posts(array(
                        'post_type' => $type,
                        'post_title' => $row['title'],
                        'post_status' => 'publish',
                        'posts_per_page' => 1
                    ));
                    
                    if (!empty($existing)) {
                        $results['skipped']++;
                        continue;
                    }
                }
                
                // Create post
                $post_data = array(
                    'post_title' => sanitize_text_field($row['title']),
                    'post_content' => wp_kses_post($row['content']),
                    'post_type' => $type,
                    'post_status' => 'publish',
                    'post_date' => isset($row['date']) ? $row['date'] : current_time('mysql')
                );
                
                $post_id = wp_insert_post($post_data);
                
                if ($post_id) {
                    // Add meta fields
                    $meta_fields = array(
                        'movie_rating' => 'rating',
                        'movie_year' => 'year',
                        'movie_duration' => 'duration',
                        'movie_director' => 'director',
                        'movie_cast' => 'cast',
                        'movie_genre' => 'genre',
                        'movie_country' => 'country',
                        'movie_language' => 'language',
                        'movie_imdb' => 'imdb',
                        'movie_trailer' => 'trailer'
                    );
                    
                    foreach ($meta_fields as $meta_key => $csv_key) {
                        if (isset($row[$csv_key])) {
                            update_post_meta($post_id, $meta_key, sanitize_text_field($row[$csv_key]));
                        }
                    }
                    
                    // Set featured image
                    if (isset($row['image_url']) && !empty($row['image_url'])) {
                        $this->set_featured_image($post_id, $row['image_url']);
                    }
                    
                    $results['success']++;
                } else {
                    $results['failed']++;
                    $results['errors'][] = "Satır " . ($index + 1) . ": Post oluşturulamadı";
                }
                
            } catch (Exception $e) {
                $results['failed']++;
                $results['errors'][] = "Satır " . ($index + 1) . ": " . $e->getMessage();
            }
        }
        
        return $results;
    }
    
    /**
     * Export content
     */
    private function export_content($type, $limit) {
        $args = array(
            'post_type' => $type,
            'post_status' => 'publish',
            'posts_per_page' => $limit === 'all' ? -1 : intval($limit)
        );
        
        $posts = get_posts($args);
        
        $csv_data = "title,content,date,rating,year,duration,director,cast,genre,country,language,imdb,trailer,image_url\n";
        
        foreach ($posts as $post) {
            $meta = get_post_meta($post->ID);
            
            $row = array(
                $post->post_title,
                $post->post_content,
                $post->post_date,
                $meta['movie_rating'][0] ?? '',
                $meta['movie_year'][0] ?? '',
                $meta['movie_duration'][0] ?? '',
                $meta['movie_director'][0] ?? '',
                $meta['movie_cast'][0] ?? '',
                $meta['movie_genre'][0] ?? '',
                $meta['movie_country'][0] ?? '',
                $meta['movie_language'][0] ?? '',
                $meta['movie_imdb'][0] ?? '',
                $meta['movie_trailer'][0] ?? '',
                get_the_post_thumbnail_url($post->ID, 'full') ?: ''
            );
            
            $csv_data .= '"' . implode('","', array_map('str_replace', array_fill(0, count($row), '"'), array_fill(0, count($row), '""'), $row)) . '"' . "\n";
        }
        
        return $csv_data;
    }
    
    /**
     * Bulk delete content
     */
    private function bulk_delete_content($type, $criteria, $value) {
        $args = array(
            'post_type' => $type,
            'post_status' => 'publish',
            'posts_per_page' => -1
        );
        
        // Add criteria
        switch ($criteria) {
            case 'date':
                $args['date_query'] = array(
                    array(
                        'before' => $value,
                        'inclusive' => true
                    )
                );
                break;
            case 'category':
                $args['tax_query'] = array(
                    array(
                        'taxonomy' => 'movie_category',
                        'field' => 'slug',
                        'terms' => $value
                    )
                );
                break;
            case 'rating':
                $args['meta_query'] = array(
                    array(
                        'key' => 'movie_rating',
                        'value' => $value,
                        'compare' => '<'
                    )
                );
                break;
            case 'views':
                $args['meta_query'] = array(
                    array(
                        'key' => 'post_views_count',
                        'value' => $value,
                        'compare' => '<'
                    )
                );
                break;
        }
        
        $posts = get_posts($args);
        $deleted = 0;
        
        foreach ($posts as $post) {
            if (wp_delete_post($post->ID, true)) {
                $deleted++;
            }
        }
        
        return array(
            'deleted' => $deleted,
            'total' => count($posts)
        );
    }
    
    /**
     * Bulk update content
     */
    private function bulk_update_content($type, $field, $value) {
        $args = array(
            'post_type' => $type,
            'post_status' => 'publish',
            'posts_per_page' => -1
        );
        
        $posts = get_posts($args);
        $updated = 0;
        
        foreach ($posts as $post) {
            switch ($field) {
                case 'category':
                    wp_set_post_terms($post->ID, $value, 'movie_category');
                    break;
                case 'status':
                    wp_update_post(array(
                        'ID' => $post->ID,
                        'post_status' => $value
                    ));
                    break;
                case 'featured':
                    update_post_meta($post->ID, 'featured', $value);
                    break;
            }
            $updated++;
        }
        
        return array(
            'updated' => $updated,
            'total' => count($posts)
        );
    }
    
    /**
     * Set featured image from URL
     */
    private function set_featured_image($post_id, $image_url) {
        $upload_dir = wp_upload_dir();
        $image_data = file_get_contents($image_url);
        $filename = basename($image_url);
        $file = $upload_dir['path'] . '/' . $filename;
        
        file_put_contents($file, $image_data);
        
        $wp_filetype = wp_check_filetype($filename, null);
        $attachment = array(
            'post_mime_type' => $wp_filetype['type'],
            'post_title' => sanitize_file_name($filename),
            'post_content' => '',
            'post_status' => 'inherit'
        );
        
        $attach_id = wp_insert_attachment($attachment, $file, $post_id);
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        $attach_data = wp_generate_attachment_metadata($attach_id, $file);
        wp_update_attachment_metadata($attach_id, $attach_data);
        
        set_post_thumbnail($post_id, $attach_id);
    }
}

// Initialize
new TOROFILM_Bulk_Admin();