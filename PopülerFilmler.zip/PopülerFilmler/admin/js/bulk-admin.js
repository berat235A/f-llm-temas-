jQuery(document).ready(function($) {
    'use strict';
    
    let importProgress = 0;
    let isImporting = false;
    
    // Initialize
    init();
    
    function init() {
        // Import functionality
        $('#import-btn').on('click', handleImport);
        $('#csv-file').on('change', handleFileSelect);
        
        // Export functionality
        $('#export-btn').on('click', handleExport);
        
        // Bulk operations
        $('#delete-btn').on('click', handleBulkDelete);
        $('#update-btn').on('click', handleBulkUpdate);
        
        // Content list
        $('#load-list-btn').on('click', loadContentList);
        
        // Template download
        $('#download-template').on('click', downloadTemplate);
        
        // Criteria change
        $('#delete-criteria').on('change', updateDeleteValue);
        
        // Load initial content list
        loadContentList();
    }
    
    function handleImport() {
        if (isImporting) return;
        
        const file = $('#csv-file')[0].files[0];
        const type = $('#import-type').val();
        const skipDuplicates = $('#skip-duplicates').is(':checked');
        
        if (!file) {
            showMessage('Lütfen bir CSV dosyası seçin', 'error');
            return;
        }
        
        if (!file.name.endsWith('.csv')) {
            showMessage('Lütfen geçerli bir CSV dosyası seçin', 'error');
            return;
        }
        
        isImporting = true;
        $('#import-btn').prop('disabled', true).text('İçe Aktarılıyor...');
        $('#import-progress').show();
        $('#import-results').hide();
        
        const formData = new FormData();
        formData.append('action', 'bulk_import_csv');
        formData.append('nonce', torofilm_bulk.nonce);
        formData.append('type', type);
        formData.append('skip_duplicates', skipDuplicates);
        formData.append('csv_file', file);
        
        // Simulate progress
        simulateProgress();
        
        $.ajax({
            url: torofilm_bulk.ajax_url,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.success) {
                    displayImportResults(response.data);
                    showMessage('İçe aktarma tamamlandı!', 'success');
                } else {
                    showMessage('İçe aktarma başarısız: ' + response.data, 'error');
                }
            },
            error: function(xhr, status, error) {
                showMessage('Bir hata oluştu: ' + error, 'error');
            },
            complete: function() {
                isImporting = false;
                $('#import-btn').prop('disabled', false).html('<i class="fa fa-upload"></i> İçe Aktar');
                $('#import-progress').hide();
            }
        });
    }
    
    function simulateProgress() {
        importProgress = 0;
        const interval = setInterval(function() {
            importProgress += Math.random() * 15;
            if (importProgress > 90) {
                importProgress = 90;
            }
            
            updateProgress(importProgress);
            
            if (importProgress >= 90) {
                clearInterval(interval);
            }
        }, 200);
    }
    
    function updateProgress(percent) {
        $('#progress-fill').css('width', percent + '%');
        $('#progress-text').text(Math.round(percent) + '%');
    }
    
    function displayImportResults(results) {
        const $container = $('#results-content');
        $container.empty();
        
        const resultItems = [
            { type: 'success', count: results.success, label: 'Başarılı' },
            { type: 'failed', count: results.failed, label: 'Başarısız' },
            { type: 'skipped', count: results.skipped, label: 'Atlandı' }
        ];
        
        resultItems.forEach(function(item) {
            const resultHtml = `
                <div class="result-item ${item.type}">
                    <div class="result-number">${item.count}</div>
                    <div class="result-label">${item.label}</div>
                </div>
            `;
            $container.append(resultHtml);
        });
        
        if (results.errors && results.errors.length > 0) {
            const errorsHtml = `
                <div class="error-details">
                    <h4>Hata Detayları:</h4>
                    <ul>
                        ${results.errors.map(error => `<li>${error}</li>`).join('')}
                    </ul>
                </div>
            `;
            $container.append(errorsHtml);
        }
        
        $('#import-results').show();
    }
    
    function handleExport() {
        const type = $('#export-type').val();
        const limit = $('#export-limit').val();
        
        const formData = new FormData();
        formData.append('action', 'bulk_export_csv');
        formData.append('nonce', torofilm_bulk.nonce);
        formData.append('type', type);
        formData.append('limit', limit);
        
        // Create a temporary form to trigger download
        const form = $('<form>', {
            method: 'POST',
            action: torofilm_bulk.ajax_url,
            target: '_blank'
        });
        
        form.append($('<input>', {
            type: 'hidden',
            name: 'action',
            value: 'bulk_export_csv'
        }));
        
        form.append($('<input>', {
            type: 'hidden',
            name: 'nonce',
            value: torofilm_bulk.nonce
        }));
        
        form.append($('<input>', {
            type: 'hidden',
            name: 'type',
            value: type
        }));
        
        form.append($('<input>', {
            type: 'hidden',
            name: 'limit',
            value: limit
        }));
        
        $('body').append(form);
        form.submit();
        form.remove();
        
        showMessage('Dışa aktarma başlatıldı...', 'success');
    }
    
    function handleBulkDelete() {
        const type = $('#delete-type').val();
        const criteria = $('#delete-criteria').val();
        const value = $('#delete-value').val();
        
        if (!value) {
            showMessage('Lütfen bir değer girin', 'error');
            return;
        }
        
        if (!confirm(`Seçilen kriterlere göre ${type} silinecek. Emin misiniz?`)) {
            return;
        }
        
        $.ajax({
            url: torofilm_bulk.ajax_url,
            type: 'POST',
            data: {
                action: 'bulk_delete_content',
                nonce: torofilm_bulk.nonce,
                type: type,
                criteria: criteria,
                value: value
            },
            success: function(response) {
                if (response.success) {
                    const data = response.data;
                    showMessage(`${data.deleted} ${type} silindi (Toplam: ${data.total})`, 'success');
                    loadContentList(); // Refresh list
                } else {
                    showMessage('Silme işlemi başarısız: ' + response.data, 'error');
                }
            },
            error: function() {
                showMessage('Bir hata oluştu!', 'error');
            }
        });
    }
    
    function handleBulkUpdate() {
        const type = $('#update-type').val();
        const field = $('#update-field').val();
        const value = $('#update-value').val();
        
        if (!value) {
            showMessage('Lütfen bir değer girin', 'error');
            return;
        }
        
        if (!confirm(`Seçilen ${type} güncellenecek. Emin misiniz?`)) {
            return;
        }
        
        $.ajax({
            url: torofilm_bulk.ajax_url,
            type: 'POST',
            data: {
                action: 'bulk_update_content',
                nonce: torofilm_bulk.nonce,
                type: type,
                field: field,
                value: value
            },
            success: function(response) {
                if (response.success) {
                    const data = response.data;
                    showMessage(`${data.updated} ${type} güncellendi (Toplam: ${data.total})`, 'success');
                    loadContentList(); // Refresh list
                } else {
                    showMessage('Güncelleme işlemi başarısız: ' + response.data, 'error');
                }
            },
            error: function() {
                showMessage('Bir hata oluştu!', 'error');
            }
        });
    }
    
    function loadContentList() {
        const type = $('#list-type').val();
        const limit = $('#list-limit').val();
        
        const $container = $('#content-list');
        $container.html('<div class="loading">Liste yükleniyor...</div>');
        
        // Simulate loading content
        setTimeout(function() {
            // This would normally be an AJAX call to get actual content
            const mockContent = generateMockContent(type, limit);
            displayContentList(mockContent);
        }, 1000);
    }
    
    function generateMockContent(type, limit) {
        const content = [];
        const count = Math.min(parseInt(limit), 50);
        
        for (let i = 1; i <= count; i++) {
            content.push({
                id: i,
                title: `${type === 'movies' ? 'Film' : 'Dizi'} ${i}`,
                date: new Date().toISOString().split('T')[0],
                views: Math.floor(Math.random() * 10000),
                rating: (Math.random() * 5 + 5).toFixed(1),
                thumbnail: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iODAiIHZpZXdCb3g9IjAgMCA2MCA4MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgd2lkdGg9IjYwIiBoZWlnaHQ9IjgwIiBmaWxsPSIjRjNGNEY2Ii8+CjxwYXRoIGQ9Ik0yMCAyNUg0MFY1NUgyMFYyNVoiIGZpbGw9IiNEMUQ1REIiLz4KPHBhdGggZD0iTTI1IDMwSDM1VjUwSDI1VjMwWiIgZmlsbD0iIzlDQTNBRiIvPgo8L3N2Zz4K'
            });
        }
        
        return content;
    }
    
    function displayContentList(content) {
        const $container = $('#content-list');
        $container.empty();
        
        if (content.length === 0) {
            $container.html('<div class="no-content">Henüz içerik eklenmemiş</div>');
            return;
        }
        
        content.forEach(function(item) {
            const itemHtml = `
                <div class="content-item">
                    <input type="checkbox" class="content-checkbox" value="${item.id}" />
                    <img src="${item.thumbnail}" alt="${item.title}" class="content-thumbnail" />
                    <div class="content-info">
                        <h4>${item.title}</h4>
                        <div class="content-meta">
                            <span class="views">👁️ ${item.views}</span>
                            <span class="rating">⭐ ${item.rating}</span>
                            <span class="date">📅 ${item.date}</span>
                        </div>
                    </div>
                    <div class="content-actions">
                        <button class="button button-secondary" onclick="editContent(${item.id})">
                            <i class="fa fa-edit"></i> Düzenle
                        </button>
                        <button class="button button-danger" onclick="deleteContent(${item.id})">
                            <i class="fa fa-trash"></i> Sil
                        </button>
                    </div>
                </div>
            `;
            $container.append(itemHtml);
        });
    }
    
    function downloadTemplate() {
        const type = $('#import-type').val();
        const template = generateCSVTemplate(type);
        
        const blob = new Blob([template], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${type}_template.csv`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
        
        showMessage('Şablon indirildi!', 'success');
    }
    
    function generateCSVTemplate(type) {
        const headers = [
            'title',
            'content',
            'date',
            'rating',
            'year',
            'duration',
            'director',
            'cast',
            'genre',
            'country',
            'language',
            'imdb',
            'trailer',
            'image_url'
        ];
        
        const sampleData = [
            'Örnek Film',
            'Bu bir örnek film açıklamasıdır.',
            '2024-01-01',
            '8.5',
            '2024',
            '120',
            'Örnek Yönetmen',
            'Örnek Oyuncu 1, Örnek Oyuncu 2',
            'Aksiyon, Dram',
            'Türkiye',
            'Türkçe',
            'tt1234567',
            'https://youtube.com/watch?v=example',
            'https://example.com/poster.jpg'
        ];
        
        return headers.join(',') + '\n' + sampleData.join(',');
    }
    
    function updateDeleteValue() {
        const criteria = $('#delete-criteria').val();
        const $valueGroup = $('#delete-value-group');
        const $valueInput = $('#delete-value');
        
        switch (criteria) {
            case 'date':
                $valueInput.attr('placeholder', 'Örn: 2023-01-01');
                break;
            case 'category':
                $valueInput.attr('placeholder', 'Örn: aksiyon');
                break;
            case 'rating':
                $valueInput.attr('placeholder', 'Örn: 5.0');
                break;
            case 'views':
                $valueInput.attr('placeholder', 'Örn: 1000');
                break;
        }
    }
    
    function showMessage(message, type) {
        const messageClass = type === 'error' ? 'error-message' : 'success-message';
        const messageHtml = `<div class="${messageClass}">${message}</div>`;
        
        $('.bulk-container').prepend(messageHtml);
        
        setTimeout(function() {
            $('.' + messageClass).fadeOut(300, function() {
                $(this).remove();
            });
        }, 5000);
    }
    
    function handleFileSelect() {
        const file = this.files[0];
        if (file) {
            showMessage(`Dosya seçildi: ${file.name}`, 'success');
        }
    }
    
    // Global functions for content actions
    window.editContent = function(id) {
        showMessage(`İçerik düzenleme: ${id}`, 'success');
    };
    
    window.deleteContent = function(id) {
        if (confirm('Bu içeriği silmek istediğinizden emin misiniz?')) {
            showMessage(`İçerik silindi: ${id}`, 'success');
            loadContentList(); // Refresh list
        }
    };
    
    // Drag and drop functionality
    const fileUploadArea = $('<div class="file-upload-area">');
    fileUploadArea.html(`
        <div class="file-upload-icon">📁</div>
        <div class="file-upload-text">CSV dosyasını buraya sürükleyin</div>
        <div class="file-upload-hint">veya dosya seçmek için tıklayın</div>
    `);
    
    fileUploadArea.on('click', function() {
        $('#csv-file').click();
    });
    
    fileUploadArea.on('dragover', function(e) {
        e.preventDefault();
        $(this).addClass('dragover');
    });
    
    fileUploadArea.on('dragleave', function(e) {
        e.preventDefault();
        $(this).removeClass('dragover');
    });
    
    fileUploadArea.on('drop', function(e) {
        e.preventDefault();
        $(this).removeClass('dragover');
        
        const files = e.originalEvent.dataTransfer.files;
        if (files.length > 0) {
            $('#csv-file')[0].files = files;
            handleFileSelect.call($('#csv-file')[0]);
        }
    });
    
    // Replace file input with drag and drop area
    $('#csv-file').after(fileUploadArea);
    $('#csv-file').hide();
});
