/**
 * Video Admin JavaScript
 * 
 * @package Torofilm
 * @since 1.0.0
 */

(function($) {
    'use strict';
    
    // Video URL validation
    function validateVideoUrl(url) {
        const supportedHosts = [
            'youtube.com', 'youtu.be', 'vidmoly.net', 'filemoon.sx', 
            'davioad.com', 'uptobox.com', 'ok.ru', 'sendvid.com',
            'fembed.com', 'doodstream.com', 'streamtap.net', 'voe.sx',
            'streamhub.gg', 'userscloud.com', 'savefiles.com', 'lulustream.com',
            'bigwarp.io', 'vidguard.to', 'goodstream.uno', 'dropload.io',
            'vidhide.com', 'mediafire.com'
        ];
        
        if (!url) return false;
        
        try {
            const urlObj = new URL(url);
            return supportedHosts.some(host => urlObj.hostname.includes(host));
        } catch (e) {
            return false;
        }
    }
    
    // Get host name from URL
    function getHostName(url) {
        try {
            const urlObj = new URL(url);
            const hostname = urlObj.hostname;
            
            if (hostname.includes('youtube.com') || hostname.includes('youtu.be')) {
                return 'YouTube';
            } else if (hostname.includes('vidmoly.net')) {
                return 'Vidmoly';
            } else if (hostname.includes('filemoon.sx')) {
                return 'FileMoon';
            } else if (hostname.includes('davioad.com')) {
                return 'StreamWish';
            } else if (hostname.includes('uptobox.com')) {
                return 'Uptobox';
            } else if (hostname.includes('ok.ru')) {
                return 'OK.RU';
            } else if (hostname.includes('sendvid.com')) {
                return 'SendVid';
            } else if (hostname.includes('fembed.com')) {
                return 'Fembed';
            } else if (hostname.includes('doodstream.com')) {
                return 'Doodstream';
            } else if (hostname.includes('streamtap.net')) {
                return 'Streamtap';
            } else if (hostname.includes('voe.sx')) {
                return 'Voe.sx';
            } else if (hostname.includes('streamhub.gg')) {
                return 'Streamhub';
            } else if (hostname.includes('userscloud.com')) {
                return 'Userscloud';
            } else if (hostname.includes('savefiles.com')) {
                return 'Savefiles';
            } else if (hostname.includes('lulustream.com')) {
                return 'Lulustream';
            } else if (hostname.includes('bigwarp.io')) {
                return 'Bigwarp.io';
            } else if (hostname.includes('vidguard.to')) {
                return 'Vidguard.to';
            } else if (hostname.includes('goodstream.uno')) {
                return 'Goodstream';
            } else if (hostname.includes('dropload.io')) {
                return 'Dropload';
            } else if (hostname.includes('vidhide.com')) {
                return 'Vidhide';
            } else if (hostname.includes('mediafire.com')) {
                return 'Mediafire';
            }
            
            return 'Bilinmeyen';
        } catch (e) {
            return 'Geçersiz URL';
        }
    }
    
    // Initialize when document is ready
    $(document).ready(function() {
        
        // Video URL validation
        $('input[name="movie_video_url"], input[name="movie_video_url_alt"], input[name="movie_trailer_url"]').on('blur', function() {
            const input = $(this);
            const url = input.val();
            
            if (url) {
                if (validateVideoUrl(url)) {
                    input.removeClass('invalid').addClass('valid');
                    const hostName = getHostName(url);
                    input.next('.url-status').remove();
                    input.after('<span class="url-status valid">✓ ' + hostName + '</span>');
                } else {
                    input.removeClass('valid').addClass('invalid');
                    input.next('.url-status').remove();
                    input.after('<span class="url-status invalid">✗ Desteklenmeyen hosting</span>');
                }
            } else {
                input.removeClass('valid invalid');
                input.next('.url-status').remove();
            }
        });
        
        // Video preview
        $('input[name="movie_video_url"], input[name="movie_video_url_alt"], input[name="movie_trailer_url"]').on('blur', function() {
            const input = $(this);
            const url = input.val();
            const container = input.closest('.video-url-group');
            let preview = container.find('.video-preview');
            
            if (url && validateVideoUrl(url)) {
                if (preview.length === 0) {
                    preview = $('<div class="video-preview"><h4>Video Önizleme</h4><div class="preview-content"></div></div>');
                    container.append(preview);
                }
                
                // Generate embed URL for preview
                let embedUrl = '';
                try {
                    const urlObj = new URL(url);
                    const hostname = urlObj.hostname;
                    
                    if (hostname.includes('youtube.com') || hostname.includes('youtu.be')) {
                        const videoId = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([a-zA-Z0-9_-]+)/);
                        if (videoId) {
                            embedUrl = 'https://www.youtube.com/embed/' + videoId[1];
                        }
                    } else if (hostname.includes('vidmoly.net')) {
                        const videoId = url.match(/vidmoly\.net\/([a-zA-Z0-9]+)/);
                        if (videoId) {
                            embedUrl = 'https://vidmoly.net/embed-' + videoId[1];
                        }
                    } else if (hostname.includes('filemoon.sx')) {
                        const videoId = url.match(/filemoon\.sx\/e\/([a-zA-Z0-9]+)/);
                        if (videoId) {
                            embedUrl = 'https://filemoon.sx/e/' + videoId[1];
                        }
                    }
                    
                    if (embedUrl) {
                        preview.find('.preview-content').html('<iframe src="' + embedUrl + '" class="preview-iframe" frameborder="0" allowfullscreen></iframe>');
                        preview.addClass('show');
                    }
                } catch (e) {
                    console.error('Preview error:', e);
                }
            } else {
                if (preview.length > 0) {
                    preview.removeClass('show');
                }
            }
        });
        
        // Form submission validation
        $('form').on('submit', function(e) {
            const videoUrls = $('input[name="movie_video_url"], input[name="movie_video_url_alt"], input[name="movie_trailer_url"]');
            let hasValidUrl = false;
            
            videoUrls.each(function() {
                const url = $(this).val();
                if (url && validateVideoUrl(url)) {
                    hasValidUrl = true;
                }
            });
            
            if (!hasValidUrl) {
                e.preventDefault();
                alert('En az bir geçerli video URL\'si girmelisiniz!');
                return false;
            }
        });
        
        // Tab switching
        $('.nav-tab').on('click', function(e) {
            e.preventDefault();
            
            const target = $(this).attr('href');
            
            // Remove active class from all tabs and panes
            $('.nav-tab').removeClass('nav-tab-active');
            $('.tab-pane').removeClass('active');
            
            // Add active class to clicked tab and corresponding pane
            $(this).addClass('nav-tab-active');
            $(target).addClass('active');
        });
        
        // Test form submission
        $('.video-test-form').on('submit', function(e) {
            e.preventDefault();
            
            const form = $(this);
            const url = form.find('input[name="test_url"]').val();
            const title = form.find('input[name="test_title"]').val();
            const resultDiv = $('.test-result');
            const outputDiv = $('.test-output');
            
            if (!url) {
                alert('Lütfen video URL\'si girin!');
                return;
            }
            
            if (!validateVideoUrl(url)) {
                outputDiv.html('<p style="color: red;">Desteklenmeyen video hosting servisi!</p>');
                resultDiv.show();
                return;
            }
            
            // Show loading
            outputDiv.html('<p>Video test ediliyor...</p>');
            resultDiv.show();
            
            // AJAX test
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'test_video_url',
                    url: url,
                    title: title,
                    nonce: $('#test_nonce').val() || 'test_nonce'
                },
                success: function(response) {
                    if (response.success) {
                        outputDiv.html(response.data.html);
                    } else {
                        outputDiv.html('<p style="color: red;">Hata: ' + response.data + '</p>');
                    }
                },
                error: function() {
                    outputDiv.html('<p style="color: red;">Bir hata oluştu!</p>');
                }
            });
        });
        
        // Auto-detect video hosting
        $('input[type="url"]').on('paste', function() {
            const input = $(this);
            setTimeout(function() {
                const url = input.val();
                if (url && validateVideoUrl(url)) {
                    input.trigger('blur');
                }
            }, 100);
        });
        
        // Copy URL to clipboard
        $(document).on('click', '.copy-url', function(e) {
            e.preventDefault();
            const url = $(this).data('url');
            navigator.clipboard.writeText(url).then(function() {
                alert('URL kopyalandı!');
            });
        });
        
        // Video quality selector
        $('.quality-select').on('change', function() {
            const quality = $(this).val();
            const preview = $(this).closest('.video-preview').find('.preview-iframe');
            
            if (preview.length > 0) {
                let src = preview.attr('src');
                if (src.includes('youtube.com')) {
                    // YouTube quality parameter
                    src = src.replace(/[?&]vq=[^&]*/, '');
                    if (quality !== 'auto') {
                        src += (src.includes('?') ? '&' : '?') + 'vq=' + quality;
                    }
                    preview.attr('src', src);
                }
            }
        });
        
        // Video speed selector
        $('.speed-select').on('change', function() {
            const speed = $(this).val();
            const preview = $(this).closest('.video-preview').find('.preview-iframe');
            
            if (preview.length > 0) {
                let src = preview.attr('src');
                if (src.includes('youtube.com')) {
                    // YouTube speed parameter
                    src = src.replace(/[?&]speed=[^&]*/, '');
                    if (speed !== '1') {
                        src += (src.includes('?') ? '&' : '?') + 'speed=' + speed;
                    }
                    preview.attr('src', src);
                }
            }
        });
        
    });
    
})(jQuery);
