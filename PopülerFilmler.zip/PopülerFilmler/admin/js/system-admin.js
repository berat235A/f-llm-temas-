jQuery(document).ready(function($) {
    'use strict';
    
    let systemData = {};
    
    // Initialize
    init();
    
    function init() {
        loadSystemStatus();
        loadSystemInfo('server');
        
        // Cache management
        $('#clear-cache-btn').on('click', handleClearCache);
        $('#clear-transients-btn').on('click', handleClearTransients);
        $('#clear-uploads-btn').on('click', handleClearUploads);
        
        // Database operations
        $('#optimize-db-btn').on('click', handleOptimizeDatabase);
        $('#repair-db-btn').on('click', handleRepairDatabase);
        $('#cleanup-db-btn').on('click', handleCleanupDatabase);
        
        // Backup operations
        $('#create-backup-btn').on('click', handleCreateBackup);
        $('#restore-backup-btn').on('click', handleRestoreBackup);
        
        // System info tabs
        $('.tab-btn').on('click', function() {
            const tab = $(this).data('tab');
            switchTab(tab);
        });
        
        // File cleanup
        $('#cleanup-files-btn').on('click', handleCleanupFiles);
        $('#scan-files-btn').on('click', handleScanFiles);
        
        // File upload
        $('#backup-file').on('change', handleFileSelect);
        
        // Auto refresh system status every 5 minutes
        setInterval(loadSystemStatus, 300000);
    }
    
    function loadSystemStatus() {
        // Simulate system status data
        const mockData = {
            db_size: '25.6 MB',
            db_detail: '12 tablo, 1,245 kayıt',
            file_size: '156.8 MB',
            file_detail: '2,847 dosya',
            php_version: '8.1.2',
            php_detail: 'Güncel',
            wp_version: '6.4.2',
            wp_detail: 'Güncel'
        };
        
        displaySystemStatus(mockData);
    }
    
    function displaySystemStatus(data) {
        $('#db-size').text(data.db_size);
        $('#db-detail').text(data.db_detail);
        $('#file-size').text(data.file_size);
        $('#file-detail').text(data.file_detail);
        $('#php-version').text(data.php_version);
        $('#php-detail').text(data.php_detail);
        $('#wp-version').text(data.wp_version);
        $('#wp-detail').text(data.wp_detail);
    }
    
    function handleClearCache() {
        if (!confirm('Cache temizlenecek. Emin misiniz?')) {
            return;
        }
        
        showProgress('cache');
        
        $.ajax({
            url: torofilm_system.ajax_url,
            type: 'POST',
            data: {
                action: 'clear_cache',
                nonce: torofilm_system.nonce
            },
            success: function(response) {
                if (response.success) {
                    const data = response.data;
                    showMessage(`Cache temizlendi! ${data.files_removed} dosya silindi, ${formatBytes(data.size_freed)} alan açıldı.`, 'success');
                } else {
                    showMessage('Cache temizleme başarısız: ' + response.data, 'error');
                }
            },
            error: function() {
                showMessage('Bir hata oluştu!', 'error');
            },
            complete: function() {
                hideProgress('cache');
            }
        });
    }
    
    function handleClearTransients() {
        if (!confirm('Transients temizlenecek. Emin misiniz?')) {
            return;
        }
        
        showProgress('cache');
        
        // Simulate transients clearing
        setTimeout(function() {
            showMessage('Transients temizlendi!', 'success');
            hideProgress('cache');
        }, 2000);
    }
    
    function handleClearUploads() {
        if (!confirm('Kullanılmayan medya dosyaları silinecek. Emin misiniz?')) {
            return;
        }
        
        showProgress('cache');
        
        // Simulate uploads clearing
        setTimeout(function() {
            showMessage('Kullanılmayan medya dosyaları temizlendi!', 'success');
            hideProgress('cache');
        }, 3000);
    }
    
    function handleOptimizeDatabase() {
        if (!confirm('Veritabanı optimize edilecek. Bu işlem biraz zaman alabilir. Emin misiniz?')) {
            return;
        }
        
        showProgress('db');
        
        $.ajax({
            url: torofilm_system.ajax_url,
            type: 'POST',
            data: {
                action: 'optimize_database',
                nonce: torofilm_system.nonce
            },
            success: function(response) {
                if (response.success) {
                    const data = response.data;
                    showMessage(`Veritabanı optimize edildi! ${data.tables_optimized} tablo optimize edildi, ${data.tables_repaired} tablo onarıldı.`, 'success');
                } else {
                    showMessage('Veritabanı optimizasyonu başarısız: ' + response.data, 'error');
                }
            },
            error: function() {
                showMessage('Bir hata oluştu!', 'error');
            },
            complete: function() {
                hideProgress('db');
            }
        });
    }
    
    function handleRepairDatabase() {
        if (!confirm('Veritabanı onarılacak. Emin misiniz?')) {
            return;
        }
        
        showProgress('db');
        
        // Simulate database repair
        setTimeout(function() {
            showMessage('Veritabanı onarıldı!', 'success');
            hideProgress('db');
        }, 2500);
    }
    
    function handleCleanupDatabase() {
        if (!confirm('Gereksiz veriler temizlenecek. Emin misiniz?')) {
            return;
        }
        
        showProgress('db');
        
        // Simulate database cleanup
        setTimeout(function() {
            showMessage('Gereksiz veriler temizlendi!', 'success');
            hideProgress('db');
        }, 2000);
    }
    
    function handleCreateBackup() {
        const type = $('#backup-type').val();
        
        if (!confirm(`${type} yedeği oluşturulacak. Emin misiniz?`)) {
            return;
        }
        
        showMessage('Yedek oluşturuluyor...', 'info');
        
        $.ajax({
            url: torofilm_system.ajax_url,
            type: 'POST',
            data: {
                action: 'create_backup',
                nonce: torofilm_system.nonce,
                type: type
            },
            success: function(response) {
                if (response.success) {
                    const data = response.data;
                    showMessage(`Yedek oluşturuldu! Dosya boyutu: ${formatBytes(data.size)}`, 'success');
                    loadBackupList(); // Refresh backup list
                } else {
                    showMessage('Yedek oluşturma başarısız: ' + response.data, 'error');
                }
            },
            error: function() {
                showMessage('Bir hata oluştu!', 'error');
            }
        });
    }
    
    function handleRestoreBackup() {
        const file = $('#backup-file')[0].files[0];
        
        if (!file) {
            showMessage('Lütfen bir yedek dosyası seçin', 'error');
            return;
        }
        
        if (!confirm('Yedek geri yüklenecek. Bu işlem mevcut verileri değiştirebilir. Emin misiniz?')) {
            return;
        }
        
        const formData = new FormData();
        formData.append('action', 'restore_backup');
        formData.append('nonce', torofilm_system.nonce);
        formData.append('backup_file', file);
        
        showMessage('Yedek geri yükleniyor...', 'info');
        
        $.ajax({
            url: torofilm_system.ajax_url,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.success) {
                    showMessage('Yedek başarıyla geri yüklendi!', 'success');
                } else {
                    showMessage('Yedek geri yükleme başarısız: ' + response.data, 'error');
                }
            },
            error: function() {
                showMessage('Bir hata oluştu!', 'error');
            }
        });
    }
    
    function handleCleanupFiles() {
        if (!confirm('Dosyalar temizlenecek. Emin misiniz?')) {
            return;
        }
        
        $.ajax({
            url: torofilm_system.ajax_url,
            type: 'POST',
            data: {
                action: 'cleanup_files',
                nonce: torofilm_system.nonce
            },
            success: function(response) {
                if (response.success) {
                    const data = response.data;
                    displayCleanupResults(data);
                    showMessage('Dosya temizliği tamamlandı!', 'success');
                } else {
                    showMessage('Dosya temizliği başarısız: ' + response.data, 'error');
                }
            },
            error: function() {
                showMessage('Bir hata oluştu!', 'error');
            }
        });
    }
    
    function handleScanFiles() {
        showMessage('Dosyalar taranıyor...', 'info');
        
        // Simulate file scanning
        setTimeout(function() {
            const mockResults = {
                files_removed: 0,
                size_freed: 0,
                directories_removed: 0,
                temp_files: 15,
                cache_files: 8,
                log_files: 3
            };
            
            displayCleanupResults(mockResults);
            showMessage('Dosya taraması tamamlandı!', 'success');
        }, 2000);
    }
    
    function displayCleanupResults(results) {
        const $container = $('#cleanup-results-content');
        $container.empty();
        
        const resultItems = [
            { type: 'success', count: results.files_removed, label: 'Silinen Dosya' },
            { type: 'info', count: formatBytes(results.size_freed), label: 'Açılan Alan' },
            { type: 'info', count: results.directories_removed, label: 'Silinen Klasör' }
        ];
        
        resultItems.forEach(function(item) {
            const resultHtml = `
                <div class="result-item ${item.type}">
                    <div class="result-number">${item.count}</div>
                    <div class="result-label">${item.label}</div>
                </div>
            `;
            $container.append(resultHtml);
        });
        
        $('#cleanup-results').show();
    }
    
    function loadSystemInfo(type) {
        const $container = $(`#${type}-info-content`);
        $container.html('<div class="loading">Bilgiler yükleniyor...</div>');
        
        $.ajax({
            url: torofilm_system.ajax_url,
            type: 'POST',
            data: {
                action: 'system_info',
                nonce: torofilm_system.nonce,
                type: type
            },
            success: function(response) {
                if (response.success) {
                    displaySystemInfo(response.data, type);
                } else {
                    $container.html('<div class="error-message">Bilgiler yüklenemedi</div>');
                }
            },
            error: function() {
                $container.html('<div class="error-message">Bir hata oluştu</div>');
            }
        });
    }
    
    function displaySystemInfo(info, type) {
        const $container = $(`#${type}-info-content`);
        $container.empty();
        
        Object.keys(info).forEach(function(key) {
            const value = info[key];
            const itemHtml = `
                <div class="info-item">
                    <span class="info-label">${key}:</span>
                    <span class="info-value">${value}</span>
                </div>
            `;
            $container.append(itemHtml);
        });
    }
    
    function switchTab(tab) {
        // Update tab buttons
        $('.tab-btn').removeClass('active');
        $(`.tab-btn[data-tab="${tab}"]`).addClass('active');
        
        // Update tab content
        $('.tab-content').removeClass('active');
        $(`#${tab}`).addClass('active');
        
        // Load content if not already loaded
        if ($(`#${tab}-info-content`).html().includes('loading')) {
            loadSystemInfo(tab.replace('-info', ''));
        }
    }
    
    function loadBackupList() {
        const $container = $('#backup-items');
        $container.html('<div class="loading">Yedekler yükleniyor...</div>');
        
        // Simulate backup list loading
        setTimeout(function() {
            const mockBackups = [
                {
                    name: 'backup_full_2024-01-15_14-30-25.zip',
                    size: '45.2 MB',
                    date: '2024-01-15 14:30:25',
                    type: 'Tam Yedek'
                },
                {
                    name: 'backup_database_2024-01-14_09-15-10.zip',
                    size: '12.8 MB',
                    date: '2024-01-14 09:15:10',
                    type: 'Veritabanı'
                },
                {
                    name: 'backup_files_2024-01-13_16-45-30.zip',
                    size: '156.3 MB',
                    date: '2024-01-13 16:45:30',
                    type: 'Dosyalar'
                }
            ];
            
            displayBackupList(mockBackups);
        }, 1000);
    }
    
    function displayBackupList(backups) {
        const $container = $('#backup-items');
        $container.empty();
        
        if (backups.length === 0) {
            $container.html('<div class="no-content">Henüz yedek oluşturulmamış</div>');
            return;
        }
        
        backups.forEach(function(backup) {
            const itemHtml = `
                <div class="backup-item">
                    <div class="backup-info">
                        <h4>${backup.name}</h4>
                        <div class="backup-meta">
                            <span>Boyut: ${backup.size}</span> |
                            <span>Tarih: ${backup.date}</span> |
                            <span>Tür: ${backup.type}</span>
                        </div>
                    </div>
                    <div class="backup-actions">
                        <button class="button button-secondary" onclick="downloadBackup('${backup.name}')">
                            <i class="fa fa-download"></i> İndir
                        </button>
                        <button class="button button-danger" onclick="deleteBackup('${backup.name}')">
                            <i class="fa fa-trash"></i> Sil
                        </button>
                    </div>
                </div>
            `;
            $container.append(itemHtml);
        });
    }
    
    function showProgress(type) {
        $(`#${type}-progress`).show();
        $(`#${type}-progress-fill`).addClass('animating');
        
        // Simulate progress
        let progress = 0;
        const interval = setInterval(function() {
            progress += Math.random() * 15;
            if (progress > 90) {
                progress = 90;
            }
            
            $(`#${type}-progress-fill`).css('width', progress + '%');
            $(`#${type}-progress-text`).text(Math.round(progress) + '%');
            
            if (progress >= 90) {
                clearInterval(interval);
            }
        }, 200);
    }
    
    function hideProgress(type) {
        $(`#${type}-progress-fill`).css('width', '100%');
        $(`#${type}-progress-text`).text('100%');
        
        setTimeout(function() {
            $(`#${type}-progress`).hide();
            $(`#${type}-progress-fill`).removeClass('animating').css('width', '0%');
            $(`#${type}-progress-text`).text('0%');
        }, 1000);
    }
    
    function showMessage(message, type) {
        const messageClass = type === 'error' ? 'error-message' : 
                           type === 'success' ? 'success-message' : 'info-message';
        const messageHtml = `<div class="${messageClass}">${message}</div>`;
        
        $('.system-container').prepend(messageHtml);
        
        setTimeout(function() {
            $('.' + messageClass).fadeOut(300, function() {
                $(this).remove();
            });
        }, 5000);
    }
    
    function handleFileSelect() {
        const file = this.files[0];
        if (file) {
            showMessage(`Dosya seçildi: ${file.name}`, 'success');
        }
    }
    
    function formatBytes(bytes) {
        if (bytes === 0) return '0 Bytes';
        
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
    
    // Global functions for backup actions
    window.downloadBackup = function(filename) {
        showMessage(`Yedek indiriliyor: ${filename}`, 'info');
    };
    
    window.deleteBackup = function(filename) {
        if (confirm(`Yedek silinecek: ${filename}. Emin misiniz?`)) {
            showMessage(`Yedek silindi: ${filename}`, 'success');
            loadBackupList(); // Refresh list
        }
    };
    
    // Load initial backup list
    loadBackupList();
    
    // Add drag and drop functionality for backup file
    const fileUploadArea = $('<div class="file-upload-area">');
    fileUploadArea.html(`
        <div class="file-upload-icon">📁</div>
        <div class="file-upload-text">Yedek dosyasını buraya sürükleyin</div>
        <div class="file-upload-hint">veya dosya seçmek için tıklayın</div>
    `);
    
    fileUploadArea.on('click', function() {
        $('#backup-file').click();
    });
    
    fileUploadArea.on('dragover', function(e) {
        e.preventDefault();
        $(this).addClass('dragover');
    });
    
    fileUploadArea.on('dragleave', function(e) {
        e.preventDefault();
        $(this).removeClass('dragover');
    });
    
    fileUploadArea.on('drop', function(e) {
        e.preventDefault();
        $(this).removeClass('dragover');
        
        const files = e.originalEvent.dataTransfer.files;
        if (files.length > 0) {
            $('#backup-file')[0].files = files;
            handleFileSelect.call($('#backup-file')[0]);
        }
    });
    
    // Replace file input with drag and drop area
    $('#backup-file').after(fileUploadArea);
    $('#backup-file').hide();
});
