/**
 * TMDB Admin JavaScript
 * 
 * @package Torofilm
 * @since 1.0.0
 */

(function($) {
    'use strict';
    
    let currentResults = [];
    let currentDetails = null;
    
    // Initialize when document is ready
    $(document).ready(function() {
        
        // Search form submission
        $('#tmdb-search-btn').on('click', function() {
            performSearch();
        });
        
        // Enter key on search input
        $('#tmdb-search-input').on('keypress', function(e) {
            if (e.which === 13) {
                performSearch();
            }
        });
        
        // Search type change
        $('input[name="search-type"]').on('change', function() {
            const type = $(this).val();
            const placeholder = type === 'movie' ? 'Film adı girin...' : 
                              type === 'tv' ? 'Dizi adı girin...' : 
                              'Kişi adı girin...';
            $('#tmdb-search-input').attr('placeholder', placeholder);
        });
        
        // Test button
        $('#tmdb-test-btn').on('click', function() {
            $('#tmdb-search-input').val('Batman');
            performSearch();
        });
        
        // Copy ID button
        $(document).on('click', '.copy-id-btn', function() {
            const id = $(this).data('id');
            copyToClipboard(id);
        });
        
        // Copy TMDB ID button
        $(document).on('click', '.copy-tmdb-id-btn', function() {
            const id = $(this).data('id');
            copyToClipboard(id);
        });
        
        // Add movie button
        $(document).on('click', '.add-movie-btn', function() {
            const tmdbId = $(this).data('tmdb-id');
            const type = $(this).data('type');
            addMovieToSite(tmdbId, type);
        });
        
        // Result card click
        $(document).on('click', '.tmdb-result-card', function() {
            const id = $(this).data('id');
            const type = $(this).data('type');
            getDetails(id, type);
        });
        
    });
    
    /**
     * Perform TMDB search
     */
    function performSearch() {
        const query = $('#tmdb-search-input').val().trim();
        const type = $('input[name="search-type"]:checked').val();
        
        if (!query) {
            alert('Lütfen arama terimi girin!');
            return;
        }
        
        // Show loading
        showLoading();
        
        // AJAX request
        $.ajax({
            url: torofilm_tmdb.ajax_url,
            type: 'POST',
            data: {
                action: 'tmdb_search',
                query: query,
                type: type,
                nonce: torofilm_tmdb.nonce
            },
            success: function(response) {
                console.log('TMDB Search Response:', response);
                if (response.success) {
                    currentResults = response.data;
                    displayResults(response.data, type);
                } else {
                    showError(response.data || 'Arama sonucu bulunamadı');
                }
            },
            error: function(xhr, status, error) {
                console.error('TMDB Search Error:', xhr.responseText);
                showError('Bir hata oluştu: ' + error);
            }
        });
    }
    
    /**
     * Display search results
     */
    function displayResults(results, type) {
        const resultsContainer = $('#tmdb-results');
        const resultsSection = $('.results-section');
        
        if (results.length === 0) {
            resultsContainer.html('<div class="no-results">Sonuç bulunamadı</div>');
            resultsSection.show();
            return;
        }
        
        let html = '';
        
        results.forEach(function(item) {
            const title = item.title || item.name;
            const year = item.release_date ? new Date(item.release_date).getFullYear() : 
                        item.first_air_date ? new Date(item.first_air_date).getFullYear() : '';
            const poster = item.poster_path ? 
                'https://image.tmdb.org/t/p/w300' + item.poster_path : 
                null;
            const overview = item.overview ? item.overview.substring(0, 100) + '...' : '';
            
            html += `
                <div class="tmdb-result-card" data-id="${item.id}" data-type="${type}">
                    <div class="tmdb-poster">
                        ${poster ? `<img src="${poster}" alt="${title}" />` : '<i class="fa fa-film"></i>'}
                    </div>
                    <div class="tmdb-info">
                        <div class="tmdb-title">${title}</div>
                        <div class="tmdb-year">${year}</div>
                        <div class="tmdb-overview">${overview}</div>
                        <div class="tmdb-id-display">
                            <span>ID: ${item.id}</span>
                            <button class="copy-id-btn" data-id="${item.id}">Kopyala</button>
                        </div>
                    </div>
                </div>
            `;
        });
        
        resultsContainer.html(html);
        resultsSection.show();
    }
    
    /**
     * Get movie/TV details
     */
    function getDetails(id, type) {
        showLoading();
        
        $.ajax({
            url: torofilm_tmdb.ajax_url,
            type: 'POST',
            data: {
                action: 'tmdb_get_details',
                id: id,
                type: type,
                nonce: torofilm_tmdb.nonce
            },
            success: function(response) {
                if (response.success) {
                    currentDetails = response.data;
                    displayDetails(response.data, type);
                } else {
                    showError(response.data || 'Detaylar alınamadı');
                }
            },
            error: function() {
                showError('Bir hata oluştu!');
            }
        });
    }
    
    /**
     * Display movie/TV details
     */
    function displayDetails(details, type) {
        const detailsContainer = $('#tmdb-details');
        const detailsSection = $('.details-section');
        
        const title = details.title || details.name;
        const year = details.release_date ? new Date(details.release_date).getFullYear() : 
                    details.first_air_date ? new Date(details.first_air_date).getFullYear() : '';
        const poster = details.poster_path ? 
            'https://image.tmdb.org/t/p/w500' + details.poster_path : 
            null;
        const overview = details.overview || '';
        const rating = details.vote_average || 0;
        const runtime = details.runtime || details.episode_run_time?.[0] || '';
        const genres = details.genres ? details.genres.map(g => g.name).join(', ') : '';
        
        const html = `
            <div class="tmdb-details-header">
                <div class="tmdb-details-poster">
                    ${poster ? `<img src="${poster}" alt="${title}" />` : '<i class="fa fa-film"></i>'}
                </div>
                <div class="tmdb-details-info">
                    <h1 class="tmdb-details-title">${title}</h1>
                    <div class="tmdb-details-meta">
                        <span><i class="fa fa-calendar"></i> ${year}</span>
                        <span><i class="fa fa-star"></i> ${rating}/10</span>
                        ${runtime ? `<span><i class="fa fa-clock-o"></i> ${runtime} dk</span>` : ''}
                    </div>
                    <div class="tmdb-details-overview">
                        <strong>Tür:</strong> ${genres}<br><br>
                        <strong>Özet:</strong><br>
                        ${overview}
                    </div>
                    <div class="tmdb-id-display">
                        <span><strong>TMDB ID:</strong> ${details.id}</span>
                        <button class="copy-tmdb-id-btn" data-id="${details.id}">Kopyala</button>
                    </div>
                    <div class="tmdb-actions">
                        <button class="tmdb-action-btn primary add-movie-btn" data-tmdb-id="${details.id}" data-type="${type}">
                            <i class="fa fa-plus"></i> Siteye Ekle
                        </button>
                        <button class="tmdb-action-btn" onclick="window.open('https://www.themoviedb.org/${type}/${details.id}', '_blank')">
                            <i class="fa fa-external-link"></i> TMDB'de Görüntüle
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        detailsContainer.html(html);
        detailsSection.show();
        
        // Scroll to details
        detailsSection[0].scrollIntoView({ behavior: 'smooth' });
    }
    
    /**
     * Add movie to site
     */
    function addMovieToSite(tmdbId, type) {
        const btn = $(`.add-movie-btn[data-tmdb-id="${tmdbId}"]`);
        const originalText = btn.html();
        
        btn.html('<i class="fa fa-spinner fa-spin"></i> Ekleniyor...').prop('disabled', true);
        
        $.ajax({
            url: torofilm_tmdb.ajax_url,
            type: 'POST',
            data: {
                action: 'tmdb_add_movie',
                tmdb_id: tmdbId,
                type: type,
                nonce: torofilm_tmdb.nonce
            },
            success: function(response) {
                if (response.success) {
                    showSuccess(`Film başarıyla eklendi! <a href="${response.data.edit_link}" target="_blank">Düzenle</a> | <a href="${response.data.view_link}" target="_blank">Görüntüle</a>`);
                    btn.html('<i class="fa fa-check"></i> Eklendi').removeClass('primary').addClass('success');
                } else {
                    showError(response.data || 'Film eklenemedi');
                    btn.html(originalText).prop('disabled', false);
                }
            },
            error: function() {
                showError('Bir hata oluştu!');
                btn.html(originalText).prop('disabled', false);
            }
        });
    }
    
    /**
     * Copy to clipboard
     */
    function copyToClipboard(text) {
        if (navigator.clipboard) {
            navigator.clipboard.writeText(text).then(function() {
                showSuccess('ID kopyalandı!');
            });
        } else {
            // Fallback for older browsers
            const textArea = document.createElement('textarea');
            textArea.value = text;
            document.body.appendChild(textArea);
            textArea.select();
            document.execCommand('copy');
            document.body.removeChild(textArea);
            showSuccess('ID kopyalandı!');
        }
    }
    
    /**
     * Show loading
     */
    function showLoading() {
        $('.results-section, .details-section').hide();
        $('.tmdb-results-grid, .tmdb-details-container').html('<div class="loading">Yükleniyor...</div>');
    }
    
    /**
     * Show error message
     */
    function showError(message) {
        $('.tmdb-results-grid, .tmdb-details-container').html(`
            <div class="error-message">
                <i class="fa fa-exclamation-triangle"></i> ${message}
            </div>
        `);
    }
    
    /**
     * Show success message
     */
    function showSuccess(message) {
        $('.tmdb-results-grid, .tmdb-details-container').html(`
            <div class="success-message">
                <i class="fa fa-check-circle"></i> ${message}
            </div>
        `);
    }
    
})(jQuery);
