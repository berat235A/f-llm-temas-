jQuery(document).ready(function($) {
    'use strict';
    
    let statsData = {};
    
    // Initialize
    init();
    
    function init() {
        loadGeneralStats();
        loadRecentContent();
        loadPopularContent();
        loadCategoryStats();
        
        // Tab switching
        $('.tab-btn').on('click', function() {
            const tab = $(this).data('tab');
            switchTab(tab);
        });
        
        // Auto refresh every 5 minutes
        setInterval(refreshStats, 300000);
        
        // Add refresh button
        addRefreshButton();
    }
    
    function loadGeneralStats() {
        $.ajax({
            url: torofilm_stats.ajax_url,
            type: 'POST',
            data: {
                action: 'get_stats_data',
                type: 'general',
                nonce: torofilm_stats.nonce
            },
            success: function(response) {
                if (response.success) {
                    statsData.general = response.data;
                    displayGeneralStats(response.data);
                }
            },
            error: function() {
                console.error('Failed to load general stats');
            }
        });
    }
    
    function displayGeneralStats(data) {
        // Update numbers with animation
        animateNumber('#total-movies', data.total_movies);
        animateNumber('#total-series', data.total_series);
        animateNumber('#total-users', data.total_users);
        animateNumber('#total-views', data.total_views);
        
        // Update changes
        updateChange('#movies-change', data.movies_change);
        updateChange('#series-change', data.series_change);
        updateChange('#users-change', data.users_change);
        updateChange('#views-change', data.views_change);
    }
    
    function animateNumber(selector, value) {
        const $element = $(selector);
        const start = 0;
        const end = parseInt(value);
        const duration = 2000;
        const increment = end / (duration / 16);
        
        let current = start;
        const timer = setInterval(function() {
            current += increment;
            if (current >= end) {
                current = end;
                clearInterval(timer);
            }
            
            if (selector === '#total-views') {
                $element.text(formatNumber(current));
            } else {
                $element.text(Math.floor(current));
            }
        }, 16);
    }
    
    function formatNumber(num) {
        if (num >= 1000000) {
            return (num / 1000000).toFixed(1) + 'M';
        } else if (num >= 1000) {
            return (num / 1000).toFixed(1) + 'K';
        }
        return Math.floor(num);
    }
    
    function updateChange(selector, change) {
        const $element = $(selector);
        const isPositive = change > 0;
        const isNegative = change < 0;
        
        $element.removeClass('positive negative');
        
        if (isPositive) {
            $element.addClass('positive').text('+' + change + '%');
        } else if (isNegative) {
            $element.addClass('negative').text(change + '%');
        } else {
            $element.text('0%');
        }
    }
    
    function loadRecentContent() {
        // Load recent movies
        $.ajax({
            url: torofilm_stats.ajax_url,
            type: 'POST',
            data: {
                action: 'get_stats_data',
                type: 'recent_movies',
                nonce: torofilm_stats.nonce
            },
            success: function(response) {
                if (response.success) {
                    displayRecentMovies(response.data);
                }
            }
        });
        
        // Load recent series
        $.ajax({
            url: torofilm_stats.ajax_url,
            type: 'POST',
            data: {
                action: 'get_stats_data',
                type: 'recent_series',
                nonce: torofilm_stats.nonce
            },
            success: function(response) {
                if (response.success) {
                    displayRecentSeries(response.data);
                }
            }
        });
    }
    
    function displayRecentMovies(movies) {
        const $container = $('#recent-movies-list');
        $container.empty();
        
        if (movies.length === 0) {
            $container.html('<div class="no-content">Henüz film eklenmemiş</div>');
            return;
        }
        
        movies.forEach(function(movie) {
            const item = createContentItem(movie, 'movie');
            $container.append(item);
        });
    }
    
    function displayRecentSeries(series) {
        const $container = $('#recent-series-list');
        $container.empty();
        
        if (series.length === 0) {
            $container.html('<div class="no-content">Henüz dizi eklenmemiş</div>');
            return;
        }
        
        series.forEach(function(serie) {
            const item = createContentItem(serie, 'series');
            $container.append(item);
        });
    }
    
    function loadPopularContent() {
        // Load popular movies
        $.ajax({
            url: torofilm_stats.ajax_url,
            type: 'POST',
            data: {
                action: 'get_stats_data',
                type: 'popular_movies',
                nonce: torofilm_stats.nonce
            },
            success: function(response) {
                if (response.success) {
                    displayPopularMovies(response.data);
                }
            }
        });
        
        // Load popular series
        $.ajax({
            url: torofilm_stats.ajax_url,
            type: 'POST',
            data: {
                action: 'get_stats_data',
                type: 'popular_series',
                nonce: torofilm_stats.nonce
            },
            success: function(response) {
                if (response.success) {
                    displayPopularSeries(response.data);
                }
            }
        });
    }
    
    function displayPopularMovies(movies) {
        const $container = $('#popular-movies-list');
        $container.empty();
        
        if (movies.length === 0) {
            $container.html('<div class="no-content">Henüz film eklenmemiş</div>');
            return;
        }
        
        movies.forEach(function(movie, index) {
            const item = createContentItem(movie, 'movie', index + 1);
            $container.append(item);
        });
    }
    
    function displayPopularSeries(series) {
        const $container = $('#popular-series-list');
        $container.empty();
        
        if (series.length === 0) {
            $container.html('<div class="no-content">Henüz dizi eklenmemiş</div>');
            return;
        }
        
        series.forEach(function(serie, index) {
            const item = createContentItem(serie, 'series', index + 1);
            $container.append(item);
        });
    }
    
    function createContentItem(item, type, rank = null) {
        const thumbnail = item.thumbnail || 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iODAiIHZpZXdCb3g9IjAgMCA2MCA4MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgd2lkdGg9IjYwIiBoZWlnaHQ9IjgwIiBmaWxsPSIjRjNGNEY2Ii8+CjxwYXRoIGQ9Ik0yMCAyNUg0MFY1NUgyMFYyNVoiIGZpbGw9IiNEMUQ1REIiLz4KPHBhdGggZD0iTTI1IDMwSDM1VjUwSDI1VjMwWiIgZmlsbD0iIzlDQTNBRiIvPgo8L3N2Zz4K';
        const date = new Date(item.date).toLocaleDateString('tr-TR');
        const views = formatNumber(item.views);
        const rating = item.rating !== 'N/A' ? item.rating : '-';
        
        return `
            <div class="content-item">
                ${rank ? `<div class="rank-badge">${rank}</div>` : ''}
                <img src="${thumbnail}" alt="${item.title}" class="content-thumbnail" />
                <div class="content-info">
                    <h4>${item.title}</h4>
                    <div class="content-meta">
                        <span class="views">👁️ ${views}</span>
                        <span class="rating">⭐ ${rating}</span>
                        <span class="date">📅 ${date}</span>
                    </div>
                </div>
            </div>
        `;
    }
    
    function loadCategoryStats() {
        $.ajax({
            url: torofilm_stats.ajax_url,
            type: 'POST',
            data: {
                action: 'get_stats_data',
                type: 'categories',
                nonce: torofilm_stats.nonce
            },
            success: function(response) {
                if (response.success) {
                    displayCategoryStats(response.data);
                }
            }
        });
    }
    
    function displayCategoryStats(categories) {
        const $container = $('#category-chart');
        $container.empty();
        
        if (categories.length === 0) {
            $container.html('<div class="no-content">Henüz kategori eklenmemiş</div>');
            return;
        }
        
        const maxCount = Math.max(...categories.map(cat => cat.count));
        
        categories.forEach(function(category) {
            const percentage = (category.count / maxCount) * 100;
            const item = `
                <div class="category-item">
                    <div class="category-name">${category.name}</div>
                    <div class="category-bar">
                        <div class="category-progress" style="width: ${percentage}%"></div>
                    </div>
                    <div class="category-count">${category.count}</div>
                </div>
            `;
            $container.append(item);
        });
    }
    
    function switchTab(tab) {
        // Update tab buttons
        $('.tab-btn').removeClass('active');
        $(`.tab-btn[data-tab="${tab}"]`).addClass('active');
        
        // Update tab content
        $('.tab-content').removeClass('active');
        $(`#${tab}`).addClass('active');
    }
    
    function refreshStats() {
        loadGeneralStats();
        loadRecentContent();
        loadPopularContent();
        loadCategoryStats();
        
        // Show refresh notification
        showNotification('İstatistikler güncellendi', 'success');
    }
    
    function addRefreshButton() {
        const refreshBtn = `
            <button class="refresh-btn" title="İstatistikleri Yenile">
                🔄
            </button>
        `;
        $('body').append(refreshBtn);
        
        $('.refresh-btn').on('click', function() {
            $(this).addClass('spinning');
            refreshStats();
            
            setTimeout(() => {
                $(this).removeClass('spinning');
            }, 1000);
        });
    }
    
    function showNotification(message, type = 'info') {
        const notification = `
            <div class="stats-notification ${type}">
                ${message}
            </div>
        `;
        
        $('body').append(notification);
        
        setTimeout(() => {
            $('.stats-notification').fadeOut(300, function() {
                $(this).remove();
            });
        }, 3000);
    }
    
    // Add spinning animation
    $('<style>')
        .prop('type', 'text/css')
        .html(`
            .refresh-btn.spinning {
                animation: spin 1s linear infinite;
            }
            
            @keyframes spin {
                from { transform: rotate(0deg); }
                to { transform: rotate(360deg); }
            }
            
            .stats-notification {
                position: fixed;
                top: 50px;
                right: 20px;
                background: #0073aa;
                color: white;
                padding: 15px 20px;
                border-radius: 6px;
                box-shadow: 0 4px 15px rgba(0,0,0,0.2);
                z-index: 1001;
                animation: slideIn 0.3s ease;
            }
            
            .stats-notification.success {
                background: #28a745;
            }
            
            .stats-notification.error {
                background: #dc3545;
            }
            
            @keyframes slideIn {
                from {
                    transform: translateX(100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
            
            .rank-badge {
                background: #0073aa;
                color: white;
                width: 30px;
                height: 30px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                font-weight: bold;
                font-size: 12px;
                flex-shrink: 0;
            }
            
            .no-content {
                text-align: center;
                padding: 40px;
                color: #666;
                font-style: italic;
            }
        `)
        .appendTo('head');
});