<?php
/**
 * Torofilm TMDB Admin
 * 
 * @package Torofilm
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class TOROFILM_TMDB_Admin {
    
    private $api_key;
    private $base_url = 'https://api.themoviedb.org/3';
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->api_key = get_option('torofilm_tmdb_api_key', '');
        
        // Gerçek TMDB API key (ücretsiz alabilirsiniz)
        if (empty($this->api_key)) {
            $this->api_key = 'f81980ff910e462a2dda05b55c16dade'; // Gerçek TMDB API key
        }
        
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_action('wp_ajax_tmdb_search', array($this, 'ajax_tmdb_search'));
        add_action('wp_ajax_tmdb_get_details', array($this, 'ajax_tmdb_get_details'));
        add_action('wp_ajax_tmdb_add_movie', array($this, 'ajax_tmdb_add_movie'));
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_submenu_page(
            'torofilm-video-hosting',
            'TMDB Film Arama',
            'TMDB Arama',
            'manage_options',
            'torofilm-tmdb-search',
            array($this, 'admin_page')
        );
    }
    
    /**
     * Register settings
     */
    public function register_settings() {
        register_setting('torofilm_tmdb_settings', 'torofilm_tmdb_api_key');
    }
    
    /**
     * Enqueue admin scripts
     */
    public function enqueue_admin_scripts($hook) {
        if ($hook !== 'video-hosting_page_torofilm-tmdb-search') {
            return;
        }
        
        wp_enqueue_style('torofilm-tmdb-admin', get_template_directory_uri() . '/admin/css/tmdb-admin.css', array(), TOROFILM_VERSION);
        wp_enqueue_script('torofilm-tmdb-admin', get_template_directory_uri() . '/admin/js/tmdb-admin.js', array('jquery'), TOROFILM_VERSION, true);
        
        wp_localize_script('torofilm-tmdb-admin', 'torofilm_tmdb', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('torofilm_tmdb_nonce')
        ));
    }
    
    /**
     * Admin page
     */
    public function admin_page() {
        ?>
        <div class="wrap">
            <h1>TMDB Film Arama</h1>
            <p class="description">The Movie Database'den film arayın ve sitenize ekleyin.</p>
            
            <?php if (empty($this->api_key)): ?>
                <div class="notice notice-warning">
                    <p><strong>TMDB API Key gerekli!</strong> <a href="https://www.themoviedb.org/settings/api" target="_blank">TMDB'den API key alın</a> ve aşağıya girin.</p>
                </div>
            <?php else: ?>
                <div class="notice notice-success">
                    <p><strong>TMDB API Key aktif!</strong> API key: <?php echo substr($this->api_key, 0, 8) . '...'; ?></p>
                </div>
            <?php endif; ?>
            
            <div class="tmdb-api-settings">
                <h3>TMDB API Ayarları</h3>
                <form method="post" action="options.php">
                    <?php settings_fields('torofilm_tmdb_settings'); ?>
                    <table class="form-table">
                        <tr>
                            <th scope="row">TMDB API Key</th>
                            <td>
                                <input type="text" name="torofilm_tmdb_api_key" value="<?php echo esc_attr($this->api_key); ?>" class="regular-text" placeholder="TMDB API Key'inizi girin" />
                                <p class="description">
                                    <a href="https://www.themoviedb.org/settings/api" target="_blank">TMDB'den ücretsiz API key alın</a>
                                </p>
                            </td>
                        </tr>
                    </table>
                    <?php submit_button('API Key Kaydet'); ?>
                </form>
            </div>
            
            <div class="tmdb-search-container">
                <div class="search-section">
                    <div class="search-form">
                        <input type="text" id="tmdb-search-input" class="regular-text" placeholder="Film adı girin..." />
                        <button type="button" id="tmdb-search-btn" class="button button-primary">
                            <i class="fa fa-search"></i> Ara
                        </button>
                        <button type="button" id="tmdb-test-btn" class="button">
                            <i class="fa fa-flask"></i> Test
                        </button>
                    </div>
                    
                    <div class="search-filters">
                        <label>
                            <input type="radio" name="search-type" value="movie" checked> Film
                        </label>
                        <label>
                            <input type="radio" name="search-type" value="tv"> Dizi
                        </label>
                        <label>
                            <input type="radio" name="search-type" value="person"> Kişi
                        </label>
                    </div>
                </div>
                
                <div class="results-section" style="display: none;">
                    <h2>Arama Sonuçları</h2>
                    <div id="tmdb-results" class="tmdb-results-grid"></div>
                </div>
                
                <div class="details-section" style="display: none;">
                    <h2>Film Detayları</h2>
                    <div id="tmdb-details" class="tmdb-details-container"></div>
                </div>
            </div>
        </div>
        
        <style>
        .tmdb-search-container {
            max-width: 1200px;
        }
        
        .search-section {
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .search-form {
            display: flex;
            gap: 10px;
            margin-bottom: 15px;
        }
        
        .search-form input {
            flex: 1;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        
        .search-form button {
            padding: 10px 20px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .search-filters {
            display: flex;
            gap: 20px;
        }
        
        .search-filters label {
            display: flex;
            align-items: center;
            gap: 5px;
            cursor: pointer;
        }
        
        .tmdb-results-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        
        .tmdb-result-card {
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            overflow: hidden;
            transition: transform 0.2s ease;
            cursor: pointer;
        }
        
        .tmdb-result-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        
        .tmdb-poster {
            width: 100%;
            height: 300px;
            background: #f0f0f0;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #666;
        }
        
        .tmdb-poster img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .tmdb-info {
            padding: 15px;
        }
        
        .tmdb-title {
            font-weight: bold;
            margin-bottom: 5px;
            color: #333;
        }
        
        .tmdb-year {
            color: #666;
            font-size: 14px;
        }
        
        .tmdb-overview {
            color: #666;
            font-size: 12px;
            margin-top: 8px;
            line-height: 1.4;
        }
        
        .tmdb-details-container {
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
        }
        
        .tmdb-details-header {
            display: flex;
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .tmdb-details-poster {
            width: 200px;
            height: 300px;
            background: #f0f0f0;
            border-radius: 8px;
            overflow: hidden;
        }
        
        .tmdb-details-poster img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .tmdb-details-info {
            flex: 1;
        }
        
        .tmdb-details-title {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 10px;
            color: #333;
        }
        
        .tmdb-details-meta {
            display: flex;
            gap: 20px;
            margin-bottom: 15px;
            color: #666;
        }
        
        .tmdb-details-overview {
            line-height: 1.6;
            margin-bottom: 20px;
        }
        
        .tmdb-actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        .tmdb-action-btn {
            padding: 8px 16px;
            border: 1px solid #ddd;
            background: #fff;
            border-radius: 4px;
            cursor: pointer;
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .tmdb-action-btn:hover {
            background: #f9f9f9;
        }
        
        .tmdb-action-btn.primary {
            background: #0073aa;
            color: #fff;
            border-color: #0073aa;
        }
        
        .tmdb-action-btn.primary:hover {
            background: #005a87;
        }
        
        .tmdb-id-display {
            background: #f0f0f0;
            padding: 10px;
            border-radius: 4px;
            font-family: monospace;
            margin: 10px 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .copy-btn {
            background: #28a745;
            color: #fff;
            border: none;
            padding: 5px 10px;
            border-radius: 3px;
            cursor: pointer;
            font-size: 12px;
        }
        
        .copy-btn:hover {
            background: #218838;
        }
        
        .loading {
            text-align: center;
            padding: 40px;
            color: #666;
        }
        
        .loading::after {
            content: '';
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid #f3f3f3;
            border-top: 3px solid #0073aa;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-left: 10px;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 15px;
            border-radius: 4px;
            margin: 20px 0;
        }
        
        .success-message {
            background: #d4edda;
            color: #155724;
            padding: 15px;
            border-radius: 4px;
            margin: 20px 0;
        }
        </style>
        <?php
    }
    
    /**
     * AJAX TMDB search
     */
    public function ajax_tmdb_search() {
        check_ajax_referer('torofilm_tmdb_nonce', 'nonce');
        
        if (empty($this->api_key)) {
            wp_send_json_error('TMDB API Key gerekli. Lütfen ayarlardan API key girin.');
        }
        
        $query = sanitize_text_field($_POST['query']);
        $type = sanitize_text_field($_POST['type']);
        
        if (empty($query)) {
            wp_send_json_error('Arama terimi gerekli');
        }
        
        $results = $this->search_tmdb($query, $type);
        
        if ($results) {
            wp_send_json_success($results);
        } else {
            wp_send_json_error('Arama sonucu bulunamadı veya API hatası');
        }
    }
    
    /**
     * AJAX TMDB get details
     */
    public function ajax_tmdb_get_details() {
        check_ajax_referer('torofilm_tmdb_nonce', 'nonce');
        
        $id = intval($_POST['id']);
        $type = sanitize_text_field($_POST['type']);
        
        if (empty($id)) {
            wp_send_json_error('ID gerekli');
        }
        
        $details = $this->get_tmdb_details($id, $type);
        
        if ($details) {
            wp_send_json_success($details);
        } else {
            wp_send_json_error('Detaylar alınamadı');
        }
    }
    
    /**
     * AJAX TMDB add movie
     */
    public function ajax_tmdb_add_movie() {
        check_ajax_referer('torofilm_tmdb_nonce', 'nonce');
        
        $tmdb_id = intval($_POST['tmdb_id']);
        $type = sanitize_text_field($_POST['type']);
        
        if (empty($tmdb_id)) {
            wp_send_json_error('TMDB ID gerekli');
        }
        
        $result = $this->add_movie_from_tmdb($tmdb_id, $type);
        
        if ($result) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error('Film eklenemedi');
        }
    }
    
    /**
     * Search TMDB
     */
    private function search_tmdb($query, $type = 'movie') {
        $url = $this->base_url . '/search/' . $type . '?api_key=' . $this->api_key . '&query=' . urlencode($query) . '&language=tr-TR&page=1';
        
        $response = wp_remote_get($url, array(
            'timeout' => 30,
            'headers' => array(
                'Accept' => 'application/json'
            )
        ));
        
        if (is_wp_error($response)) {
            error_log('TMDB API Error: ' . $response->get_error_message());
            return false;
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        if ($response_code !== 200) {
            error_log('TMDB API HTTP Error: ' . $response_code);
            return false;
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (isset($data['results'])) {
            return $data['results'];
        }
        
        if (isset($data['status_message'])) {
            error_log('TMDB API Error: ' . $data['status_message']);
        }
        
        return false;
    }
    
    /**
     * Get TMDB details
     */
    private function get_tmdb_details($id, $type = 'movie') {
        $url = $this->base_url . '/' . $type . '/' . $id . '?api_key=' . $this->api_key . '&language=tr-TR';
        
        $response = wp_remote_get($url, array(
            'timeout' => 30,
            'headers' => array(
                'Accept' => 'application/json'
            )
        ));
        
        if (is_wp_error($response)) {
            error_log('TMDB Details API Error: ' . $response->get_error_message());
            return false;
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        if ($response_code !== 200) {
            error_log('TMDB Details API HTTP Error: ' . $response_code);
            return false;
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (isset($data['status_message'])) {
            error_log('TMDB Details API Error: ' . $data['status_message']);
            return false;
        }
        
        return $data;
    }
    
    /**
     * Add movie from TMDB
     */
    private function add_movie_from_tmdb($tmdb_id, $type = 'movie') {
        $details = $this->get_tmdb_details($tmdb_id, $type);
        
        if (!$details) {
            return false;
        }
        
        $post_type = ($type === 'tv') ? 'series' : 'movies';
        
        $post_data = array(
            'post_title' => $details['title'] ?? $details['name'],
            'post_content' => $details['overview'] ?? '',
            'post_status' => 'publish',
            'post_type' => $post_type,
            'post_author' => get_current_user_id()
        );
        
        $post_id = wp_insert_post($post_data);
        
        if ($post_id && !is_wp_error($post_id)) {
            // TMDB ID'yi kaydet
            update_post_meta($post_id, 'tmdb_id', $tmdb_id);
            
            // Yıl bilgisini kaydet
            $release_date = $details['release_date'] ?? $details['first_air_date'];
            if ($release_date) {
                $year = date('Y', strtotime($release_date));
                update_post_meta($post_id, 'field_release_year', $year);
            }
            
            // Rating bilgisini kaydet
            if (isset($details['vote_average'])) {
                update_post_meta($post_id, 'rating', $details['vote_average']);
            }
            
            // Varsayılan değerler
            update_post_meta($post_id, 'views', 0);
            
            return array(
                'post_id' => $post_id,
                'title' => $post_data['post_title'],
                'edit_link' => get_edit_post_link($post_id),
                'view_link' => get_permalink($post_id)
            );
        }
        
        return false;
    }
}

// Initialize the class
new TOROFILM_TMDB_Admin();
