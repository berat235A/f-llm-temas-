<?php
class TOROFILM_Admin {
    private $theme_name;
    private $version;
    private $build_menupage;
    private $helpers;
    public function __construct( $theme_name, $version ) {
        $this->theme_name     = $theme_name;
        $this->version        = $version;
        
        // Platform meta boxes
        add_action('add_meta_boxes', array($this, 'add_platform_meta_boxes'));
        add_action('save_post', array($this, 'save_platform_meta_box'));
    }
    public function enqueue_styles( $hook ) {
        #Styles General Admin
        wp_enqueue_style( 'peli_wordpress_admin_css', TOROFILM_DIR_URI . 'admin/css/torofilm-wordpress-global.css', array(), $this->version, 'all' );
        #Style for series admin pages
        if( strpos($hook, 'torofilm-series') !== false ) {
            wp_enqueue_style( 'torofilm_series_admin_css', TOROFILM_DIR_URI . 'admin/css/torofilm-series-admin.css', array(), $this->version, 'all' );
        }
    }
    public function enqueue_scripts( $hook ) {
        wp_enqueue_script( 'peli_wordpress_admin_js', TOROFILM_DIR_URI . 'admin/js/torofilm-wordpress-global.js', [ 'jquery' ], $this->version, true );
        /**
         * Condicional para controlar la carga de los archivos
         * solamente en la página del plugin
         */
        if( strpos($hook, 'torofilm-series') !== false ) {
            wp_enqueue_media();
        }
    }
    /*ADD MENU PAGE ADMIN*/
    /**
     * Añade los Menus para mostrarlos
     * en el front end
     *  L Menu Header 
     *  L Menu Mobile
     */
    public function torofilm_register_menus() {
        register_nav_menus
        (
            array(
                'header' => 'Menu Header',
                'footer' => 'Menu Footer',
                'tags'   => 'Tags Footer'
            )
        );
    }

    /**
     * Add admin menu for Series Management
     */
    public function add_admin_menu() {
        add_menu_page(
            'Seri Film Yönetimi',
            'Seri Filmler',
            'manage_options',
            'torofilm-series',
            array($this, 'series_admin_page'),
            'dashicons-video-alt3',
            30
        );
        
        add_submenu_page(
            'torofilm-series',
            'Seri Film Ekle',
            'Yeni Seri Film',
            'manage_options',
            'torofilm-add-series',
            array($this, 'add_series_page')
        );
        
        add_submenu_page(
            'torofilm-series',
            'Film-Seri İlişkileri',
            'Film-Seri Bağlantıları',
            'manage_options',
            'torofilm-movie-series',
            array($this, 'movie_series_relations_page')
        );
        
        add_submenu_page(
            'torofilm-series',
            'Hızlı Film Ekle',
            'Hızlı Film Ekle',
            'manage_options',
            'torofilm-quick-add-movie',
            array($this, 'quick_add_movie_page')
        );
        
        add_submenu_page(
            'torofilm-series',
            'Platform Yönetimi',
            'Platform Yönetimi',
            'manage_options',
            'torofilm-platforms',
            array($this, 'platforms_page')
        );
    }

    /**
     * Series admin page
     */
    public function series_admin_page() {
        // Test seri filmi oluştur
        $this->create_test_series();
        ?>
        <div class="wrap">
            <h1>Seri Film Yönetimi</h1>
            <div class="torofilm-admin-dashboard">
                <div class="admin-stats">
                    <div class="stat-box">
                        <h3>Toplam Seri Film</h3>
                        <span class="stat-number"><?php 
                            $series_count = wp_count_terms('series_collection', array('hide_empty' => false));
                            echo $series_count ? $series_count : 0;
                        ?></span>
                    </div>
                    <div class="stat-box">
                        <h3>Toplam Film</h3>
                        <span class="stat-number"><?php echo wp_count_posts('movies')->publish; ?></span>
                    </div>
                    <div class="stat-box">
                        <h3>Bağlantılı Filmler</h3>
                        <span class="stat-number"><?php echo $this->get_connected_movies_count(); ?></span>
                    </div>
                </div>
                
                <div class="admin-actions">
                    <a href="<?php echo admin_url('admin.php?page=torofilm-quick-add-movie'); ?>" class="button button-primary">
                        <i class="dashicons dashicons-video-alt2"></i> Hızlı Film Ekle
                    </a>
                    <a href="<?php echo admin_url('admin.php?page=torofilm-add-series'); ?>" class="button">
                        <i class="dashicons dashicons-plus-alt"></i> Yeni Seri Film Ekle
                    </a>
                    <a href="<?php echo admin_url('admin.php?page=torofilm-movie-series'); ?>" class="button">
                        <i class="dashicons dashicons-admin-links"></i> Film-Seri Bağlantıları
                    </a>
                    <a href="<?php echo admin_url('edit-tags.php?taxonomy=series_collection'); ?>" class="button">
                        <i class="dashicons dashicons-admin-tools"></i> Seri Filmleri Yönet
                    </a>
                </div>
                
                <div class="recent-series">
                    <h2>Son Eklenen Seri Filmler</h2>
                    <?php $this->display_recent_series(); ?>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Add series page
     */
    public function add_series_page() {
        if (isset($_POST['submit_series'])) {
            $this->save_series();
        }
        ?>
        <div class="wrap">
            <h1>Yeni Seri Film Ekle</h1>
            <form method="post" action="">
                <?php wp_nonce_field('torofilm_series_nonce', 'series_nonce'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">Seri Film Adı</th>
                        <td>
                            <input type="text" name="series_name" class="regular-text" required />
                            <p class="description">Seri filmin adını girin (örn: Marvel Sinematik Evreni)</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Açıklama</th>
                        <td>
                            <textarea name="series_description" rows="5" cols="50" class="large-text"></textarea>
                            <p class="description">Seri film hakkında kısa açıklama</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Seri Resmi</th>
                        <td>
                            <input type="text" name="series_image" id="series_image" class="regular-text" />
                            <input type="button" class="button" value="Resim Seç" onclick="selectSeriesImage()" />
                            <p class="description">Seri film için kapak resmi</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Durum</th>
                        <td>
                            <select name="series_status">
                                <option value="active">Aktif</option>
                                <option value="inactive">Pasif</option>
                            </select>
                        </td>
                    </tr>
                </table>
                
                <?php submit_button('Seri Film Ekle', 'primary', 'submit_series'); ?>
            </form>
        </div>
        
        <script>
        function selectSeriesImage() {
            var frame = wp.media({
                title: 'Seri Film Resmi Seç',
                button: {
                    text: 'Seç'
                },
                multiple: false
            });
            
            frame.on('select', function() {
                var attachment = frame.state().get('selection').first().toJSON();
                document.getElementById('series_image').value = attachment.url;
            });
            
            frame.open();
        }
        </script>
        <?php
    }

    /**
     * Movie-Series relations page
     */
    public function movie_series_relations_page() {
        if (isset($_POST['submit_relation'])) {
            $this->save_movie_series_relation();
        }
        
        // Test bağlantıları oluştur
        $this->create_test_relations();
        ?>
        <div class="wrap">
            <h1>Film-Seri Bağlantıları</h1>
            
            <form method="post" action="">
                <?php wp_nonce_field('torofilm_relation_nonce', 'relation_nonce'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">Film Seç</th>
                        <td>
                            <select name="movie_id" required>
                                <option value="">Film Seçin</option>
                                <?php
                                $movies = get_posts(array(
                                    'post_type' => 'movies',
                                    'posts_per_page' => -1,
                                    'post_status' => 'publish'
                                ));
                                foreach ($movies as $movie) {
                                    echo '<option value="' . $movie->ID . '">' . $movie->post_title . '</option>';
                                }
                                ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Seri Film Seç</th>
                        <td>
                            <select name="series_id" required>
                                <option value="">Seri Film Seçin</option>
                                <?php
                                $series = get_terms(array(
                                    'taxonomy' => 'series_collection',
                                    'hide_empty' => false
                                ));
                                foreach ($series as $serie) {
                                    echo '<option value="' . $serie->term_id . '">' . $serie->name . '</option>';
                                }
                                ?>
                            </select>
                        </td>
                    </tr>
                </table>
                
                <?php submit_button('Bağlantı Ekle', 'primary', 'submit_relation'); ?>
            </form>
            
            <hr>
            
            <h2>Mevcut Bağlantılar</h2>
            <?php $this->display_movie_series_relations(); ?>
        </div>
        <?php
    }

    /**
     * Save series
     */
    private function save_series() {
        if (!wp_verify_nonce($_POST['series_nonce'], 'torofilm_series_nonce')) {
            wp_die('Güvenlik hatası!');
        }
        
        $series_name = sanitize_text_field($_POST['series_name']);
        $series_description = sanitize_textarea_field($_POST['series_description']);
        $series_image = esc_url_raw($_POST['series_image']);
        $series_status = sanitize_text_field($_POST['series_status']);
        
        $term = wp_insert_term(
            $series_name,
            'series_collection',
            array(
                'description' => $series_description,
                'slug' => sanitize_title($series_name)
            )
        );
        
        if (!is_wp_error($term)) {
            update_term_meta($term['term_id'], 'series_image', $series_image);
            update_term_meta($term['term_id'], 'series_status', $series_status);
            
            echo '<div class="notice notice-success"><p>Seri film başarıyla eklendi!</p></div>';
        } else {
            echo '<div class="notice notice-error"><p>Hata: ' . $term->get_error_message() . '</p></div>';
        }
    }

    /**
     * Save movie-series relation
     */
    private function save_movie_series_relation() {
        if (!wp_verify_nonce($_POST['relation_nonce'], 'torofilm_relation_nonce')) {
            wp_die('Güvenlik hatası!');
        }
        
        $movie_id = intval($_POST['movie_id']);
        $series_id = intval($_POST['series_id']);
        
        $result = wp_set_post_terms($movie_id, array($series_id), 'series_collection', true);
        
        if (!is_wp_error($result)) {
            echo '<div class="notice notice-success"><p>Film-seri bağlantısı başarıyla eklendi!</p></div>';
        } else {
            echo '<div class="notice notice-error"><p>Hata: ' . $result->get_error_message() . '</p></div>';
        }
    }

    /**
     * Get connected movies count
     */
    private function get_connected_movies_count() {
        global $wpdb;
        $count = $wpdb->get_var("
            SELECT COUNT(DISTINCT p.ID) 
            FROM {$wpdb->posts} p 
            INNER JOIN {$wpdb->term_relationships} tr ON p.ID = tr.object_id 
            INNER JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id = tt.term_taxonomy_id 
            WHERE p.post_type = 'movies' 
            AND p.post_status = 'publish' 
            AND tt.taxonomy = 'series_collection'
        ");
        return $count ? $count : 0;
    }

    /**
     * Display recent series
     */
    private function display_recent_series() {
        $series = get_terms(array(
            'taxonomy' => 'series_collection',
            'hide_empty' => false,
            'number' => 10,
            'orderby' => 'term_id',
            'order' => 'DESC'
        ));
        
        if (!empty($series)) {
            echo '<table class="wp-list-table widefat fixed striped">';
            echo '<thead><tr><th>Seri Adı</th><th>Film Sayısı</th><th>Durum</th><th>İşlemler</th></tr></thead>';
            echo '<tbody>';
            
            foreach ($series as $serie) {
                $film_count = $serie->count;
                $status = get_term_meta($serie->term_id, 'series_status', true);
                $status_text = $status === 'active' ? 'Aktif' : 'Pasif';
                
                echo '<tr>';
                echo '<td><strong>' . $serie->name . '</strong></td>';
                echo '<td>' . $film_count . '</td>';
                echo '<td>' . $status_text . '</td>';
                echo '<td><a href="' . admin_url('edit-tags.php?taxonomy=series_collection&tag_ID=' . $serie->term_id) . '">Düzenle</a></td>';
                echo '</tr>';
            }
            
            echo '</tbody></table>';
        } else {
            echo '<p>Henüz seri film eklenmemiş.</p>';
        }
    }

    /**
     * Display movie-series relations
     */
    private function display_movie_series_relations() {
        global $wpdb;
        
        $relations = $wpdb->get_results("
            SELECT p.ID, p.post_title, t.name as series_name, t.term_id as series_id
            FROM {$wpdb->posts} p 
            INNER JOIN {$wpdb->term_relationships} tr ON p.ID = tr.object_id 
            INNER JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id = tt.term_taxonomy_id 
            INNER JOIN {$wpdb->terms} t ON tt.term_id = t.term_id
            WHERE p.post_type = 'movies' 
            AND p.post_status = 'publish' 
            AND tt.taxonomy = 'series_collection'
            ORDER BY t.name, p.post_title
        ");
        
        if (!empty($relations)) {
            echo '<table class="wp-list-table widefat fixed striped">';
            echo '<thead><tr><th>Film</th><th>Seri Film</th><th>İşlemler</th></tr></thead>';
            echo '<tbody>';
            
            foreach ($relations as $relation) {
                echo '<tr>';
                echo '<td><strong>' . $relation->post_title . '</strong></td>';
                echo '<td>' . $relation->series_name . '</td>';
                echo '<td><a href="' . get_edit_post_link($relation->ID) . '">Film Düzenle</a></td>';
                echo '</tr>';
            }
            
            echo '</tbody></table>';
        } else {
            echo '<p>Henüz film-seri bağlantısı eklenmemiş.</p>';
        }
    }

    /**
     * Create test series for demonstration
     */
    private function create_test_series() {
        // Test seri filmleri oluştur
        $test_series = array(
            'Marvel Sinematik Evreni' => 'Marvel karakterlerinin yer aldığı film serisi',
            'DC Extended Universe' => 'DC Comics karakterlerinin film serisi',
            'Fast & Furious' => 'Hızlı araba filmleri serisi',
            'Transformers' => 'Robot dönüşüm filmleri serisi',
            'Mission Impossible' => 'Ethan Hunt maceraları serisi'
        );

        foreach ($test_series as $name => $description) {
            // Seri film zaten var mı kontrol et
            $existing = get_term_by('name', $name, 'series_collection');
            if (!$existing) {
                $term = wp_insert_term(
                    $name,
                    'series_collection',
                    array(
                        'description' => $description,
                        'slug' => sanitize_title($name)
                    )
                );
                
                if (!is_wp_error($term)) {
                    update_term_meta($term['term_id'], 'series_status', 'active');
                }
            }
        }
    }

    /**
     * Quick add movie page
     */
    public function quick_add_movie_page() {
        if (isset($_POST['submit_movie'])) {
            $this->save_quick_movie();
        }
        ?>
        <div class="wrap">
            <h1>Hızlı Film Ekle</h1>
            <p class="description">Sadece film adını girerek hızlıca film ekleyebilirsiniz. Diğer bilgileri daha sonra düzenleyebilirsiniz.</p>
            <p><a href="<?php echo home_url(); ?>" target="_blank" class="button">Ana Sayfayı Görüntüle</a></p>
            
            <form method="post" action="">
                <?php wp_nonce_field('torofilm_movie_nonce', 'movie_nonce'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">Film Adı</th>
                        <td>
                            <input type="text" name="movie_title" class="regular-text" required placeholder="Film adını girin..." />
                            <p class="description">Eklemek istediğiniz filmin adını girin</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Yayın Yılı</th>
                        <td>
                            <input type="number" name="movie_year" class="small-text" min="1900" max="<?php echo date('Y') + 5; ?>" placeholder="<?php echo date('Y'); ?>" />
                            <p class="description">Filmin yayın yılı (opsiyonel)</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Açıklama</th>
                        <td>
                            <textarea name="movie_description" rows="3" cols="50" class="large-text" placeholder="Film hakkında kısa açıklama..."></textarea>
                            <p class="description">Film hakkında kısa açıklama (opsiyonel)</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Video URL'leri</th>
                        <td>
                            <div class="video-urls-container">
                                <div class="video-url-group">
                                    <label>Ana Video URL:</label>
                                    <input type="url" name="movie_video_url" class="regular-text" placeholder="https://vidmoly.net/xxxxxxxxx" />
                                    <p class="description">Ana video URL'si (Vidmoly, FileMoon, StreamWish, vs.)</p>
                                </div>
                                
                                <div class="video-url-group">
                                    <label>Alternatif Video URL:</label>
                                    <input type="url" name="movie_video_url_alt" class="regular-text" placeholder="https://filemoon.sx/e/xxxxxxxxx" />
                                    <p class="description">Alternatif video URL'si (opsiyonel)</p>
                                </div>
                                
                                <div class="video-url-group">
                                    <label>YouTube Trailer:</label>
                                    <input type="url" name="movie_trailer_url" class="regular-text" placeholder="https://youtube.com/watch?v=xxxxxxxxx" />
                                    <p class="description">YouTube trailer URL'si (opsiyonel)</p>
                                </div>
                            </div>
                        </td>
                    </tr>
                </table>
                
                <?php submit_button('Film Ekle', 'primary', 'submit_movie'); ?>
            </form>
            
            <hr>
            
            <h2>Son Eklenen Filmler</h2>
            <?php $this->display_recent_movies(); ?>
        </div>
        <?php
    }

    /**
     * Save quick movie
     */
    private function save_quick_movie() {
        if (!wp_verify_nonce($_POST['movie_nonce'], 'torofilm_movie_nonce')) {
            wp_die('Güvenlik hatası!');
        }
        
        $movie_title = sanitize_text_field($_POST['movie_title']);
        $movie_year = sanitize_text_field($_POST['movie_year']);
        $movie_description = sanitize_textarea_field($_POST['movie_description']);
        $movie_video_url = sanitize_url($_POST['movie_video_url'] ?? '');
        $movie_video_url_alt = sanitize_url($_POST['movie_video_url_alt'] ?? '');
        $movie_trailer_url = sanitize_url($_POST['movie_trailer_url'] ?? '');
        
        if (empty($movie_title)) {
            echo '<div class="notice notice-error"><p>Film adı gereklidir!</p></div>';
            return;
        }
        
        // Film zaten var mı kontrol et
        $existing_movie = get_page_by_title($movie_title, OBJECT, 'movies');
        if ($existing_movie) {
            echo '<div class="notice notice-warning"><p>Bu film zaten mevcut: <a href="' . get_edit_post_link($existing_movie->ID) . '">' . $movie_title . '</a></p></div>';
            return;
        }
        
        $post_data = array(
            'post_title' => $movie_title,
            'post_content' => $movie_description,
            'post_status' => 'publish',
            'post_type' => 'movies',
            'post_author' => get_current_user_id()
        );
        
        $post_id = wp_insert_post($post_data);
        
        if ($post_id && !is_wp_error($post_id)) {
            // Yıl bilgisini ekle
            if (!empty($movie_year)) {
                update_post_meta($post_id, 'field_release_year', $movie_year);
            }
            
            // Varsayılan değerler
            update_post_meta($post_id, 'views', 0);
            update_post_meta($post_id, 'rating', 0);
            
            // Video URL'lerini kaydet
            if (!empty($movie_video_url)) {
                update_post_meta($post_id, 'movie_video_url', $movie_video_url);
            }
            if (!empty($movie_video_url_alt)) {
                update_post_meta($post_id, 'movie_video_url_alt', $movie_video_url_alt);
            }
            if (!empty($movie_trailer_url)) {
                update_post_meta($post_id, 'movie_trailer_url', $movie_trailer_url);
            }
            
            echo '<div class="notice notice-success"><p>Film başarıyla eklendi! <a href="' . get_edit_post_link($post_id) . '">Film düzenle</a> | <a href="' . get_permalink($post_id) . '">Filmi görüntüle</a></p></div>';
        } else {
            echo '<div class="notice notice-error"><p>Film eklenirken hata oluştu!</p></div>';
        }
    }

    /**
     * Display recent movies
     */
    private function display_recent_movies() {
        $movies = get_posts(array(
            'post_type' => 'movies',
            'posts_per_page' => 10,
            'post_status' => 'publish',
            'orderby' => 'date',
            'order' => 'DESC'
        ));
        
        if (!empty($movies)) {
            echo '<table class="wp-list-table widefat fixed striped">';
            echo '<thead><tr><th>Film Adı</th><th>Yıl</th><th>Eklenme Tarihi</th><th>İşlemler</th></tr></thead>';
            echo '<tbody>';
            
            foreach ($movies as $movie) {
                $year = get_post_meta($movie->ID, 'field_release_year', true);
                $year_display = $year ? $year : '-';
                $date = get_the_date('d.m.Y H:i', $movie->ID);
                
                echo '<tr>';
                echo '<td><strong>' . $movie->post_title . '</strong></td>';
                echo '<td>' . $year_display . '</td>';
                echo '<td>' . $date . '</td>';
                echo '<td>';
                echo '<a href="' . get_edit_post_link($movie->ID) . '">Düzenle</a> | ';
                echo '<a href="' . get_permalink($movie->ID) . '" target="_blank">Görüntüle</a>';
                echo '</td>';
                echo '</tr>';
            }
            
            echo '</tbody></table>';
        } else {
            echo '<p>Henüz film eklenmemiş.</p>';
        }
    }

    /**
     * Create test movie-series relations
     */
    private function create_test_relations() {
        // Marvel serisi için test filmleri
        $marvel_series = get_term_by('name', 'Marvel Sinematik Evreni', 'series_collection');
        if ($marvel_series) {
            $marvel_movies = get_posts(array(
                'post_type' => 'movies',
                'posts_per_page' => 3,
                'post_status' => 'publish',
                'meta_query' => array(
                    array(
                        'key' => 'field_release_year',
                        'value' => '2010',
                        'compare' => '>='
                    )
                )
            ));
            
            foreach ($marvel_movies as $movie) {
                wp_set_post_terms($movie->ID, array($marvel_series->term_id), 'series_collection', true);
            }
        }
    }
    
    /**
     * Platforms management page
     */
    public function platforms_page() {
        if (isset($_POST['add_platform']) && wp_verify_nonce($_POST['platform_nonce'], 'torofilm_platform_nonce')) {
            $this->save_platform();
        }
        
        if (isset($_POST['delete_platform']) && wp_verify_nonce($_POST['delete_nonce'], 'torofilm_delete_platform')) {
            $this->delete_platform();
        }
        
        if (isset($_POST['edit_platform']) && wp_verify_nonce($_POST['edit_platform_nonce'], 'torofilm_edit_platform_nonce')) {
            $this->edit_platform();
        }
        
        $platforms = get_option('torofilm_platforms', array());
        ?>
        <div class="wrap">
            <h1>Platform Yönetimi</h1>
            
            <?php if (isset($_POST['flush_rewrite_rules']) && wp_verify_nonce($_POST['flush_nonce'], 'flush_rewrite_rules')): ?>
                <?php
                flush_rewrite_rules();
                echo '<div class="notice notice-success"><p>Rewrite rules başarıyla yenilendi!</p></div>';
                ?>
            <?php endif; ?>
            
            <div class="platform-admin-actions">
                <form method="post" style="display: inline;">
                    <?php wp_nonce_field('flush_rewrite_rules', 'flush_nonce'); ?>
                    <button type="submit" name="flush_rewrite_rules" class="button button-secondary" onclick="return confirm('Rewrite rules yenilenecek. Devam etmek istediğinizden emin misiniz?');">
                        <i class="fa fa-refresh"></i> Rewrite Rules Yenile
                    </button>
                </form>
                <span class="description" style="margin-left: 10px;">Platform sayfaları açılmıyorsa bu butona tıklayın.</span>
            </div>
            
            <div class="platform-management">
                <div class="add-platform-section">
                    <h2 id="form-title">Yeni Platform Ekle</h2>
                    <form method="post" action="" id="platform-form">
                        <?php wp_nonce_field('torofilm_platform_nonce', 'platform_nonce'); ?>
                        <?php wp_nonce_field('torofilm_edit_platform_nonce', 'edit_platform_nonce'); ?>
                        <input type="hidden" name="editing_platform_id" id="editing_platform_id" value="">
                        <table class="form-table">
                            <tr>
                                <th scope="row">Platform Adı</th>
                                <td><input type="text" name="platform_name" id="platform_name" required class="regular-text" placeholder="Netflix, Prime Video, vb."></td>
                            </tr>
                            <tr>
                                <th scope="row">Platform URL</th>
                                <td><input type="url" name="platform_url" id="platform_url" class="regular-text" placeholder="https://netflix.com"></td>
                            </tr>
                            <tr>
                                <th scope="row">Platform Rengi</th>
                                <td><input type="color" name="platform_color" id="platform_color" value="#E50914" class="regular-text"></td>
                            </tr>
                            <tr>
                                <th scope="row">Platform İkonu</th>
                                <td>
                                    <select name="platform_icon" id="platform_icon" class="regular-text">
                                        <option value="fa-play">Play (▶)</option>
                                        <option value="fa-tv">TV</option>
                                        <option value="fa-video-camera">Video Camera</option>
                                        <option value="fa-film">Film</option>
                                        <option value="fa-desktop">Desktop</option>
                                        <option value="fa-laptop">Laptop</option>
                                        <option value="fa-mobile">Mobile</option>
                                        <option value="fa-tablet">Tablet</option>
                                        <option value="fa-globe">Globe</option>
                                        <option value="fa-star">Star</option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Platform Logosu</th>
                                <td>
                                    <input type="hidden" name="platform_logo" id="platform_logo" value="">
                                    <div id="platform_logo_preview" style="margin-bottom: 10px;"></div>
                                    <button type="button" class="button" onclick="selectPlatformLogo()">Logo Seç</button>
                                    <button type="button" class="button" onclick="removePlatformLogo()" style="margin-left: 10px;">Logoyu Kaldır</button>
                                    <p class="description">Platform logosu için PNG, JPG veya SVG formatında görsel yükleyebilirsiniz.</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Açıklama</th>
                                <td><textarea name="platform_description" id="platform_description" class="large-text" rows="3" placeholder="Platform hakkında kısa açıklama"></textarea></td>
                            </tr>
                        </table>
                        <div id="form-buttons">
                            <?php submit_button('Platform Ekle', 'primary', 'add_platform'); ?>
                        </div>
                    </form>
                </div>
                
                <div class="platforms-list-section">
                    <h2>Mevcut Platformlar</h2>
                    <?php if (!empty($platforms)): ?>
                        <table class="wp-list-table widefat fixed striped">
                            <thead>
                                <tr>
                                    <th>Platform</th>
                                    <th>Renk</th>
                                    <th>İkon</th>
                                    <th>Logo</th>
                                    <th>URL</th>
                                    <th>İçerikler</th>
                                    <th>İşlemler</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($platforms as $id => $platform): ?>
                                    <tr>
                                        <td>
                                            <strong><?php echo esc_html($platform['name']); ?></strong>
                                            <?php if (!empty($platform['description'])): ?>
                                                <br><small><?php echo esc_html($platform['description']); ?></small>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span style="display: inline-block; width: 20px; height: 20px; background: <?php echo esc_attr($platform['color']); ?>; border-radius: 3px;"></span>
                                            <?php echo esc_html($platform['color']); ?>
                                        </td>
                                        <td><i class="fa <?php echo esc_attr($platform['icon']); ?>"></i> <?php echo esc_html($platform['icon']); ?></td>
                                        <td>
                                            <?php if (!empty($platform['logo'])): ?>
                                                <img src="<?php echo esc_url($platform['logo']); ?>" alt="<?php echo esc_attr($platform['name']); ?>" style="width: 40px; height: 40px; object-fit: contain; border-radius: 5px;">
                                            <?php else: ?>
                                                <span class="description">Logo yok</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if (!empty($platform['url'])): ?>
                                                <a href="<?php echo esc_url($platform['url']); ?>" target="_blank"><?php echo esc_html($platform['url']); ?></a>
                                            <?php else: ?>
                                                <span class="description">URL yok</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php
                                            // Bu platformda bulunan film ve dizi sayılarını hesapla
                                            $movies_count = 0;
                                            $series_count = 0;
                                            
                                            // Filmler
                                            $movies_query = new WP_Query(array(
                                                'post_type' => 'movies',
                                                'posts_per_page' => -1,
                                                'meta_query' => array(
                                                    array(
                                                        'key' => '_torofilm_platforms',
                                                        'value' => $id,
                                                        'compare' => 'LIKE'
                                                    )
                                                )
                                            ));
                                            $movies_count = $movies_query->found_posts;
                                            
                                            // Diziler
                                            $series_query = new WP_Query(array(
                                                'post_type' => 'series',
                                                'posts_per_page' => -1,
                                                'meta_query' => array(
                                                    array(
                                                        'key' => '_torofilm_platforms',
                                                        'value' => $id,
                                                        'compare' => 'LIKE'
                                                    )
                                                )
                                            ));
                                            $series_count = $series_query->found_posts;
                                            
                                            $total_content = $movies_count + $series_count;
                                            ?>
                                            <div class="platform-content-stats">
                                                <div class="content-count">
                                                    <strong><?php echo $total_content; ?></strong> içerik
                                                </div>
                                                <div class="content-breakdown">
                                                    <span class="movies-count"><?php echo $movies_count; ?> film</span>
                                                    <span class="series-count"><?php echo $series_count; ?> dizi</span>
                                                </div>
                                                <button class="button button-small" onclick="openContentManager('<?php echo esc_attr($id); ?>', '<?php echo esc_attr($platform['name']); ?>')">
                                                    <i class="fa fa-edit"></i> Yönet
                                                </button>
                                            </div>
                                        </td>
                                        <td>
                                            <button class="button button-small" onclick="editPlatform('<?php echo esc_attr($id); ?>', <?php echo htmlspecialchars(json_encode($platform)); ?>)">Düzenle</button>
                                            <form method="post" style="display: inline;">
                                                <?php wp_nonce_field('torofilm_delete_platform', 'delete_nonce'); ?>
                                                <input type="hidden" name="platform_id" value="<?php echo esc_attr($id); ?>">
                                                <input type="submit" name="delete_platform" value="Sil" class="button button-small" onclick="return confirm('Bu platformu silmek istediğinizden emin misiniz?');">
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p>Henüz platform eklenmemiş.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Content Manager Modal -->
        <div id="contentManagerModal" class="modal-overlay" style="display: none;">
            <div class="modal-content" style="max-width: 900px; width: 95%;">
                <div class="modal-header">
                    <h2 id="contentManagerTitle">İçerik Yönetimi</h2>
                    <button class="modal-close" onclick="closeContentManager()">
                        <i class="fa fa-times"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="content-manager-tabs">
                        <button class="tab-button active" onclick="switchTab('movies')">Filmler</button>
                        <button class="tab-button" onclick="switchTab('series')">Diziler</button>
                        <button class="tab-button" onclick="switchTab('add')">İçerik Ekle</button>
                    </div>
                    
                    <div id="movies-tab" class="tab-content active">
                        <div class="content-list">
                            <h3>Bu Platformdaki Filmler</h3>
                            <div id="platform-movies-list" class="content-grid">
                                <!-- Filmler buraya yüklenecek -->
                            </div>
                        </div>
                    </div>
                    
                    <div id="series-tab" class="tab-content">
                        <div class="content-list">
                            <h3>Bu Platformdaki Diziler</h3>
                            <div id="platform-series-list" class="content-grid">
                                <!-- Diziler buraya yüklenecek -->
                            </div>
                        </div>
                    </div>
                    
                    <div id="add-tab" class="tab-content">
                        <div class="add-content-form">
                            <h3>İçerik Ekle</h3>
                            
                            <!-- Arama Bölümü -->
                            <div class="search-section">
                                <div class="search-header">
                                    <h4>Mevcut İçeriklerden Seç</h4>
                                    <p>Yayınlanmış film ve dizilerden seçim yapın</p>
                                </div>
                                
                                <div class="search-controls">
                                    <div class="form-row">
                                        <div class="form-group">
                                            <label for="searchContentType">İçerik Türü</label>
                                            <select id="searchContentType" onchange="searchExistingContent()">
                                                <option value="">Tümü</option>
                                                <option value="movies">Filmler</option>
                                                <option value="series">Diziler</option>
                                            </select>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label for="searchQuery">Arama</label>
                                            <input type="text" id="searchQuery" placeholder="Film veya dizi adı yazın..." onkeyup="searchExistingContent()">
                                        </div>
                                    </div>
                                    
                                    <div class="search-actions">
                                        <button type="button" class="button" onclick="searchExistingContent()">
                                            <i class="fa fa-search"></i> Ara
                                        </button>
                                        <button type="button" class="button" onclick="clearSearch()">
                                            <i class="fa fa-refresh"></i> Temizle
                                        </button>
                                    </div>
                                </div>
                                
                                <div id="searchResults" class="search-results">
                                    <div class="search-placeholder">
                                        <i class="fa fa-search"></i>
                                        <p>Arama yapmak için yukarıdaki alanları kullanın</p>
                                    </div>
                                </div>
                                
                                <div id="selectedItems" class="selected-items" style="display: none;">
                                    <h4>Seçili İçerikler</h4>
                                    <div id="selectedItemsList"></div>
                                    <div class="selected-actions">
                                        <button type="button" class="button button-primary" onclick="addSelectedToPlatform()">
                                            <i class="fa fa-plus"></i> Seçili İçerikleri Platforma Ekle
                                        </button>
                                        <button type="button" class="button" onclick="clearSelection()">
                                            <i class="fa fa-times"></i> Seçimi Temizle
                                        </button>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Yeni İçerik Ekleme Bölümü -->
                            <div class="new-content-section">
                                <div class="section-divider">
                                    <span>veya</span>
                                </div>
                                
                                <h4>Yeni İçerik Oluştur</h4>
                                <form id="addContentForm">
                                    <div class="form-row">
                                        <div class="form-group">
                                            <label for="contentType">İçerik Türü</label>
                                            <select id="contentType" name="content_type" required>
                                                <option value="">Seçiniz</option>
                                                <option value="movies">Film</option>
                                                <option value="series">Dizi</option>
                                            </select>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label for="contentTitle">Başlık</label>
                                            <input type="text" id="contentTitle" name="content_title" required placeholder="Film veya dizi adı">
                                        </div>
                                    </div>
                                    
                                    <div class="form-row">
                                        <div class="form-group">
                                            <label for="contentYear">Yıl</label>
                                            <input type="number" id="contentYear" name="content_year" placeholder="2024" min="1900" max="2030">
                                        </div>
                                        
                                        <div class="form-group">
                                            <label for="contentRating">Puan (0-10)</label>
                                            <input type="number" id="contentRating" name="content_rating" placeholder="8.5" min="0" max="10" step="0.1">
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <label for="contentDescription">Açıklama</label>
                                        <textarea id="contentDescription" name="content_description" rows="4" placeholder="Film veya dizi açıklaması"></textarea>
                                    </div>
                                    
                                    <div class="form-row">
                                        <div class="form-group">
                                            <label for="contentPoster">Poster URL</label>
                                            <input type="url" id="contentPoster" name="content_poster" placeholder="https://image.tmdb.org/t/p/w342/poster.jpg">
                                        </div>
                                        
                                        <div class="form-group">
                                            <label for="contentGenres">Türler (virgülle ayırın)</label>
                                            <input type="text" id="contentGenres" name="content_genres" placeholder="Aksiyon, Komedi, Dram">
                                        </div>
                                    </div>
                                    
                                    <div class="form-actions">
                                        <button type="button" class="button button-primary" onclick="addContentToPlatform()">
                                            <i class="fa fa-plus"></i> Yeni İçerik Oluştur
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <script>
        function selectPlatformLogo() {
            var frame = wp.media({
                title: 'Platform Logosu Seç',
                button: {
                    text: 'Seç'
                },
                multiple: false,
                library: {
                    type: 'image'
                }
            });
            
            frame.on('select', function() {
                var attachment = frame.state().get('selection').first().toJSON();
                document.getElementById('platform_logo').value = attachment.url;
                
                var preview = document.getElementById('platform_logo_preview');
                preview.innerHTML = '<img src="' + attachment.url + '" alt="Platform Logo" style="max-width: 100px; max-height: 60px; border-radius: 5px; border: 1px solid #ddd;">';
            });
            
            frame.open();
        }
        
        function removePlatformLogo() {
            document.getElementById('platform_logo').value = '';
            document.getElementById('platform_logo_preview').innerHTML = '';
        }
        
        function editPlatform(platformId, platformData) {
            // Form başlığını değiştir
            document.getElementById('form-title').textContent = 'Platform Düzenle';
            
            // Form alanlarını doldur
            document.getElementById('editing_platform_id').value = platformId;
            document.getElementById('platform_name').value = platformData.name || '';
            document.getElementById('platform_url').value = platformData.url || '';
            document.getElementById('platform_color').value = platformData.color || '#E50914';
            document.getElementById('platform_icon').value = platformData.icon || 'fa-play';
            document.getElementById('platform_logo').value = platformData.logo || '';
            document.getElementById('platform_description').value = platformData.description || '';
            
            // Logo önizlemesini göster
            if (platformData.logo) {
                document.getElementById('platform_logo_preview').innerHTML = '<img src="' + platformData.logo + '" alt="Platform Logo" style="max-width: 100px; max-height: 60px; border-radius: 5px; border: 1px solid #ddd;">';
            }
            
            // Form butonlarını değiştir
            document.getElementById('form-buttons').innerHTML = '<input type="submit" name="edit_platform" value="Platform Güncelle" class="button button-primary"> <button type="button" class="button" onclick="resetForm()">İptal</button>';
            
            // Formu yukarı kaydır
            document.getElementById('platform-form').scrollIntoView({ behavior: 'smooth' });
        }
        
        function resetForm() {
            // Form başlığını sıfırla
            document.getElementById('form-title').textContent = 'Yeni Platform Ekle';
            
            // Form alanlarını temizle
            document.getElementById('editing_platform_id').value = '';
            document.getElementById('platform_name').value = '';
            document.getElementById('platform_url').value = '';
            document.getElementById('platform_color').value = '#E50914';
            document.getElementById('platform_icon').value = 'fa-play';
            document.getElementById('platform_logo').value = '';
            document.getElementById('platform_description').value = '';
            document.getElementById('platform_logo_preview').innerHTML = '';
            
            // Form butonlarını sıfırla
            document.getElementById('form-buttons').innerHTML = '<input type="submit" name="add_platform" value="Platform Ekle" class="button button-primary">';
        }
        
        // Content Manager Functions
        let currentPlatformId = '';
        let currentPlatformName = '';
        let selectedContentItems = [];
        
        function openContentManager(platformId, platformName) {
            currentPlatformId = platformId;
            currentPlatformName = platformName;
            selectedContentItems = [];
            
            document.getElementById('contentManagerTitle').textContent = platformName + ' - İçerik Yönetimi';
            document.getElementById('contentManagerModal').style.display = 'block';
            document.body.style.overflow = 'hidden';
            
            // İlk tab'ı yükle
            loadPlatformContent('movies');
            
            // Arama bölümünü temizle
            clearSearch();
        }
        
        function closeContentManager() {
            document.getElementById('contentManagerModal').style.display = 'none';
            document.body.style.overflow = '';
            currentPlatformId = '';
            currentPlatformName = '';
        }
        
        function switchTab(tabName) {
            // Tüm tab butonlarını deaktif et
            document.querySelectorAll('.tab-button').forEach(btn => btn.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
            
            // Seçili tab'ı aktif et
            event.target.classList.add('active');
            document.getElementById(tabName + '-tab').classList.add('active');
            
            // İçerik yükle
            if (tabName !== 'add') {
                loadPlatformContent(tabName);
            }
        }
        
        function loadPlatformContent(contentType) {
            const container = document.getElementById('platform-' + contentType + '-list');
            container.innerHTML = '<div class="loading">Yükleniyor...</div>';
            
            // AJAX ile platform içeriklerini yükle
            fetch(ajaxurl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    action: 'get_platform_content',
                    platform_id: currentPlatformId,
                    content_type: contentType,
                    nonce: '<?php echo wp_create_nonce('get_platform_content'); ?>'
                })
            })
            .then(response => response.json())
            .then(result => {
                if (result.success) {
                    displayPlatformContent(container, result.data, contentType);
                } else {
                    container.innerHTML = '<div class="error">Hata: ' + result.data + '</div>';
                }
            })
            .catch(error => {
                console.error('Error:', error);
                container.innerHTML = '<div class="error">Bir hata oluştu!</div>';
            });
        }
        
        function displayPlatformContent(container, content, contentType) {
            if (content.length === 0) {
                container.innerHTML = '<div class="no-content">Bu platformda henüz ' + (contentType === 'movies' ? 'film' : 'dizi') + ' bulunmuyor.</div>';
                return;
            }
            
            let html = '';
            content.forEach(function(item) {
                html += '<div class="content-item">';
                html += '<div class="content-poster">';
                html += '<img src="' + item.poster + '" alt="' + item.title + '">';
                html += '</div>';
                html += '<div class="content-info">';
                html += '<h4>' + item.title + '</h4>';
                html += '<div class="content-meta">';
                html += '<span class="year">' + item.year + '</span>';
                html += '<span class="rating">' + item.rating + '</span>';
                html += '</div>';
                html += '<div class="content-actions">';
                html += '<button class="button button-small" onclick="editContent(' + item.id + ')">Düzenle</button>';
                html += '<button class="button button-small button-link-delete" onclick="removeFromPlatform(' + item.id + ', \'' + contentType + '\')">Platformdan Kaldır</button>';
                html += '</div>';
                html += '</div>';
                html += '</div>';
            });
            
            container.innerHTML = html;
        }
        
        function addContentToPlatform() {
            const form = document.getElementById('addContentForm');
            const formData = new FormData(form);
            
            const data = {
                action: 'add_content_to_platform_admin',
                platform_id: currentPlatformId,
                content_type: formData.get('content_type'),
                content_title: formData.get('content_title'),
                content_year: formData.get('content_year'),
                content_description: formData.get('content_description'),
                content_poster: formData.get('content_poster'),
                content_rating: formData.get('content_rating'),
                content_genres: formData.get('content_genres'),
                nonce: '<?php echo wp_create_nonce('add_content_admin'); ?>'
            };
            
            fetch(ajaxurl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams(data)
            })
            .then(response => response.json())
            .then(result => {
                if (result.success) {
                    alert('İçerik başarıyla eklendi!');
                    form.reset();
                    // Mevcut tab'ı yenile
                    const activeTab = document.querySelector('.tab-content.active').id.replace('-tab', '');
                    if (activeTab !== 'add') {
                        loadPlatformContent(activeTab);
                    }
                } else {
                    alert('Hata: ' + result.data);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Bir hata oluştu!');
            });
        }
        
        function removeFromPlatform(contentId, contentType) {
            if (!confirm('Bu içeriği platformdan kaldırmak istediğinizden emin misiniz?')) {
                return;
            }
            
            fetch(ajaxurl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    action: 'remove_content_from_platform',
                    content_id: contentId,
                    platform_id: currentPlatformId,
                    nonce: '<?php echo wp_create_nonce('remove_content_platform'); ?>'
                })
            })
            .then(response => response.json())
            .then(result => {
                if (result.success) {
                    alert('İçerik platformdan kaldırıldı!');
                    loadPlatformContent(contentType);
                } else {
                    alert('Hata: ' + result.data);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Bir hata oluştu!');
            });
        }
        
        // Modal overlay'e tıklayınca kapat
        document.getElementById('contentManagerModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeContentManager();
            }
        });
        
        // ESC tuşu ile kapat
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && document.getElementById('contentManagerModal').style.display === 'block') {
                closeContentManager();
            }
        });
        
        // Arama Fonksiyonları
        function searchExistingContent() {
            const contentType = document.getElementById('searchContentType').value;
            const query = document.getElementById('searchQuery').value.trim();
            
            if (!query && !contentType) {
                showSearchPlaceholder();
                return;
            }
            
            const container = document.getElementById('searchResults');
            container.innerHTML = '<div class="loading">Aranıyor...</div>';
            
            fetch(ajaxurl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    action: 'search_existing_content',
                    content_type: contentType,
                    search_query: query,
                    nonce: '<?php echo wp_create_nonce('search_existing_content'); ?>'
                })
            })
            .then(response => response.json())
            .then(result => {
                if (result.success) {
                    displaySearchResults(result.data);
                } else {
                    container.innerHTML = '<div class="error">Hata: ' + result.data + '</div>';
                }
            })
            .catch(error => {
                console.error('Error:', error);
                container.innerHTML = '<div class="error">Arama sırasında hata oluştu!</div>';
            });
        }
        
        function displaySearchResults(results) {
            const container = document.getElementById('searchResults');
            
            if (results.length === 0) {
                container.innerHTML = '<div class="no-results">Arama kriterlerinize uygun içerik bulunamadı.</div>';
                return;
            }
            
            let html = '<div class="search-results-grid">';
            results.forEach(function(item) {
                const isSelected = selectedContentItems.some(selected => selected.id === item.id);
                html += '<div class="search-result-item ' + (isSelected ? 'selected' : '') + '" data-id="' + item.id + '">';
                html += '<div class="result-poster">';
                html += '<img src="' + item.poster + '" alt="' + item.title + '">';
                html += '</div>';
                html += '<div class="result-info">';
                html += '<h5>' + item.title + '</h5>';
                html += '<div class="result-meta">';
                html += '<span class="result-type">' + (item.type === 'movies' ? 'Film' : 'Dizi') + '</span>';
                html += '<span class="result-year">' + item.year + '</span>';
                html += '<span class="result-rating">' + item.rating + '</span>';
                html += '</div>';
                html += '<div class="result-actions">';
                if (isSelected) {
                    html += '<button class="button button-small" onclick="removeFromSelection(' + item.id + ')">Kaldır</button>';
                } else {
                    html += '<button class="button button-small button-primary" onclick="addToSelection(' + item.id + ', \'' + item.title + '\', \'' + item.type + '\', \'' + item.poster + '\', \'' + item.year + '\', \'' + item.rating + '\')">Seç</button>';
                }
                html += '</div>';
                html += '</div>';
                html += '</div>';
            });
            html += '</div>';
            
            container.innerHTML = html;
        }
        
        function showSearchPlaceholder() {
            const container = document.getElementById('searchResults');
            container.innerHTML = '<div class="search-placeholder"><i class="fa fa-search"></i><p>Arama yapmak için yukarıdaki alanları kullanın</p></div>';
        }
        
        function clearSearch() {
            document.getElementById('searchContentType').value = '';
            document.getElementById('searchQuery').value = '';
            showSearchPlaceholder();
        }
        
        function addToSelection(id, title, type, poster, year, rating) {
            const item = {
                id: id,
                title: title,
                type: type,
                poster: poster,
                year: year,
                rating: rating
            };
            
            selectedContentItems.push(item);
            updateSelectedItemsDisplay();
            updateSearchResults();
        }
        
        function removeFromSelection(id) {
            selectedContentItems = selectedContentItems.filter(item => item.id !== id);
            updateSelectedItemsDisplay();
            updateSearchResults();
        }
        
        function updateSelectedItemsDisplay() {
            const container = document.getElementById('selectedItems');
            const list = document.getElementById('selectedItemsList');
            
            if (selectedContentItems.length === 0) {
                container.style.display = 'none';
                return;
            }
            
            container.style.display = 'block';
            
            let html = '<div class="selected-items-grid">';
            selectedContentItems.forEach(function(item) {
                html += '<div class="selected-item">';
                html += '<div class="selected-poster">';
                html += '<img src="' + item.poster + '" alt="' + item.title + '">';
                html += '</div>';
                html += '<div class="selected-info">';
                html += '<h6>' + item.title + '</h6>';
                html += '<span class="selected-type">' + (item.type === 'movies' ? 'Film' : 'Dizi') + '</span>';
                html += '</div>';
                html += '<button class="remove-selected" onclick="removeFromSelection(' + item.id + ')">×</button>';
                html += '</div>';
            });
            html += '</div>';
            
            list.innerHTML = html;
        }
        
        function updateSearchResults() {
            // Mevcut arama sonuçlarını güncelle
            const resultItems = document.querySelectorAll('.search-result-item');
            resultItems.forEach(function(item) {
                const id = parseInt(item.dataset.id);
                const isSelected = selectedContentItems.some(selected => selected.id === id);
                
                if (isSelected) {
                    item.classList.add('selected');
                    const button = item.querySelector('.result-actions button');
                    button.textContent = 'Kaldır';
                    button.className = 'button button-small';
                    button.onclick = function() { removeFromSelection(id); };
                } else {
                    item.classList.remove('selected');
                    const button = item.querySelector('.result-actions button');
                    button.textContent = 'Seç';
                    button.className = 'button button-small button-primary';
                    const itemData = {
                        id: id,
                        title: item.querySelector('h5').textContent,
                        type: item.querySelector('.result-type').textContent === 'Film' ? 'movies' : 'series',
                        poster: item.querySelector('img').src,
                        year: item.querySelector('.result-year').textContent,
                        rating: item.querySelector('.result-rating').textContent
                    };
                    button.onclick = function() { 
                        addToSelection(itemData.id, itemData.title, itemData.type, itemData.poster, itemData.year, itemData.rating); 
                    };
                }
            });
        }
        
        function clearSelection() {
            selectedContentItems = [];
            updateSelectedItemsDisplay();
            updateSearchResults();
        }
        
        function addSelectedToPlatform() {
            if (selectedContentItems.length === 0) {
                alert('Lütfen en az bir içerik seçin!');
                return;
            }
            
            const itemIds = selectedContentItems.map(item => item.id);
            
            fetch(ajaxurl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({
                    action: 'add_existing_content_to_platform',
                    platform_id: currentPlatformId,
                    content_ids: itemIds.join(','),
                    nonce: '<?php echo wp_create_nonce('add_existing_content'); ?>'
                })
            })
            .then(response => response.json())
            .then(result => {
                if (result.success) {
                    alert('Seçili içerikler platforma eklendi!');
                    clearSelection();
                    clearSearch();
                    // Mevcut tab'ı yenile
                    const activeTab = document.querySelector('.tab-content.active').id.replace('-tab', '');
                    if (activeTab !== 'add') {
                        loadPlatformContent(activeTab);
                    }
                } else {
                    alert('Hata: ' + result.data);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Bir hata oluştu!');
            });
        }
        </script>
        
        <style>
        /* Platform Content Management Styles */
        .platform-content-stats {
            text-align: center;
        }
        
        .content-count {
            font-size: 14px;
            margin-bottom: 5px;
        }
        
        .content-breakdown {
            font-size: 12px;
            color: #666;
            margin-bottom: 8px;
        }
        
        .content-breakdown span {
            display: block;
            margin: 2px 0;
        }
        
        .movies-count {
            color: #0073aa;
        }
        
        .series-count {
            color: #00a32a;
        }
        
        /* Modal Styles */
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.7);
            z-index: 9999;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .modal-content {
            background: #fff;
            border-radius: 8px;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        }
        
        .modal-header {
            padding: 20px;
            border-bottom: 1px solid #ddd;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .modal-header h2 {
            margin: 0;
            font-size: 18px;
        }
        
        .modal-close {
            background: none;
            border: none;
            font-size: 20px;
            cursor: pointer;
            color: #666;
            padding: 5px;
        }
        
        .modal-close:hover {
            color: #000;
        }
        
        .modal-body {
            padding: 20px;
        }
        
        /* Tab Styles */
        .content-manager-tabs {
            display: flex;
            border-bottom: 1px solid #ddd;
            margin-bottom: 20px;
        }
        
        .tab-button {
            padding: 10px 20px;
            background: #f1f1f1;
            border: none;
            border-bottom: 2px solid transparent;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s ease;
        }
        
        .tab-button:hover {
            background: #e1e1e1;
        }
        
        .tab-button.active {
            background: #fff;
            border-bottom-color: #0073aa;
            color: #0073aa;
        }
        
        .tab-content {
            display: none;
        }
        
        .tab-content.active {
            display: block;
        }
        
        /* Content Grid */
        .content-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }
        
        .content-item {
            border: 1px solid #ddd;
            border-radius: 8px;
            overflow: hidden;
            background: #fff;
            transition: box-shadow 0.3s ease;
        }
        
        .content-item:hover {
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }
        
        .content-poster {
            height: 120px;
            overflow: hidden;
        }
        
        .content-poster img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .content-info {
            padding: 10px;
        }
        
        .content-info h4 {
            margin: 0 0 8px 0;
            font-size: 14px;
            line-height: 1.3;
        }
        
        .content-meta {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            font-size: 12px;
            color: #666;
        }
        
        .content-actions {
            display: flex;
            gap: 5px;
        }
        
        .content-actions .button {
            flex: 1;
            font-size: 11px;
            padding: 5px 8px;
        }
        
        /* Form Styles */
        .add-content-form {
            max-width: 600px;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin-bottom: 15px;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
        }
        
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            border-color: #0073aa;
            outline: none;
            box-shadow: 0 0 0 1px #0073aa;
        }
        
        .form-actions {
            margin-top: 20px;
            text-align: right;
        }
        
        /* Loading and Error States */
        .loading,
        .error,
        .no-content {
            text-align: center;
            padding: 40px 20px;
            color: #666;
            font-style: italic;
        }
        
        .error {
            color: #d63638;
        }
        
        /* Search Section Styles */
        .search-section {
            margin-bottom: 30px;
            padding: 20px;
            background: #f9f9f9;
            border-radius: 8px;
        }
        
        .search-header h4 {
            margin: 0 0 5px 0;
            color: #0073aa;
        }
        
        .search-header p {
            margin: 0 0 15px 0;
            color: #666;
            font-size: 14px;
        }
        
        .search-controls {
            margin-bottom: 20px;
        }
        
        .search-actions {
            margin-top: 15px;
            display: flex;
            gap: 10px;
        }
        
        .search-results {
            min-height: 200px;
            border: 1px solid #ddd;
            border-radius: 8px;
            background: #fff;
            padding: 15px;
        }
        
        .search-placeholder {
            text-align: center;
            padding: 40px 20px;
            color: #666;
        }
        
        .search-placeholder i {
            font-size: 48px;
            margin-bottom: 15px;
            color: #ccc;
        }
        
        .search-results-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            gap: 15px;
        }
        
        .search-result-item {
            border: 1px solid #ddd;
            border-radius: 8px;
            overflow: hidden;
            background: #fff;
            transition: all 0.3s ease;
            position: relative;
        }
        
        .search-result-item:hover {
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            transform: translateY(-2px);
        }
        
        .search-result-item.selected {
            border-color: #0073aa;
            box-shadow: 0 0 0 2px rgba(0, 115, 170, 0.2);
        }
        
        .result-poster {
            height: 100px;
            overflow: hidden;
        }
        
        .result-poster img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .result-info {
            padding: 10px;
        }
        
        .result-info h5 {
            margin: 0 0 8px 0;
            font-size: 13px;
            line-height: 1.3;
            height: 34px;
            overflow: hidden;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
        }
        
        .result-meta {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            font-size: 11px;
            color: #666;
        }
        
        .result-type {
            background: #0073aa;
            color: #fff;
            padding: 2px 6px;
            border-radius: 3px;
            font-size: 10px;
        }
        
        .result-actions {
            text-align: center;
        }
        
        .result-actions .button {
            width: 100%;
            font-size: 11px;
            padding: 6px 8px;
        }
        
        /* Selected Items Styles */
        .selected-items {
            margin-top: 20px;
            padding: 15px;
            background: #e8f4fd;
            border-radius: 8px;
            border: 1px solid #0073aa;
        }
        
        .selected-items h4 {
            margin: 0 0 15px 0;
            color: #0073aa;
        }
        
        .selected-items-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
            gap: 10px;
            margin-bottom: 15px;
        }
        
        .selected-item {
            position: relative;
            border: 1px solid #0073aa;
            border-radius: 6px;
            overflow: hidden;
            background: #fff;
        }
        
        .selected-poster {
            height: 60px;
            overflow: hidden;
        }
        
        .selected-poster img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .selected-info {
            padding: 5px;
            text-align: center;
        }
        
        .selected-info h6 {
            margin: 0 0 3px 0;
            font-size: 11px;
            line-height: 1.2;
            height: 26px;
            overflow: hidden;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
        }
        
        .selected-type {
            font-size: 9px;
            color: #0073aa;
            background: #e8f4fd;
            padding: 1px 4px;
            border-radius: 2px;
        }
        
        .remove-selected {
            position: absolute;
            top: 2px;
            right: 2px;
            width: 18px;
            height: 18px;
            border: none;
            background: #d63638;
            color: #fff;
            border-radius: 50%;
            font-size: 12px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .remove-selected:hover {
            background: #b32d2e;
        }
        
        .selected-actions {
            display: flex;
            gap: 10px;
            justify-content: center;
        }
        
        /* Section Divider */
        .section-divider {
            text-align: center;
            margin: 30px 0;
            position: relative;
        }
        
        .section-divider::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 0;
            right: 0;
            height: 1px;
            background: #ddd;
        }
        
        .section-divider span {
            background: #fff;
            padding: 0 20px;
            color: #666;
            font-style: italic;
        }
        
        .new-content-section {
            padding: 20px;
            background: #f9f9f9;
            border-radius: 8px;
        }
        
        .new-content-section h4 {
            margin: 0 0 20px 0;
            color: #0073aa;
        }
        
        /* No Results */
        .no-results {
            text-align: center;
            padding: 40px 20px;
            color: #666;
            font-style: italic;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .modal-content {
                width: 95%;
                margin: 20px;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .content-grid {
                grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            }
            
            .content-actions {
                flex-direction: column;
            }
            
            .search-results-grid {
                grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            }
            
            .selected-items-grid {
                grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
            }
            
            .search-actions {
                flex-direction: column;
            }
            
            .selected-actions {
                flex-direction: column;
            }
        }
        </style>
        <?php
    }
    
    /**
     * Save platform
     */
    private function save_platform() {
        $platform_name = sanitize_text_field($_POST['platform_name']);
        $platform_url = esc_url_raw($_POST['platform_url']);
        $platform_color = sanitize_hex_color($_POST['platform_color']);
        $platform_icon = sanitize_text_field($_POST['platform_icon']);
        $platform_logo = esc_url_raw($_POST['platform_logo']);
        $platform_description = sanitize_textarea_field($_POST['platform_description']);
        
        if (empty($platform_name)) {
            echo '<div class="notice notice-error"><p>Platform adı gereklidir!</p></div>';
            return;
        }
        
        $platforms = get_option('torofilm_platforms', array());
        $platform_id = sanitize_title($platform_name);
        
        $platforms[$platform_id] = array(
            'name' => $platform_name,
            'url' => $platform_url,
            'color' => $platform_color,
            'icon' => $platform_icon,
            'logo' => $platform_logo,
            'description' => $platform_description
        );
        
        update_option('torofilm_platforms', $platforms);
        echo '<div class="notice notice-success"><p>Platform başarıyla eklendi!</p></div>';
    }
    
    /**
     * Delete platform
     */
    private function delete_platform() {
        $platform_id = sanitize_text_field($_POST['platform_id']);
        $platforms = get_option('torofilm_platforms', array());
        
        if (isset($platforms[$platform_id])) {
            unset($platforms[$platform_id]);
            update_option('torofilm_platforms', $platforms);
            echo '<div class="notice notice-success"><p>Platform başarıyla silindi!</p></div>';
        }
    }
    
    /**
     * Edit platform
     */
    private function edit_platform() {
        $editing_platform_id = sanitize_text_field($_POST['editing_platform_id']);
        $platform_name = sanitize_text_field($_POST['platform_name']);
        $platform_url = esc_url_raw($_POST['platform_url']);
        $platform_color = sanitize_hex_color($_POST['platform_color']);
        $platform_icon = sanitize_text_field($_POST['platform_icon']);
        $platform_logo = esc_url_raw($_POST['platform_logo']);
        $platform_description = sanitize_textarea_field($_POST['platform_description']);
        
        if (empty($platform_name)) {
            echo '<div class="notice notice-error"><p>Platform adı gereklidir!</p></div>';
            return;
        }
        
        if (empty($editing_platform_id)) {
            echo '<div class="notice notice-error"><p>Düzenlenecek platform bulunamadı!</p></div>';
            return;
        }
        
        $platforms = get_option('torofilm_platforms', array());
        
        if (isset($platforms[$editing_platform_id])) {
            $platforms[$editing_platform_id] = array(
                'name' => $platform_name,
                'url' => $platform_url,
                'color' => $platform_color,
                'icon' => $platform_icon,
                'logo' => $platform_logo,
                'description' => $platform_description
            );
            
            update_option('torofilm_platforms', $platforms);
            echo '<div class="notice notice-success"><p>Platform başarıyla güncellendi!</p></div>';
        } else {
            echo '<div class="notice notice-error"><p>Platform bulunamadı!</p></div>';
        }
    }
    
    /**
     * Add platform meta boxes
     */
    public function add_platform_meta_boxes() {
        add_meta_box(
            'torofilm_platforms',
            'Platform Seçimi',
            array($this, 'platform_meta_box_callback'),
            array('movies', 'series'),
            'side',
            'default'
        );
    }
    
    /**
     * Platform meta box callback
     */
    public function platform_meta_box_callback($post) {
        wp_nonce_field('torofilm_platform_nonce', 'torofilm_platform_nonce');
        
        $platforms = get_option('torofilm_platforms', array());
        $selected_platforms = get_post_meta($post->ID, '_torofilm_platforms', true);
        
        if (!is_array($selected_platforms)) {
            $selected_platforms = array();
        }
        
        echo '<p>Bu içeriğin hangi platformlarda mevcut olduğunu seçin:</p>';
        
        if (!empty($platforms)) {
            foreach ($platforms as $platform_id => $platform) {
                $checked = in_array($platform_id, $selected_platforms) ? 'checked' : '';
                echo '<label style="display: block; margin-bottom: 10px;">';
                echo '<input type="checkbox" name="torofilm_platforms[]" value="' . esc_attr($platform_id) . '" ' . $checked . '> ';
                echo '<span style="display: inline-block; width: 15px; height: 15px; background: ' . esc_attr($platform['color']) . '; border-radius: 3px; margin-right: 8px; vertical-align: middle;"></span>';
                echo esc_html($platform['name']);
                echo '</label>';
            }
        } else {
            echo '<p>Henüz platform eklenmemiş. <a href="' . admin_url('admin.php?page=torofilm-platforms') . '">Platform eklemek için tıklayın</a></p>';
        }
    }
    
    /**
     * Save platform meta box
     */
    public function save_platform_meta_box($post_id) {
        if (!isset($_POST['torofilm_platform_nonce']) || !wp_verify_nonce($_POST['torofilm_platform_nonce'], 'torofilm_platform_nonce')) {
            return;
        }
        
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        
        $platforms = isset($_POST['torofilm_platforms']) ? array_map('sanitize_text_field', $_POST['torofilm_platforms']) : array();
        update_post_meta($post_id, '_torofilm_platforms', $platforms);
    }
}
