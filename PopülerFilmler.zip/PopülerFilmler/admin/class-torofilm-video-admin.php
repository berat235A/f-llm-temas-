<?php
/**
 * Torofilm Video Admin
 * 
 * @package Torofilm
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class TOROFILM_Video_Admin {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        // Ana menü olarak ekle
        add_menu_page(
            'Video Hosting',
            'Video Hosting',
            'manage_options',
            'torofilm-video-hosting',
            array($this, 'admin_page'),
            'dashicons-video-alt3',
            30
        );
        
        // Alt menüler
        add_submenu_page(
            'torofilm-video-hosting',
            'Video Ayarları',
            'Ayarlar',
            'manage_options',
            'torofilm-video-hosting',
            array($this, 'admin_page')
        );
        
        add_submenu_page(
            'torofilm-video-hosting',
            'Desteklenen Hostlar',
            'Host Listesi',
            'manage_options',
            'torofilm-video-hosts',
            array($this, 'hosts_page')
        );
        
        add_submenu_page(
            'torofilm-video-hosting',
            'Video Test',
            'Video Test',
            'manage_options',
            'torofilm-video-test',
            array($this, 'test_page')
        );
    }
    
    /**
     * Register settings
     */
    public function register_settings() {
        register_setting('torofilm_video_settings', 'torofilm_video_options');
        
        add_settings_section(
            'torofilm_video_section',
            'Video Hosting Ayarları',
            array($this, 'settings_section_callback'),
            'torofilm-video-hosting'
        );
        
        add_settings_field(
            'auto_embed',
            'Otomatik Embed',
            array($this, 'auto_embed_callback'),
            'torofilm-video-hosting',
            'torofilm_video_section'
        );
        
        add_settings_field(
            'default_quality',
            'Varsayılan Kalite',
            array($this, 'default_quality_callback'),
            'torofilm-video-hosting',
            'torofilm_video_section'
        );
        
        add_settings_field(
            'autoplay',
            'Otomatik Oynatma',
            array($this, 'autoplay_callback'),
            'torofilm-video-hosting',
            'torofilm_video_section'
        );
    }
    
    /**
     * Settings section callback
     */
    public function settings_section_callback() {
        echo '<p>Video hosting servisleri için genel ayarlar.</p>';
    }
    
    /**
     * Auto embed callback
     */
    public function auto_embed_callback() {
        $options = get_option('torofilm_video_options');
        $auto_embed = isset($options['auto_embed']) ? $options['auto_embed'] : 0;
        
        echo '<input type="checkbox" name="torofilm_video_options[auto_embed]" value="1" ' . checked(1, $auto_embed, false) . ' />';
        echo '<label for="auto_embed">Video URL\'lerini otomatik olarak embed et</label>';
    }
    
    /**
     * Default quality callback
     */
    public function default_quality_callback() {
        $options = get_option('torofilm_video_options');
        $default_quality = isset($options['default_quality']) ? $options['default_quality'] : 'auto';
        
        echo '<select name="torofilm_video_options[default_quality]">';
        echo '<option value="auto" ' . selected('auto', $default_quality, false) . '>Otomatik</option>';
        echo '<option value="1080p" ' . selected('1080p', $default_quality, false) . '>1080p</option>';
        echo '<option value="720p" ' . selected('720p', $default_quality, false) . '>720p</option>';
        echo '<option value="480p" ' . selected('480p', $default_quality, false) . '>480p</option>';
        echo '<option value="360p" ' . selected('360p', $default_quality, false) . '>360p</option>';
        echo '</select>';
    }
    
    /**
     * Autoplay callback
     */
    public function autoplay_callback() {
        $options = get_option('torofilm_video_options');
        $autoplay = isset($options['autoplay']) ? $options['autoplay'] : 0;
        
        echo '<input type="checkbox" name="torofilm_video_options[autoplay]" value="1" ' . checked(1, $autoplay, false) . ' />';
        echo '<label for="autoplay">Videoları otomatik olarak oynat</label>';
    }
    
    /**
     * Enqueue admin scripts
     */
    public function enqueue_admin_scripts($hook) {
        if ($hook !== 'appearance_page_torofilm-video-hosting') {
            return;
        }
        
        wp_enqueue_style('torofilm-video-admin', get_template_directory_uri() . '/admin/css/video-admin.css', array(), TOROFILM_VERSION);
        wp_enqueue_script('torofilm-video-admin', get_template_directory_uri() . '/admin/js/video-admin.js', array('jquery'), TOROFILM_VERSION, true);
    }
    
    /**
     * Hosts page
     */
    public function hosts_page() {
        $video_hosting = new TOROFILM_Video_Hosting();
        $supported_hosts = $video_hosting->get_supported_hosts();
        
        ?>
        <div class="wrap">
            <h1>Desteklenen Video Hosting Servisleri</h1>
            <p class="description">Tema tarafından desteklenen tüm video hosting servisleri ve özellikleri.</p>
            
            <div class="hosts-grid">
                <?php foreach ($supported_hosts as $host_key => $host_info): ?>
                    <div class="host-card">
                        <h3><?php echo esc_html($host_info['name']); ?></h3>
                        <p><strong>Domain:</strong> <?php echo esc_html($host_info['domain']); ?></p>
                        <p><strong>Tip:</strong> 
                            <span class="host-type <?php echo esc_attr($host_info['type']); ?>">
                                <?php echo esc_html($host_info['type'] === 'iframe' ? 'Embed' : 'Direct'); ?>
                            </span>
                        </p>
                        <?php if (!empty($host_info['embed_url'])): ?>
                            <p><strong>Embed URL:</strong> <code><?php echo esc_html($host_info['embed_url']); ?></code></p>
                        <?php endif; ?>
                        <p><strong>Örnek URL:</strong></p>
                        <div class="example-url">
                            <?php if ($host_key === 'youtube'): ?>
                                <code>https://youtube.com/watch?v=xxxxxxxxx</code>
                            <?php elseif ($host_key === 'vidmoly'): ?>
                                <code>https://vidmoly.net/xxxxxxxxx</code>
                            <?php elseif ($host_key === 'filemoon'): ?>
                                <code>https://filemoon.sx/e/xxxxxxxxx</code>
                            <?php elseif ($host_key === 'streamwish'): ?>
                                <code>https://davioad.com/e/xxxxxxxxx</code>
                            <?php else: ?>
                                <code>https://<?php echo esc_html($host_info['domain']); ?>/xxxxxxxxx</code>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
    }
    
    /**
     * Test page
     */
    public function test_page() {
        ?>
        <div class="wrap">
            <h1>Video URL Test</h1>
            <p class="description">Video URL'lerini test edin ve önizleme yapın.</p>
            
            <form class="video-test-form">
                <table class="form-table">
                    <tr>
                        <th scope="row">Video URL</th>
                        <td>
                            <input type="url" name="test_url" class="regular-text" placeholder="https://vidmoly.net/xxxxxxxxx" required />
                            <p class="description">Test etmek istediğiniz video URL'sini girin.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Video Başlığı</th>
                        <td>
                            <input type="text" name="test_title" class="regular-text" placeholder="Test Video" />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Video Ayarları</th>
                        <td>
                            <label>
                                <input type="checkbox" name="autoplay" value="1" /> Otomatik oynatma
                            </label><br>
                            <label>
                                <input type="checkbox" name="controls" value="1" checked /> Kontrolleri göster
                            </label>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button type="submit" class="button button-primary">Test Et</button>
                    <button type="button" class="button" onclick="clearTest()">Temizle</button>
                </p>
            </form>
            
            <div class="test-result" style="display: none;">
                <h3>Test Sonucu</h3>
                <div class="test-output"></div>
            </div>
            
            <div class="test-examples">
                <h3>Test Örnekleri</h3>
                <div class="example-urls">
                    <button class="button example-btn" data-url="https://vidmoly.net/xxxxxxxxx">Vidmoly Test</button>
                    <button class="button example-btn" data-url="https://filemoon.sx/e/xxxxxxxxx">FileMoon Test</button>
                    <button class="button example-btn" data-url="https://davioad.com/e/xxxxxxxxx">StreamWish Test</button>
                    <button class="button example-btn" data-url="https://youtube.com/watch?v=xxxxxxxxx">YouTube Test</button>
                </div>
            </div>
        </div>
        
        <style>
        .test-examples {
            margin-top: 30px;
            padding: 20px;
            background: #f9f9f9;
            border-radius: 5px;
        }
        
        .example-urls {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-top: 10px;
        }
        
        .example-btn {
            margin: 0;
        }
        
        .host-type {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 3px;
            font-size: 11px;
            font-weight: bold;
            text-transform: uppercase;
        }
        
        .host-type.iframe {
            background: #4CAF50;
            color: white;
        }
        
        .host-type.direct {
            background: #2196F3;
            color: white;
        }
        
        .example-url {
            background: #f5f5f5;
            padding: 8px;
            border-radius: 3px;
            margin-top: 5px;
        }
        
        .example-url code {
            background: none;
            color: #333;
        }
        </style>
        
        <script>
        jQuery(document).ready(function($) {
            // Example URL buttons
            $('.example-btn').on('click', function() {
                const url = $(this).data('url');
                $('input[name="test_url"]').val(url);
            });
        });
        
        function clearTest() {
            document.querySelector('.video-test-form').reset();
            document.querySelector('.test-result').style.display = 'none';
        }
        </script>
        <?php
    }
    
    /**
     * Admin page
     */
    public function admin_page() {
        $video_hosting = new TOROFILM_Video_Hosting();
        $supported_hosts = $video_hosting->get_supported_hosts();
        
        ?>
        <div class="wrap">
            <h1>Video Hosting Ayarları</h1>
            <p class="description">Video hosting servisleri için genel ayarlar ve konfigürasyon.</p>
            
            <div class="torofilm-video-admin">
                <div class="admin-tabs">
                    <nav class="nav-tab-wrapper">
                        <a href="#settings" class="nav-tab nav-tab-active">Ayarlar</a>
                        <a href="#stats" class="nav-tab">İstatistikler</a>
                        <a href="#help" class="nav-tab">Yardım</a>
                    </nav>
                    
                    <div class="tab-content">
                        <div id="settings" class="tab-pane active">
                            <form method="post" action="options.php">
                                <?php
                                settings_fields('torofilm_video_settings');
                                do_settings_sections('torofilm-video-hosting');
                                submit_button();
                                ?>
                            </form>
                            
                            <div class="settings-info">
                                <h3>Hızlı Başlangıç</h3>
                                <div class="quick-start">
                                    <div class="quick-step">
                                        <span class="step-number">1</span>
                                        <div class="step-content">
                                            <h4>Film Ekle</h4>
                                            <p><a href="<?php echo admin_url('admin.php?page=torofilm-quick-add-movie'); ?>" class="button">Hızlı Film Ekle</a> sayfasından film ekleyin</p>
                                        </div>
                                    </div>
                                    <div class="quick-step">
                                        <span class="step-number">2</span>
                                        <div class="step-content">
                                            <h4>Video URL Ekle</h4>
                                            <p>Film ekleme formunda video URL'lerini girin (Vidmoly, FileMoon, vs.)</p>
                                        </div>
                                    </div>
                                    <div class="quick-step">
                                        <span class="step-number">3</span>
                                        <div class="step-content">
                                            <h4>Test Et</h4>
                                            <p><a href="<?php echo admin_url('admin.php?page=torofilm-video-test'); ?>" class="button">Video Test</a> sayfasından URL'leri test edin</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div id="stats" class="tab-pane">
                            <h2>Video Hosting İstatistikleri</h2>
                            
                            <div class="stats-grid">
                                <div class="stat-card">
                                    <h3><?php echo count($supported_hosts); ?></h3>
                                    <p>Desteklenen Hosting Servisi</p>
                                </div>
                                
                                <div class="stat-card">
                                    <h3><?php 
                                        $movies_with_video = get_posts(array(
                                            'post_type' => 'movies',
                                            'meta_query' => array(
                                                array(
                                                    'key' => 'movie_video_url',
                                                    'compare' => 'EXISTS'
                                                )
                                            ),
                                            'posts_per_page' => -1
                                        ));
                                        echo count($movies_with_video);
                                    ?></h3>
                                    <p>Video URL'si Olan Film</p>
                                </div>
                                
                                <div class="stat-card">
                                    <h3><?php 
                                        $total_movies = wp_count_posts('movies');
                                        echo $total_movies->publish;
                                    ?></h3>
                                    <p>Toplam Film Sayısı</p>
                                </div>
                                
                                <div class="stat-card">
                                    <h3><?php 
                                        $host_usage = array();
                                        foreach ($movies_with_video as $movie) {
                                            $video_url = get_post_meta($movie->ID, 'movie_video_url', true);
                                            if ($video_url) {
                                                $host = $video_hosting->detect_host($video_url);
                                                if ($host) {
                                                    $host_usage[$host['name']] = ($host_usage[$host['name']] ?? 0) + 1;
                                                }
                                            }
                                        }
                                        echo !empty($host_usage) ? max($host_usage) : 0;
                                    ?></h3>
                                    <p>En Çok Kullanılan Host</p>
                                </div>
                            </div>
                            
                            <div class="host-usage">
                                <h3>Hosting Servisi Kullanımı</h3>
                                <div class="usage-list">
                                    <?php 
                                    arsort($host_usage);
                                    foreach ($host_usage as $host_name => $count): 
                                    ?>
                                        <div class="usage-item">
                                            <span class="host-name"><?php echo esc_html($host_name); ?></span>
                                            <div class="usage-bar">
                                                <div class="usage-fill" style="width: <?php echo ($count / max($host_usage)) * 100; ?>%"></div>
                                            </div>
                                            <span class="usage-count"><?php echo $count; ?></span>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                        
                        <div id="help" class="tab-pane">
                            <h2>Video Hosting Yardım</h2>
                            
                            <div class="help-sections">
                                <div class="help-section">
                                    <h3>Desteklenen URL Formatları</h3>
                                    <div class="url-examples">
                                        <div class="url-example">
                                            <strong>Vidmoly:</strong>
                                            <code>https://vidmoly.net/xxxxxxxxx</code>
                                        </div>
                                        <div class="url-example">
                                            <strong>FileMoon:</strong>
                                            <code>https://filemoon.sx/e/xxxxxxxxx</code>
                                        </div>
                                        <div class="url-example">
                                            <strong>StreamWish:</strong>
                                            <code>https://davioad.com/e/xxxxxxxxx</code>
                                        </div>
                                        <div class="url-example">
                                            <strong>YouTube:</strong>
                                            <code>https://youtube.com/watch?v=xxxxxxxxx</code>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="help-section">
                                    <h3>Kullanım Adımları</h3>
                                    <ol>
                                        <li>Admin panelde <strong>Hızlı Film Ekle</strong> sayfasına gidin</li>
                                        <li>Film bilgilerini doldurun</li>
                                        <li>Video URL'lerini ilgili alanlara girin</li>
                                        <li>Film ekle butonuna tıklayın</li>
                                        <li>Film sayfasında video player otomatik görünecek</li>
                                    </ol>
                                </div>
                                
                                <div class="help-section">
                                    <h3>Sorun Giderme</h3>
                                    <div class="troubleshooting">
                                        <div class="trouble-item">
                                            <strong>Video görünmüyor:</strong>
                                            <p>URL formatını kontrol edin ve desteklenen hosting servislerinden birini kullandığınızdan emin olun.</p>
                                        </div>
                                        <div class="trouble-item">
                                            <strong>Embed hatası:</strong>
                                            <p>Video URL'sinin doğru olduğundan ve video ID'sinin çıkarılabildiğinden emin olun.</p>
                                        </div>
                                        <div class="trouble-item">
                                            <strong>Mobil uyumluluk:</strong>
                                            <p>Tüm video player'lar responsive tasarıma sahiptir ve mobil cihazlarda çalışır.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <style>
        .hosts-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        
        .host-card {
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .host-card h3 {
            margin-top: 0;
            color: #333;
        }
        
        .host-card p {
            margin: 5px 0;
            font-size: 14px;
        }
        
        .tab-content {
            margin-top: 20px;
        }
        
        .tab-pane {
            display: none;
        }
        
        .tab-pane.active {
            display: block;
        }
        
        .test-result {
            margin-top: 20px;
            padding: 20px;
            background: #f9f9f9;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        </style>
        
        <script>
        jQuery(document).ready(function($) {
            // Tab switching
            $('.nav-tab').on('click', function(e) {
                e.preventDefault();
                
                $('.nav-tab').removeClass('nav-tab-active');
                $(this).addClass('nav-tab-active');
                
                $('.tab-pane').removeClass('active');
                $($(this).attr('href')).addClass('active');
            });
            
            // Test form
            $('.video-test-form').on('submit', function(e) {
                e.preventDefault();
                
                const url = $(this).find('input[name="test_url"]').val();
                const title = $(this).find('input[name="test_title"]').val();
                
                if (!url) {
                    alert('Lütfen video URL\'si girin!');
                    return;
                }
                
                $('.test-result').show();
                $('.test-output').html('<p>Test ediliyor...</p>');
                
                // AJAX test
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'test_video_url',
                        url: url,
                        title: title,
                        nonce: '<?php echo wp_create_nonce('test_video_nonce'); ?>'
                    },
                    success: function(response) {
                        if (response.success) {
                            $('.test-output').html(response.data.html);
                        } else {
                            $('.test-output').html('<p style="color: red;">Hata: ' + response.data + '</p>');
                        }
                    },
                    error: function() {
                        $('.test-output').html('<p style="color: red;">Bir hata oluştu!</p>');
                    }
                });
            });
        });
        </script>
        <?php
    }
}

// Initialize admin class
new TOROFILM_Video_Admin();
