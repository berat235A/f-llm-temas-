<?php
/**
 * Torofilm Statistics Admin
 * 
 * @package Torofilm
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class TOROFILM_Stats_Admin {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_action('wp_ajax_get_stats_data', array($this, 'ajax_get_stats_data'));
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_menu_page(
            'Torofilm Yönetim',
            'Torofilm',
            'manage_options',
            'torofilm-stats',
            array($this, 'admin_page'),
            'dashicons-chart-bar',
            30
        );
        
        // İstatistikler alt menüsü
        add_submenu_page(
            'torofilm-stats',
            'İstatistikler',
            'İstatistikler',
            'manage_options',
            'torofilm-stats',
            array($this, 'admin_page')
        );
        
        // Toplu Yönetim alt menüsü
        add_submenu_page(
            'torofilm-stats',
            'Toplu İçerik Yönetimi',
            'Toplu Yönetim',
            'manage_options',
            'torofilm-bulk',
            array($this, 'bulk_admin_page')
        );
        
        // Sistem Araçları alt menüsü
        add_submenu_page(
            'torofilm-stats',
            'Sistem Araçları',
            'Sistem Araçları',
            'manage_options',
            'torofilm-system',
            array($this, 'system_admin_page')
        );
    }
    
    /**
     * Enqueue admin scripts
     */
    public function enqueue_admin_scripts($hook) {
        // Tüm Torofilm admin sayfalarında script'leri yükle
        if (strpos($hook, 'torofilm') === false) {
            return;
        }
        
        // İstatistikler sayfası
        if ($hook === 'toplevel_page_torofilm-stats') {
            wp_enqueue_style('torofilm-stats-admin', get_template_directory_uri() . '/admin/css/stats-admin.css', array(), TOROFILM_VERSION);
            wp_enqueue_script('torofilm-stats-admin', get_template_directory_uri() . '/admin/js/stats-admin.js', array('jquery'), TOROFILM_VERSION, true);
            
            wp_localize_script('torofilm-stats-admin', 'torofilm_stats', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('torofilm_stats_nonce')
            ));
        }
        
        // Toplu Yönetim sayfası
        if ($hook === 'statistics_page_torofilm-bulk') {
            wp_enqueue_style('torofilm-bulk-admin', get_template_directory_uri() . '/admin/css/bulk-admin.css', array(), TOROFILM_VERSION);
            wp_enqueue_script('torofilm-bulk-admin', get_template_directory_uri() . '/admin/js/bulk-admin.js', array('jquery'), TOROFILM_VERSION, true);
            
            wp_localize_script('torofilm-bulk-admin', 'torofilm_bulk', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('torofilm_bulk_nonce')
            ));
        }
        
        // Sistem Araçları sayfası
        if ($hook === 'statistics_page_torofilm-system') {
            wp_enqueue_style('torofilm-system-admin', get_template_directory_uri() . '/admin/css/system-admin.css', array(), TOROFILM_VERSION);
            wp_enqueue_script('torofilm-system-admin', get_template_directory_uri() . '/admin/js/system-admin.js', array('jquery'), TOROFILM_VERSION, true);
            
            wp_localize_script('torofilm-system-admin', 'torofilm_system', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('torofilm_system_nonce')
            ));
        }
    }
    
    /**
     * Admin page
     */
    public function admin_page() {
        ?>
        <div class="wrap">
            <h1>Torofilm İstatistikler</h1>
            <p class="description">Sitenizin genel istatistiklerini görüntüleyin.</p>
            
            <div class="stats-container">
                <!-- Genel İstatistikler -->
                <div class="stats-section">
                    <h2>Genel İstatistikler</h2>
                    <div class="stats-grid">
                        <div class="stat-card">
                            <div class="stat-icon">🎬</div>
                            <div class="stat-content">
                                <h3>Toplam Filmler</h3>
                                <div class="stat-number" id="total-movies">-</div>
                                <div class="stat-change" id="movies-change">-</div>
                            </div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-icon">📺</div>
                            <div class="stat-content">
                                <h3>Toplam Diziler</h3>
                                <div class="stat-number" id="total-series">-</div>
                                <div class="stat-change" id="series-change">-</div>
                            </div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-icon">👥</div>
                            <div class="stat-content">
                                <h3>Toplam Kullanıcılar</h3>
                                <div class="stat-number" id="total-users">-</div>
                                <div class="stat-change" id="users-change">-</div>
                            </div>
                        </div>
                        
                        <div class="stat-card">
                            <div class="stat-icon">📊</div>
                            <div class="stat-content">
                                <h3>Toplam Görüntülenme</h3>
                                <div class="stat-number" id="total-views">-</div>
                                <div class="stat-change" id="views-change">-</div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Son Eklenen İçerikler -->
                <div class="stats-section">
                    <h2>Son Eklenen İçerikler</h2>
                    <div class="recent-content">
                        <div class="content-tabs">
                            <button class="tab-btn active" data-tab="recent-movies">Son Filmler</button>
                            <button class="tab-btn" data-tab="recent-series">Son Diziler</button>
                        </div>
                        
                        <div class="tab-content active" id="recent-movies">
                            <div class="content-list" id="recent-movies-list">
                                <div class="loading">Yükleniyor...</div>
                            </div>
                        </div>
                        
                        <div class="tab-content" id="recent-series">
                            <div class="content-list" id="recent-series-list">
                                <div class="loading">Yükleniyor...</div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- En Popüler İçerikler -->
                <div class="stats-section">
                    <h2>En Popüler İçerikler</h2>
                    <div class="popular-content">
                        <div class="content-tabs">
                            <button class="tab-btn active" data-tab="popular-movies">Popüler Filmler</button>
                            <button class="tab-btn" data-tab="popular-series">Popüler Diziler</button>
                        </div>
                        
                        <div class="tab-content active" id="popular-movies">
                            <div class="content-list" id="popular-movies-list">
                                <div class="loading">Yükleniyor...</div>
                            </div>
                        </div>
                        
                        <div class="tab-content" id="popular-series">
                            <div class="content-list" id="popular-series-list">
                                <div class="loading">Yükleniyor...</div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Kategori Dağılımı -->
                <div class="stats-section">
                    <h2>Kategori Dağılımı</h2>
                    <div class="category-stats">
                        <div class="category-chart" id="category-chart">
                            <div class="loading">Yükleniyor...</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Bulk admin page
     */
    public function bulk_admin_page() {
        // Bulk admin sınıfını dahil et
        if (class_exists('TOROFILM_Bulk_Admin')) {
            $bulk_admin = new TOROFILM_Bulk_Admin();
            $bulk_admin->admin_page();
        }
    }
    
    /**
     * System admin page
     */
    public function system_admin_page() {
        // System admin sınıfını dahil et
        if (class_exists('TOROFILM_System_Admin')) {
            $system_admin = new TOROFILM_System_Admin();
            $system_admin->admin_page();
        }
    }
    
    /**
     * AJAX get stats data
     */
    public function ajax_get_stats_data() {
        check_ajax_referer('torofilm_stats_nonce', 'nonce');
        
        $type = sanitize_text_field($_POST['type']);
        
        switch ($type) {
            case 'general':
                $data = $this->get_general_stats();
                break;
            case 'recent_movies':
                $data = $this->get_recent_movies();
                break;
            case 'recent_series':
                $data = $this->get_recent_series();
                break;
            case 'popular_movies':
                $data = $this->get_popular_movies();
                break;
            case 'popular_series':
                $data = $this->get_popular_series();
                break;
            case 'categories':
                $data = $this->get_category_stats();
                break;
            default:
                $data = array();
        }
        
        wp_send_json_success($data);
    }
    
    /**
     * Get general statistics
     */
    private function get_general_stats() {
        global $wpdb;
        
        // Toplam filmler
        $total_movies = wp_count_posts('movies')->publish;
        
        // Toplam diziler
        $total_series = wp_count_posts('series')->publish;
        
        // Toplam kullanıcılar
        $total_users = count_users()['total_users'];
        
        // Toplam görüntülenme (meta'dan)
        $total_views = $wpdb->get_var("
            SELECT SUM(CAST(meta_value AS UNSIGNED)) 
            FROM {$wpdb->postmeta} 
            WHERE meta_key = 'post_views_count'
        ");
        
        // Son 30 gün değişim
        $movies_change = $this->get_change_percentage('movies', 30);
        $series_change = $this->get_change_percentage('series', 30);
        $users_change = $this->get_user_change_percentage(30);
        $views_change = $this->get_views_change_percentage(30);
        
        return array(
            'total_movies' => $total_movies,
            'total_series' => $total_series,
            'total_users' => $total_users,
            'total_views' => $total_views ?: 0,
            'movies_change' => $movies_change,
            'series_change' => $series_change,
            'users_change' => $users_change,
            'views_change' => $views_change
        );
    }
    
    /**
     * Get recent movies
     */
    private function get_recent_movies() {
        $movies = get_posts(array(
            'post_type' => 'movies',
            'posts_per_page' => 10,
            'post_status' => 'publish',
            'orderby' => 'date',
            'order' => 'DESC'
        ));
        
        $data = array();
        foreach ($movies as $movie) {
            $data[] = array(
                'id' => $movie->ID,
                'title' => $movie->post_title,
                'date' => $movie->post_date,
                'views' => get_post_meta($movie->ID, 'post_views_count', true) ?: 0,
                'rating' => get_post_meta($movie->ID, 'movie_rating', true) ?: 'N/A',
                'thumbnail' => get_the_post_thumbnail_url($movie->ID, 'thumbnail')
            );
        }
        
        return $data;
    }
    
    /**
     * Get recent series
     */
    private function get_recent_series() {
        $series = get_posts(array(
            'post_type' => 'series',
            'posts_per_page' => 10,
            'post_status' => 'publish',
            'orderby' => 'date',
            'order' => 'DESC'
        ));
        
        $data = array();
        foreach ($series as $serie) {
            $data[] = array(
                'id' => $serie->ID,
                'title' => $serie->post_title,
                'date' => $serie->post_date,
                'views' => get_post_meta($serie->ID, 'post_views_count', true) ?: 0,
                'rating' => get_post_meta($serie->ID, 'series_rating', true) ?: 'N/A',
                'thumbnail' => get_the_post_thumbnail_url($serie->ID, 'thumbnail')
            );
        }
        
        return $data;
    }
    
    /**
     * Get popular movies
     */
    private function get_popular_movies() {
        $movies = get_posts(array(
            'post_type' => 'movies',
            'posts_per_page' => 10,
            'post_status' => 'publish',
            'meta_key' => 'post_views_count',
            'orderby' => 'meta_value_num',
            'order' => 'DESC'
        ));
        
        $data = array();
        foreach ($movies as $movie) {
            $data[] = array(
                'id' => $movie->ID,
                'title' => $movie->post_title,
                'views' => get_post_meta($movie->ID, 'post_views_count', true) ?: 0,
                'rating' => get_post_meta($movie->ID, 'movie_rating', true) ?: 'N/A',
                'thumbnail' => get_the_post_thumbnail_url($movie->ID, 'thumbnail')
            );
        }
        
        return $data;
    }
    
    /**
     * Get popular series
     */
    private function get_popular_series() {
        $series = get_posts(array(
            'post_type' => 'series',
            'posts_per_page' => 10,
            'post_status' => 'publish',
            'meta_key' => 'post_views_count',
            'orderby' => 'meta_value_num',
            'order' => 'DESC'
        ));
        
        $data = array();
        foreach ($series as $serie) {
            $data[] = array(
                'id' => $serie->ID,
                'title' => $serie->post_title,
                'views' => get_post_meta($serie->ID, 'post_views_count', true) ?: 0,
                'rating' => get_post_meta($serie->ID, 'series_rating', true) ?: 'N/A',
                'thumbnail' => get_the_post_thumbnail_url($serie->ID, 'thumbnail')
            );
        }
        
        return $data;
    }
    
    /**
     * Get category statistics
     */
    private function get_category_stats() {
        $categories = get_terms(array(
            'taxonomy' => 'movie_category',
            'hide_empty' => true
        ));
        
        $data = array();
        foreach ($categories as $category) {
            $data[] = array(
                'name' => $category->name,
                'count' => $category->count,
                'slug' => $category->slug
            );
        }
        
        return $data;
    }
    
    /**
     * Get change percentage for posts
     */
    private function get_change_percentage($post_type, $days = 30) {
        $current_count = wp_count_posts($post_type)->publish;
        
        $date = date('Y-m-d', strtotime("-{$days} days"));
        $old_count = $wpdb->get_var($wpdb->prepare("
            SELECT COUNT(*) 
            FROM {$wpdb->posts} 
            WHERE post_type = %s 
            AND post_status = 'publish' 
            AND post_date <= %s
        ", $post_type, $date));
        
        if ($old_count == 0) {
            return $current_count > 0 ? 100 : 0;
        }
        
        return round((($current_count - $old_count) / $old_count) * 100, 1);
    }
    
    /**
     * Get user change percentage
     */
    private function get_user_change_percentage($days = 30) {
        $current_count = count_users()['total_users'];
        
        $date = date('Y-m-d', strtotime("-{$days} days"));
        $old_count = $wpdb->get_var($wpdb->prepare("
            SELECT COUNT(*) 
            FROM {$wpdb->users} 
            WHERE user_registered <= %s
        ", $date));
        
        if ($old_count == 0) {
            return $current_count > 0 ? 100 : 0;
        }
        
        return round((($current_count - $old_count) / $old_count) * 100, 1);
    }
    
    /**
     * Get views change percentage
     */
    private function get_views_change_percentage($days = 30) {
        global $wpdb;
        
        $current_views = $wpdb->get_var("
            SELECT SUM(CAST(meta_value AS UNSIGNED)) 
            FROM {$wpdb->postmeta} 
            WHERE meta_key = 'post_views_count'
        ");
        
        $date = date('Y-m-d', strtotime("-{$days} days"));
        $old_views = $wpdb->get_var($wpdb->prepare("
            SELECT SUM(CAST(meta_value AS UNSIGNED)) 
            FROM {$wpdb->postmeta} pm
            INNER JOIN {$wpdb->posts} p ON pm.post_id = p.ID
            WHERE pm.meta_key = 'post_views_count'
            AND p.post_date <= %s
        ", $date));
        
        if ($old_views == 0) {
            return $current_views > 0 ? 100 : 0;
        }
        
        return round((($current_views - $old_views) / $old_views) * 100, 1);
    }
}

// Initialize
new TOROFILM_Stats_Admin();