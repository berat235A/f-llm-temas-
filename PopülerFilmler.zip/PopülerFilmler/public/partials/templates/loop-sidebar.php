<li>
	<article class="post dfx alg-cr top">
		<header class="entry-header fg1">
			<h2 class="entry-title"><?php the_title(); ?></h2>
			
		</header>
		<div class="post-thumbnail or-1">
			<figure><?php the_post_thumbnail('thumbnail'); ?></figure>
		</div>
		<a href="<?php the_permalink(); ?>" class="lnk-blk"></a>	
	</article>
</li>