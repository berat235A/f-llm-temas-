<?php 
/**
 * Son Bölümler Template
 * Bu template Son Bölümler bölümü için kullanılır
 */

// Global değişkenlerden verileri al
global $episode_data;

if (!isset($episode_data)) {
    return; // Veri yoksa çık
}

$episode = $episode_data['episode'];
$air_date = $episode_data['air_date'];
$series_id = $episode_data['series_id'];
$season_number = $episode_data['season_number'];
$episode_number = $episode_data['episode_number'];

// Tarih işleme
$dat = strtotime($air_date);
$series_post = get_post($series_id);

// Poster URL'sini al
$poster_hotlink = '';
$poster_field = '';
$poster_url = '';

if ($series_post) {
    $poster_hotlink = get_post_meta($series_post->ID, 'poster_hotlink', true);
    $poster_field = get_post_meta($series_post->ID, 'field_poster', true);
    
    if ($poster_field) {
        $poster_url = wp_get_attachment_image_src($poster_field, 'medium')[0];
    } elseif ($poster_hotlink) {
        if (filter_var($poster_hotlink, FILTER_VALIDATE_URL) === FALSE) {
            $poster_url = '//image.tmdb.org/t/p/w342' . $poster_hotlink;
        } else {
            $poster_url = $poster_hotlink;
        }
    }
}

// Tarih formatını hazırla
$time_ago = '';
if ($dat) {
    $time_ago = human_time_diff($dat, current_time('timestamp')) . ' önce';
}
?>

<div class="episode-item">
    <article class="post dfx fcl episodes">
        <div class="post-thumbnail">
            <?php if ($poster_url): ?>
                <img src="<?php echo esc_url($poster_url); ?>" 
                     alt="<?php echo esc_attr($episode->name); ?>" 
                     loading="lazy"
                     class="episode-poster-img">
            <?php elseif ($series_post): ?>
                <?php echo tr_theme_img($series_post->ID, 'medium', $series_post->post_title); ?>
            <?php else: ?>
                <!-- Varsayılan poster -->
                <div class="default-poster">
                    <i class="fa fa-play-circle"></i>
                </div>
            <?php endif; ?>
            
            <!-- Bölüm Numarası -->
            <span class="episode-number">
                <?php echo $season_number; ?>x<?php echo $episode_number; ?>
            </span>
            
            <!-- Play Button -->
            <div class="play-btn">
                <i class="fa fa-play"></i>
            </div>
        </div>
        
        <header class="entry-header">
            <h3 class="entry-title"><?php echo $episode->name; ?></h3>
            
            <?php if ($series_post): ?>
                <p class="series-name"><?php echo $series_post->post_title; ?></p>
            <?php endif; ?>
            
            <div class="entry-meta">
                <?php if ($time_ago): ?>
                    <span class="time"><?php echo $time_ago; ?></span>
                <?php endif; ?>
                
                <!-- Ek bilgiler -->
                <div class="episode-info">
                    <?php if ($season_number && $episode_number): ?>
                        <span class="episode-details">
                            <i class="fa fa-tv"></i>
                            Sezon <?php echo $season_number; ?> • Bölüm <?php echo $episode_number; ?>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
        </header>
        
        <a href="<?php echo get_term_link($episode); ?>" class="lnk-blk" data-swiper-ignore></a>
    </article>
</div>
