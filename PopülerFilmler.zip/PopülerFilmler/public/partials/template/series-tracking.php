<?php
// Dizi Takip Sistemi
$series_id = get_the_ID();
$user_id = get_current_user_id();

// Kullanıcının takip ettiği diziler
$tracked_series = get_user_meta($user_id, 'tracked_series', true);
if (!is_array($tracked_series)) {
    $tracked_series = array();
}

// Bu diziyi takip ediyor mu?
$is_tracked = in_array($series_id, $tracked_series);

// Kullanıcının bu dizi için izlediği sezon/bölüm
$watched_season = get_user_meta($user_id, 'watched_season_' . $series_id, true);
$watched_episode = get_user_meta($user_id, 'watched_episode_' . $series_id, true);

// Toplam sezon ve bölüm sayısı
$total_seasons = get_post_meta($series_id, 'total_seasons', true);
$total_episodes = get_post_meta($series_id, 'total_episodes', true);

if (!$watched_season) $watched_season = 0;
if (!$watched_episode) $watched_episode = 0;
if (!$total_seasons) $total_seasons = 1;
if (!$total_episodes) $total_episodes = 1;
?>

<div class="series-tracking-widget">
    <div class="tracking-header">
        <h3>Dizi Takip</h3>
        <button class="track-toggle-btn <?php echo $is_tracked ? 'tracked' : ''; ?>" 
                data-series-id="<?php echo $series_id; ?>">
            <i class="fa fa-<?php echo $is_tracked ? 'check' : 'plus'; ?>"></i>
            <?php echo $is_tracked ? 'Takip Ediliyor' : 'Takip Et'; ?>
        </button>
    </div>
    
    <?php if ($is_tracked): ?>
    <div class="tracking-progress">
        <div class="progress-info">
            <span class="current-progress">
                Sezon <?php echo $watched_season; ?>, Bölüm <?php echo $watched_episode; ?>
            </span>
            <span class="total-progress">
                / Sezon <?php echo $total_seasons; ?>, Bölüm <?php echo $total_episodes; ?>
            </span>
        </div>
        
        <div class="progress-bar">
            <div class="progress-fill" 
                 style="width: <?php echo $total_seasons > 0 ? ($watched_season / $total_seasons) * 100 : 0; ?>%"></div>
        </div>
        
        <div class="tracking-controls">
            <div class="season-control">
                <label>Sezon:</label>
                <select class="season-select" data-series-id="<?php echo $series_id; ?>">
                    <?php for ($i = 0; $i <= $total_seasons; $i++): ?>
                        <option value="<?php echo $i; ?>" <?php selected($watched_season, $i); ?>>
                            <?php echo $i == 0 ? 'Başlamadı' : 'Sezon ' . $i; ?>
                        </option>
                    <?php endfor; ?>
                </select>
            </div>
            
            <div class="episode-control">
                <label>Bölüm:</label>
                <select class="episode-select" data-series-id="<?php echo $series_id; ?>">
                    <?php for ($i = 0; $i <= $total_episodes; $i++): ?>
                        <option value="<?php echo $i; ?>" <?php selected($watched_episode, $i); ?>>
                            <?php echo $i == 0 ? 'Başlamadı' : 'Bölüm ' . $i; ?>
                        </option>
                    <?php endfor; ?>
                </select>
            </div>
        </div>
        
        <div class="tracking-actions">
            <button class="mark-watched-btn" data-series-id="<?php echo $series_id; ?>">
                <i class="fa fa-check"></i>
                İzledim Olarak İşaretle
            </button>
            <button class="reset-progress-btn" data-series-id="<?php echo $series_id; ?>">
                <i class="fa fa-refresh"></i>
                Sıfırla
            </button>
        </div>
    </div>
    <?php endif; ?>
</div>

<style>
.series-tracking-widget {
    background: var(--gray);
    border-radius: 15px;
    padding: 20px;
    margin: 20px 0;
    border: 1px solid var(--gray-light);
}

.tracking-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.tracking-header h3 {
    margin: 0;
    color: var(--text);
    font-size: 1.2rem;
}

.track-toggle-btn {
    background: var(--primary);
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 25px;
    cursor: pointer;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 0.9rem;
}

.track-toggle-btn:hover {
    background: var(--secondary);
    transform: translateY(-2px);
}

.track-toggle-btn.tracked {
    background: var(--success);
}

.tracking-progress {
    animation: slideDown 0.3s ease;
}

@keyframes slideDown {
    from { opacity: 0; transform: translateY(-10px); }
    to { opacity: 1; transform: translateY(0); }
}

.progress-info {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;
    font-size: 0.9rem;
}

.current-progress {
    color: var(--primary);
    font-weight: 600;
}

.total-progress {
    color: var(--light-7);
}

.progress-bar {
    width: 100%;
    height: 8px;
    background: var(--gray-light);
    border-radius: 4px;
    overflow: hidden;
    margin-bottom: 20px;
}

.progress-fill {
    height: 100%;
    background: linear-gradient(90deg, var(--primary), var(--secondary));
    transition: width 0.3s ease;
}

.tracking-controls {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 15px;
    margin-bottom: 20px;
}

.season-control, .episode-control {
    display: flex;
    flex-direction: column;
    gap: 5px;
}

.season-control label, .episode-control label {
    font-size: 0.8rem;
    color: var(--light-7);
    font-weight: 500;
}

.season-select, .episode-select {
    background: var(--gray-light);
    color: var(--text);
    border: 1px solid var(--gray-light);
    padding: 8px 12px;
    border-radius: 8px;
    font-size: 0.9rem;
}

.tracking-actions {
    display: flex;
    gap: 10px;
}

.mark-watched-btn, .reset-progress-btn {
    flex: 1;
    background: var(--gray-light);
    color: var(--text);
    border: 1px solid var(--gray-light);
    padding: 10px 15px;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    font-size: 0.8rem;
}

.mark-watched-btn:hover {
    background: var(--success);
    color: white;
    border-color: var(--success);
}

.reset-progress-btn:hover {
    background: var(--danger);
    color: white;
    border-color: var(--danger);
}

@media (max-width: 768px) {
    .tracking-controls {
        grid-template-columns: 1fr;
    }
    
    .tracking-actions {
        flex-direction: column;
    }
}
</style>
