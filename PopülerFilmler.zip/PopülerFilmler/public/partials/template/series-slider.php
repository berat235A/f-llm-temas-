<?php 
$loop = new TOROFLIX_Movies();
$fecha = get_post_meta(get_the_ID(), 'field_release_year', true);
$fechas = explode('-', $fecha);
$tmdb = get_post_meta(get_the_ID(), 'rating', true);
$year = $loop->year();
$quality = $loop->get_quality();
$lang = $loop->get_lang();
$option = get_option('poster_option_views', array());

if (!$tmdb) {
    $tmdb = 0;
} 
?>
<div class="slider-item series-item">
    <article class="post dfx fcl series">
        <div class="post-thumbnail">
            <figure>
                <?php echo tr_theme_img(get_the_ID(), 'medium', get_the_title()); ?>    
            </figure> 
            <div class="post-overlay">
                <span class="post-ql"> 
                    <?php if (in_array('qual', $option)) { 
                        if ( 'series' == get_post_type(get_the_ID()) && $quality) { echo $quality;} 
                    } ?> 
                    <?php if (in_array('lang', $option)) {   
                        if ( 'series' == get_post_type(get_the_ID()) && $lang) {  ?>
                        <span class="lang"><?php echo $lang; ?></span>
                    <?php } } ?>
                </span> 
                <?php if (in_array('year', $option)) { if ($year) {  ?> 
                    <span class="year"><?php echo $year; ?></span>
                <?php } } ?> 
                <span class="play-btn">
                    <i class="fa fa-play"></i>
                </span>
                <div class="series-info">
                    <h3 class="series-title"><?php the_title(); ?></h3>
                    <div class="series-meta">
                        <span class="vote">
                            <i class="fa fa-star"></i>
                            <span>TMDB <?php echo $tmdb; ?></span>
                        </span>
                        <?php if ($year) { ?>
                            <span class="year"><?php echo $year; ?></span>
                        <?php } ?>
                        <?php 
                        // Bölüm sayısını al
                        $episodes_count = wp_count_posts('episodes');
                        if ($episodes_count) {
                            $total_episodes = $episodes_count->publish;
                            if ($total_episodes > 0) {
                                echo '<span class="episodes-count">' . $total_episodes . ' Bölüm</span>';
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
        <a href="<?php the_permalink(); ?>" class="lnk-blk" data-swiper-ignore></a>
    </article>
</div>
