<?php 
$loop = new TOROFLIX_Movies();
$fecha = get_post_meta(get_the_ID(), 'field_release_year', true);
$fechas = explode('-', $fecha);
$tmdb = get_post_meta(get_the_ID(), 'rating', true);
$year = $loop->year();
$quality = $loop->get_quality();
$lang = $loop->get_lang();
$option = get_option('poster_option_views', array());
$views = get_post_meta(get_the_ID(), 'views', true);

if (!$tmdb) {
    $tmdb = 0;
} 

// Poster URL'sini al
$poster_hotlink = get_post_meta(get_the_ID(), 'poster_hotlink', true);
$poster_field = get_post_meta(get_the_ID(), 'field_poster', true);
$poster_url = '';

if ($poster_field) {
    $poster_url = wp_get_attachment_image_src($poster_field, 'medium')[0];
} elseif ($poster_hotlink) {
    if (filter_var($poster_hotlink, FILTER_VALIDATE_URL) === FALSE) {
        $poster_url = '//image.tmdb.org/t/p/w342' . $poster_hotlink;
    } else {
        $poster_url = $poster_hotlink;
    }
}
?>
<div class="slider-item movie-item">
    <article class="post dfx fcl movies">
        <div class="post-thumbnail">
            <figure>
                <?php if ($poster_url): ?>
                    <img src="<?php echo esc_url($poster_url); ?>" 
                         alt="<?php echo esc_attr(get_the_title()); ?>" 
                         loading="lazy"
                         class="movie-poster-img">
                <?php else: ?>
                    <?php echo tr_theme_img(get_the_ID(), 'medium', get_the_title()); ?>
                <?php endif; ?>    
            </figure> 
            <div class="post-overlay">
                <span class="post-ql"> 
                    <?php if (in_array('qual', $option)) { 
                        if ( 'movies' == get_post_type(get_the_ID()) && $quality) { echo $quality;} 
                    } ?> 
                    <?php if (in_array('lang', $option)) {   
                        if ( 'movies' == get_post_type(get_the_ID()) && $lang) {  ?>
                        <span class="lang"><?php echo $lang; ?></span>
                    <?php } } ?>
                </span> 
                <?php if (in_array('year', $option)) { if ($year) {  ?> 
                    <span class="year"><?php echo $year; ?></span>
                <?php } } ?> 
                <span class="play-btn">
                    <i class="fa fa-play"></i>
                </span>
                <div class="movie-info">
                    <h3 class="movie-title"><?php the_title(); ?></h3>
                    <div class="movie-meta">
                        <span class="vote">
                            <i class="fa fa-star"></i>
                            <span>TMDB <?php echo $tmdb; ?></span>
                        </span>
                        <?php if ($year) { ?>
                            <span class="year"><?php echo $year; ?></span>
                        <?php } ?>
                        <?php if ($views && $views > 0) { ?>
                            <span class="views">
                                <i class="fa fa-eye"></i>
                                <span><?php echo number_format($views); ?></span>
                            </span>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
        <a href="<?php the_permalink(); ?>" class="lnk-blk" data-swiper-ignore></a>
    </article>
</div>
