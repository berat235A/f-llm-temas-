<?php
/**
 * Movie Video Player Template
 * 
 * @package Torofilm
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

global $post;

// Video URL'lerini al
$main_video_url = get_post_meta($post->ID, 'movie_video_url', true);
$alt_video_url = get_post_meta($post->ID, 'movie_video_url_alt', true);
$trailer_url = get_post_meta($post->ID, 'movie_trailer_url', true);

// Video hosting sınıfını başlat
$video_hosting = new TOROFILM_Video_Hosting();

// En az bir video URL'si var mı kontrol et
if (empty($main_video_url) && empty($alt_video_url) && empty($trailer_url)) {
    return;
}
?>

<div class="movie-video-section">
    <div class="video-tabs">
        <nav class="video-tab-nav">
            <?php if (!empty($main_video_url)): ?>
                <button class="video-tab-btn active" data-tab="main-video">
                    <i class="fa fa-play"></i> Ana Video
                </button>
            <?php endif; ?>
            
            <?php if (!empty($alt_video_url)): ?>
                <button class="video-tab-btn" data-tab="alt-video">
                    <i class="fa fa-play"></i> Alternatif
                </button>
            <?php endif; ?>
            
            <?php if (!empty($trailer_url)): ?>
                <button class="video-tab-btn" data-tab="trailer">
                    <i class="fa fa-youtube-play"></i> Trailer
                </button>
            <?php endif; ?>
        </nav>
        
        <div class="video-tab-content">
            <?php if (!empty($main_video_url)): ?>
                <div class="video-tab-pane active" id="main-video">
                    <div class="video-player-container">
                        <?php echo $video_hosting->generate_video_player($main_video_url, array(
                            'title' => get_the_title(),
                            'autoplay' => 'false'
                        )); ?>
                    </div>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($alt_video_url)): ?>
                <div class="video-tab-pane" id="alt-video">
                    <div class="video-player-container">
                        <?php echo $video_hosting->generate_video_player($alt_video_url, array(
                            'title' => get_the_title() . ' - Alternatif',
                            'autoplay' => 'false'
                        )); ?>
                    </div>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($trailer_url)): ?>
                <div class="video-tab-pane" id="trailer">
                    <div class="video-player-container">
                        <?php echo $video_hosting->generate_video_player($trailer_url, array(
                            'title' => get_the_title() . ' - Trailer',
                            'autoplay' => 'false'
                        )); ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Video Bilgileri -->
    <div class="video-info">
        <div class="video-quality-info">
            <span class="quality-badge">HD</span>
            <span class="quality-badge">1080p</span>
        </div>
        
        <div class="video-actions">
            <button class="video-action-btn" onclick="shareVideo()">
                <i class="fa fa-share"></i> Paylaş
            </button>
            <button class="video-action-btn" onclick="downloadVideo()">
                <i class="fa fa-download"></i> İndir
            </button>
            <button class="video-action-btn" onclick="reportVideo()">
                <i class="fa fa-flag"></i> Bildir
            </button>
        </div>
    </div>
</div>

<style>
.movie-video-section {
    background: #1a1a1a;
    border-radius: 10px;
    overflow: hidden;
    margin: 20px 0;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
}

.video-tabs {
    position: relative;
}

.video-tab-nav {
    display: flex;
    background: #2a2a2a;
    border-bottom: 1px solid #333;
    padding: 0;
    margin: 0;
}

.video-tab-btn {
    background: transparent;
    border: none;
    color: #ccc;
    padding: 15px 20px;
    cursor: pointer;
    transition: all 0.3s ease;
    border-bottom: 3px solid transparent;
    font-size: 14px;
    font-weight: 500;
}

.video-tab-btn:hover {
    background: #333;
    color: #fff;
}

.video-tab-btn.active {
    color: #ff6b35;
    border-bottom-color: #ff6b35;
    background: #333;
}

.video-tab-btn i {
    margin-right: 8px;
}

.video-tab-content {
    position: relative;
}

.video-tab-pane {
    display: none;
    padding: 0;
}

.video-tab-pane.active {
    display: block;
}

.video-player-container {
    position: relative;
    width: 100%;
    background: #000;
}

.video-info {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 15px 20px;
    background: #2a2a2a;
    border-top: 1px solid #333;
}

.video-quality-info {
    display: flex;
    gap: 10px;
}

.quality-badge {
    background: #ff6b35;
    color: #fff;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 12px;
    font-weight: bold;
}

.video-actions {
    display: flex;
    gap: 10px;
}

.video-action-btn {
    background: transparent;
    border: 1px solid #555;
    color: #ccc;
    padding: 8px 12px;
    border-radius: 5px;
    cursor: pointer;
    transition: all 0.3s ease;
    font-size: 12px;
}

.video-action-btn:hover {
    background: #ff6b35;
    border-color: #ff6b35;
    color: #fff;
}

.video-action-btn i {
    margin-right: 5px;
}

/* Responsive */
@media (max-width: 768px) {
    .video-tab-btn {
        padding: 12px 15px;
        font-size: 12px;
    }
    
    .video-info {
        flex-direction: column;
        gap: 15px;
        align-items: flex-start;
    }
    
    .video-actions {
        width: 100%;
        justify-content: space-between;
    }
    
    .video-action-btn {
        flex: 1;
        text-align: center;
    }
}
</style>

<script>
jQuery(document).ready(function($) {
    // Video tab switching
    $('.video-tab-btn').on('click', function() {
        const tabId = $(this).data('tab');
        
        // Remove active class from all tabs and panes
        $('.video-tab-btn').removeClass('active');
        $('.video-tab-pane').removeClass('active');
        
        // Add active class to clicked tab and corresponding pane
        $(this).addClass('active');
        $('#' + tabId).addClass('active');
        
        // Reinitialize video player for the active tab
        const activePane = $('#' + tabId);
        const videoPlayer = activePane.find('.torofilm-video-player');
        
        if (videoPlayer.length > 0) {
            // Destroy existing player if any
            if (window.TorofilmVideoPlayer) {
                videoPlayer.each(function() {
                    if (this.torofilmPlayer) {
                        this.torofilmPlayer.destroy();
                    }
                });
            }
            
            // Initialize new player
            videoPlayer.each(function() {
                new TorofilmVideoPlayer(this);
            });
        }
    });
});

// Video action functions
function shareVideo() {
    if (navigator.share) {
        navigator.share({
            title: '<?php echo esc_js(get_the_title()); ?>',
            url: window.location.href
        });
    } else {
        // Fallback: copy to clipboard
        navigator.clipboard.writeText(window.location.href).then(function() {
            alert('Link kopyalandı!');
        });
    }
}

function downloadVideo() {
    alert('İndirme özelliği yakında eklenecek!');
}

function reportVideo() {
    const reason = prompt('Bildirim sebebi:');
    if (reason) {
        alert('Bildiriminiz alındı. Teşekkürler!');
    }
}
</script>
