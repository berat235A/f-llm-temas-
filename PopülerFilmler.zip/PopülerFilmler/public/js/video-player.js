/**
 * Torofilm Video Player JavaScript
 * 
 * @package Torofilm
 * @since 1.0.0
 */

(function($) {
    'use strict';
    
    // Video Player Class
    class TorofilmVideoPlayer {
        constructor(element) {
            this.element = $(element);
            this.iframe = this.element.find('.video-iframe iframe');
            this.video = this.element.find('.video-direct');
            this.controls = this.element.find('.torofilm-video-controls');
            this.host = this.element.data('host');
            
            this.init();
        }
        
        init() {
            this.createControls();
            this.bindEvents();
            this.addAccessibility();
        }
        
        createControls() {
            if (this.controls.length === 0) {
                const controlsHtml = `
                    <div class="torofilm-video-controls">
                        <div class="control-left">
                            <button class="control-btn play-pause" aria-label="Oynat/Duraklat">
                                <i class="fa fa-play"></i>
                            </button>
                            <button class="control-btn volume" aria-label="Ses">
                                <i class="fa fa-volume-up"></i>
                            </button>
                        </div>
                        <div class="control-center">
                            <div class="progress-bar">
                                <div class="progress-fill"></div>
                            </div>
                        </div>
                        <div class="control-right">
                            <button class="control-btn settings" aria-label="Ayarlar">
                                <i class="fa fa-cog"></i>
                            </button>
                            <button class="control-btn fullscreen" aria-label="Tam Ekran">
                                <i class="fa fa-expand"></i>
                            </button>
                        </div>
                    </div>
                `;
                
                this.element.append(controlsHtml);
                this.controls = this.element.find('.torofilm-video-controls');
            }
        }
        
        bindEvents() {
            // Play/Pause button
            this.controls.find('.play-pause').on('click', () => {
                this.togglePlayPause();
            });
            
            // Volume button
            this.controls.find('.volume').on('click', () => {
                this.toggleMute();
            });
            
            // Fullscreen button
            this.controls.find('.fullscreen').on('click', () => {
                this.toggleFullscreen();
            });
            
            // Settings button
            this.controls.find('.settings').on('click', () => {
                this.showSettings();
            });
            
            // Progress bar
            this.controls.find('.progress-bar').on('click', (e) => {
                this.seekTo(e);
            });
            
            // Keyboard shortcuts
            $(document).on('keydown', (e) => {
                if (this.element.is(':hover') || this.element.hasClass('fullscreen')) {
                    this.handleKeyboard(e);
                }
            });
            
            // Mouse events
            this.element.on('mouseenter', () => {
                this.controls.fadeIn();
            });
            
            this.element.on('mouseleave', () => {
                if (!this.element.hasClass('fullscreen')) {
                    this.controls.fadeOut();
                }
            });
            
            // Resize events
            $(window).on('resize', () => {
                this.handleResize();
            });
        }
        
        togglePlayPause() {
            const playBtn = this.controls.find('.play-pause i');
            
            if (this.video.length > 0) {
                if (this.video[0].paused) {
                    this.video[0].play();
                    playBtn.removeClass('fa-play').addClass('fa-pause');
                } else {
                    this.video[0].pause();
                    playBtn.removeClass('fa-pause').addClass('fa-play');
                }
            } else if (this.iframe.length > 0) {
                // For iframe videos, we can't control them directly
                // But we can show a message or try to communicate with the iframe
                this.showMessage('Iframe video kontrolü desteklenmiyor');
            }
        }
        
        toggleMute() {
            const volumeBtn = this.controls.find('.volume i');
            
            if (this.video.length > 0) {
                if (this.video[0].muted) {
                    this.video[0].muted = false;
                    volumeBtn.removeClass('fa-volume-mute').addClass('fa-volume-up');
                } else {
                    this.video[0].muted = true;
                    volumeBtn.removeClass('fa-volume-up').addClass('fa-volume-mute');
                }
            }
        }
        
        toggleFullscreen() {
            const fullscreenBtn = this.controls.find('.fullscreen i');
            
            if (!document.fullscreenElement) {
                if (this.element[0].requestFullscreen) {
                    this.element[0].requestFullscreen();
                } else if (this.element[0].webkitRequestFullscreen) {
                    this.element[0].webkitRequestFullscreen();
                } else if (this.element[0].msRequestFullscreen) {
                    this.element[0].msRequestFullscreen();
                }
                
                this.element.addClass('fullscreen');
                fullscreenBtn.removeClass('fa-expand').addClass('fa-compress');
            } else {
                if (document.exitFullscreen) {
                    document.exitFullscreen();
                } else if (document.webkitExitFullscreen) {
                    document.webkitExitFullscreen();
                } else if (document.msExitFullscreen) {
                    document.msExitFullscreen();
                }
                
                this.element.removeClass('fullscreen');
                fullscreenBtn.removeClass('fa-compress').addClass('fa-expand');
            }
        }
        
        showSettings() {
            const settingsHtml = `
                <div class="video-settings">
                    <h3>Video Ayarları</h3>
                    <div class="setting-group">
                        <label>Kalite:</label>
                        <select class="quality-select">
                            <option value="auto">Otomatik</option>
                            <option value="1080p">1080p</option>
                            <option value="720p">720p</option>
                            <option value="480p">480p</option>
                            <option value="360p">360p</option>
                        </select>
                    </div>
                    <div class="setting-group">
                        <label>Hız:</label>
                        <select class="speed-select">
                            <option value="0.5">0.5x</option>
                            <option value="0.75">0.75x</option>
                            <option value="1" selected>1x</option>
                            <option value="1.25">1.25x</option>
                            <option value="1.5">1.5x</option>
                            <option value="2">2x</option>
                        </select>
                    </div>
                    <button class="close-settings">Kapat</button>
                </div>
            `;
            
            const settingsModal = $(settingsHtml);
            this.element.append(settingsModal);
            
            settingsModal.find('.close-settings').on('click', () => {
                settingsModal.remove();
            });
            
            settingsModal.find('.speed-select').on('change', (e) => {
                if (this.video.length > 0) {
                    this.video[0].playbackRate = parseFloat(e.target.value);
                }
            });
        }
        
        seekTo(event) {
            if (this.video.length > 0) {
                const progressBar = $(event.currentTarget);
                const clickX = event.offsetX;
                const barWidth = progressBar.width();
                const seekTime = (clickX / barWidth) * this.video[0].duration;
                
                this.video[0].currentTime = seekTime;
            }
        }
        
        handleKeyboard(event) {
            switch(event.key) {
                case ' ':
                case 'k':
                    event.preventDefault();
                    this.togglePlayPause();
                    break;
                case 'm':
                    event.preventDefault();
                    this.toggleMute();
                    break;
                case 'f':
                    event.preventDefault();
                    this.toggleFullscreen();
                    break;
                case 'ArrowLeft':
                    event.preventDefault();
                    this.seek(-10);
                    break;
                case 'ArrowRight':
                    event.preventDefault();
                    this.seek(10);
                    break;
                case 'ArrowUp':
                    event.preventDefault();
                    this.changeVolume(0.1);
                    break;
                case 'ArrowDown':
                    event.preventDefault();
                    this.changeVolume(-0.1);
                    break;
            }
        }
        
        seek(seconds) {
            if (this.video.length > 0) {
                this.video[0].currentTime += seconds;
            }
        }
        
        changeVolume(delta) {
            if (this.video.length > 0) {
                const newVolume = Math.max(0, Math.min(1, this.video[0].volume + delta));
                this.video[0].volume = newVolume;
                
                if (newVolume === 0) {
                    this.controls.find('.volume i').removeClass('fa-volume-up').addClass('fa-volume-mute');
                } else {
                    this.controls.find('.volume i').removeClass('fa-volume-mute').addClass('fa-volume-up');
                }
            }
        }
        
        handleResize() {
            if (this.element.hasClass('fullscreen')) {
                this.element.css({
                    'width': '100vw',
                    'height': '100vh'
                });
            }
        }
        
        addAccessibility() {
            this.element.attr('role', 'application');
            this.element.attr('aria-label', 'Video Player');
            
            // Add ARIA labels to controls
            this.controls.find('.control-btn').each(function() {
                if (!$(this).attr('aria-label')) {
                    $(this).attr('aria-label', 'Video Control');
                }
            });
        }
        
        showMessage(message) {
            const messageHtml = `<div class="video-message">${message}</div>`;
            const messageEl = $(messageHtml);
            
            this.element.append(messageEl);
            
            setTimeout(() => {
                messageEl.fadeOut(() => {
                    messageEl.remove();
                });
            }, 3000);
        }
        
        destroy() {
            this.controls.remove();
            this.element.off();
        }
    }
    
    // Initialize video players when document is ready
    $(document).ready(function() {
        $('.torofilm-video-player').each(function() {
            new TorofilmVideoPlayer(this);
        });
    });
    
    // AJAX video embed handler
    $(document).on('submit', '.video-embed-form', function(e) {
        e.preventDefault();
        
        const form = $(this);
        const url = form.find('input[name="video_url"]').val();
        const container = form.find('.video-container');
        
        if (!url) {
            alert('Lütfen video URL\'si girin!');
            return;
        }
        
        // Show loading
        container.html('<div class="torofilm-video-loading">Video yükleniyor...</div>');
        
        // AJAX request
        $.ajax({
            url: torofilm_video.ajax_url,
            type: 'POST',
            data: {
                action: 'get_video_embed',
                url: url,
                nonce: torofilm_video.nonce
            },
            success: function(response) {
                if (response.success) {
                    container.html(response.data.html);
                    
                    // Reinitialize video player
                    container.find('.torofilm-video-player').each(function() {
                        new TorofilmVideoPlayer(this);
                    });
                } else {
                    container.html('<div class="torofilm-video-error">Video yüklenemedi!</div>');
                }
            },
            error: function() {
                container.html('<div class="torofilm-video-error">Bir hata oluştu!</div>');
            }
        });
    });
    
    // Video URL validation
    function validateVideoUrl(url) {
        const supportedHosts = torofilm_video.supported_hosts;
        
        for (let host of supportedHosts) {
            if (url.includes(host)) {
                return true;
            }
        }
        
        return false;
    }
    
    // Export for global use
    window.TorofilmVideoPlayer = TorofilmVideoPlayer;
    
})(jQuery);
