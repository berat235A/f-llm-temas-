/**
 * TOROFILM MOBİL JAVASCRIPT
 * Mobil cihazlar için özel JavaScript fonksiyonları
 */

(function() {
    'use strict';
    
    // DOM yüklendiğinde çalışacak fonksiyonlar
    document.addEventListener('DOMContentLoaded', function() {
        initMobileMenu();
        initTouchGestures();
        
        // Swiper'ı biraz gecikmeyle başlat
        setTimeout(function() {
            initSwiperMobile();
        }, 100);
        
        initLazyLoading();
        initMobileOptimizations();
    });
    
    /**
     * Mobil menü işlevleri
     */
    function initMobileMenu() {
        const menuToggle = document.getElementById('mobile-menu-toggle');
        const mainNav = document.getElementById('main-nav');
        const overlay = document.getElementById('mobile-menu-overlay');
        const body = document.body;
        
        if (!menuToggle || !mainNav || !overlay) return;
        
        // Menü açma/kapama
        menuToggle.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const isActive = mainNav.classList.contains('active');
            
            if (isActive) {
                closeMobileMenu();
            } else {
                openMobileMenu();
            }
        });
        
        // Overlay'e tıklayınca menüyü kapat
        overlay.addEventListener('click', function() {
            closeMobileMenu();
        });
        
        // Menü linklerine tıklayınca menüyü kapat
        const menuLinks = mainNav.querySelectorAll('a');
        menuLinks.forEach(function(link) {
            link.addEventListener('click', function() {
                closeMobileMenu();
            });
        });
        
        // ESC tuşu ile menüyü kapat
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && mainNav.classList.contains('active')) {
                closeMobileMenu();
            }
        });
        
        function openMobileMenu() {
            mainNav.classList.add('active');
            overlay.classList.add('active');
            menuToggle.classList.add('active');
            body.style.overflow = 'hidden';
            
            // Animasyon için küçük gecikme
            setTimeout(function() {
                mainNav.style.transform = 'translateX(0)';
            }, 10);
        }
        
        function closeMobileMenu() {
            mainNav.classList.remove('active');
            overlay.classList.remove('active');
            menuToggle.classList.remove('active');
            body.style.overflow = '';
            
            // Animasyon için küçük gecikme
            setTimeout(function() {
                mainNav.style.transform = 'translateX(-100%)';
            }, 10);
        }
    }
    
    /**
     * Touch jestleri ve kaydırma işlevleri
     */
    function initTouchGestures() {
        let startY = 0;
        let startX = 0;
        let isScrolling = false;
        
        // Touch başlangıcı - swiper alanları hariç
        document.addEventListener('touchstart', function(e) {
            // Swiper alanında değilse touch gesture'ları aktif et
            if (!e.target.closest('.swiper-wrapper') && !e.target.closest('.swiper-slide')) {
                startY = e.touches[0].clientY;
                startX = e.touches[0].clientX;
                isScrolling = false;
            }
        }, { passive: true });
        
        // Touch hareketi - swiper alanları hariç
        document.addEventListener('touchmove', function(e) {
            if (!e.target.closest('.swiper-wrapper') && !e.target.closest('.swiper-slide')) {
                if (!startY || !startX) return;
                
                const currentY = e.touches[0].clientY;
                const currentX = e.touches[0].clientX;
                const diffY = startY - currentY;
                const diffX = startX - currentX;
                
                // Yatay kaydırma tespiti
                if (Math.abs(diffX) > Math.abs(diffY)) {
                    isScrolling = true;
                }
                
                // Dikey kaydırma tespiti
                if (Math.abs(diffY) > Math.abs(diffX)) {
                    isScrolling = true;
                }
            }
        }, { passive: true });
        
        // Touch bitişi
        document.addEventListener('touchend', function(e) {
            startY = 0;
            startX = 0;
            isScrolling = false;
        }, { passive: true });
        
        // Pull-to-refresh benzeri işlev
        let pullStartY = 0;
        let isPulling = false;
        
        document.addEventListener('touchstart', function(e) {
            if (window.scrollY === 0) {
                pullStartY = e.touches[0].clientY;
                isPulling = true;
            }
        }, { passive: true });
        
        document.addEventListener('touchmove', function(e) {
            if (!isPulling || window.scrollY > 0) return;
            
            const currentY = e.touches[0].clientY;
            const diffY = currentY - pullStartY;
            
            if (diffY > 50) {
                // Pull-to-refresh tetikle
                handlePullToRefresh();
                isPulling = false;
            }
        }, { passive: true });
        
        document.addEventListener('touchend', function() {
            isPulling = false;
        }, { passive: true });
    }
    
    /**
     * Swiper mobil optimizasyonları - Güncellenmiş
     */
    function initSwiperMobile() {
        // Mobil cihazlarda gelişmiş swiper
        if (window.innerWidth <= 768) {
            console.log('🚀 Mobil Swiper optimizasyonu başlatılıyor...');
            
            // Movies slider için gelişmiş mobil swiper
            const moviesSwiper = new Swiper('#moviesSwiper', {
                // Temel ayarlar - Mobil için optimize edilmiş
                slidesPerView: 'auto',
                spaceBetween: 12,
                grabCursor: true,
                centeredSlides: false,
                loop: false,
                
                // Free mode - Mobil için daha iyi deneyim
                freeMode: {
                    enabled: true,
                    sticky: true,
                    momentum: true,
                    momentumRatio: 0.5,
                    momentumBounce: true,
                    momentumBounceRatio: 0.5,
                },
                
                // Touch ayarları - İyileştirilmiş
                touchRatio: 1.5,
                touchAngle: 45,
                simulateTouch: true,
                allowTouchMove: true,
                touchStartPreventDefault: false,
                touchMoveStopPropagation: false,
                
                // İleri/Geri Butonları - Mobil için optimize
                navigation: {
                    nextEl: '.swiper-button-next',
                    prevEl: '.swiper-button-prev',
                },
                
                // Pagination - Mobil için daha iyi
                pagination: {
                    el: '.swiper-pagination',
                    type: 'bullets',
                    clickable: true,
                    dynamicBullets: true,
                },
                
                // Autoplay - Mobil için daha yavaş
                autoplay: {
                    delay: 5000,
                    disableOnInteraction: false,
                    pauseOnMouseEnter: true,
                },
                
                // Responsive breakpoints - Filmlerin dışarıya taşmaması için düzeltilmiş
                breakpoints: {
                    320: {
                        slidesPerView: 2.2,
                        spaceBetween: 12,
                        slidesOffsetBefore: 10,
                        slidesOffsetAfter: 10,
                    },
                    480: {
                        slidesPerView: 2.8,
                        spaceBetween: 15,
                        slidesOffsetBefore: 15,
                        slidesOffsetAfter: 15,
                    },
                    640: {
                        slidesPerView: 3.2,
                        spaceBetween: 18,
                        slidesOffsetBefore: 20,
                        slidesOffsetAfter: 20,
                    },
                    768: {
                        slidesPerView: 3.5,
                        spaceBetween: 20,
                        slidesOffsetBefore: 25,
                        slidesOffsetAfter: 25,
                    }
                },
                
                // Event listeners - Mobil için optimize
                on: {
                    init: function () {
                        console.log('✅ Mobil Movies Swiper başarıyla başlatıldı');
                        
                        // Mobil için pagination'ı göster
                        const pagination = this.pagination.el;
                        if (pagination) {
                            pagination.style.display = 'block';
                            pagination.style.marginTop = '15px';
                        }
                    },
                    
                    slideChange: function () {
                        // Mobil için slide değişim animasyonu
                        this.slides.forEach((slide, index) => {
                            if (index === this.activeIndex) {
                                slide.style.transform = 'scale(1.05)';
                                slide.style.transition = 'transform 0.3s ease';
                            } else {
                                slide.style.transform = 'scale(1)';
                            }
                        });
                    }
                }
            });
            
            // Series slider için Swiper.js coverflow
            const seriesSwiper = new Swiper('#seriesSwiper', {
                // Coverflow efekti
                effect: 'coverflow',
                grabCursor: true,
                
                // Aktif diziyi her zaman ortada tutar
                centeredSlides: true,
                
                // Ekranda kaç dizi görüneceği
                slidesPerView: 'auto',
                
                // Sonsuz döngü kapalı
                loop: false,
                
                // Coverflow efektinin ayarları
                coverflowEffect: {
                    rotate: 25,       // Yanlardaki dizilerin açısı
                    stretch: 0,
                    depth: 80,        // Mobil için daha az derinlik
                    modifier: 1,
                    slideShadows: false,
                },
                
                // İleri/Geri Butonları
                navigation: {
                    nextEl: '.swiper-button-next',
                    prevEl: '.swiper-button-prev',
                },
                
                // Mobil için özel ayarlar
                spaceBetween: 15,
                speed: 300,
                
                // Touch ayarları
                touchRatio: 1,
                touchAngle: 45,
                simulateTouch: true,
                allowTouchMove: true,
                
                // Responsive breakpoints
                breakpoints: {
                    320: {
                        coverflowEffect: {
                            rotate: 20,
                            depth: 60,
                        }
                    },
                    480: {
                        coverflowEffect: {
                            rotate: 25,
                            depth: 80,
                        }
                    },
                    768: {
                        coverflowEffect: {
                            rotate: 30,
                            depth: 100,
                        }
                    }
                }
            });
            
            console.log('Swiper.js coverflow efektleri başarıyla yüklendi!');
        }
    }
    
    // Görünür kart sayısını hesapla
    function getVisibleCards(width) {
        if (width <= 480) return 2;
        if (width <= 768) return 3;
        return 4;
    }
    
    // Gelişmiş Mobil Swiper Class
    class AdvancedMobileSwiper {
        constructor(container, options = {}) {
            this.container = container;
            this.wrapper = container.querySelector('.swiper-wrapper');
            this.prevBtn = container.querySelector('.swiper-button-prev');
            this.nextBtn = container.querySelector('.swiper-button-next');
            this.cards = container.querySelectorAll('.swiper-slide');
            
            this.currentIndex = 0;
            this.cardWidth = options.cardWidth || 160;
            this.gap = options.gap || 15;
            this.visibleCards = options.visibleCards || 3;
            this.maxIndex = Math.max(0, this.cards.length - this.visibleCards);
            
            this.init();
        }
        
        init() {
            this.updateButtons();
            this.addEventListeners();
            this.addTouchSupport();
            this.addMouseSupport();
            
            // Responsive güncelleme
            window.addEventListener('resize', () => {
                this.visibleCards = getVisibleCards(window.innerWidth);
                this.maxIndex = Math.max(0, this.cards.length - this.visibleCards);
                this.currentIndex = Math.min(this.currentIndex, this.maxIndex);
                this.updatePosition();
                this.updateButtons();
            });
        }
        
        addEventListeners() {
            if (this.prevBtn) {
                this.prevBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    this.prev();
                });
            }
            
            if (this.nextBtn) {
                this.nextBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    this.next();
                });
            }
        }
        
        addTouchSupport() {
            let startX = 0;
            let currentX = 0;
            let isDragging = false;
            
            this.wrapper.addEventListener('touchstart', (e) => {
                startX = e.touches[0].clientX;
                isDragging = true;
                this.wrapper.style.transition = 'none';
            }, { passive: true });
            
            this.wrapper.addEventListener('touchmove', (e) => {
                if (!isDragging) return;
                
                currentX = e.touches[0].clientX;
                const diffX = startX - currentX;
                const currentTransform = this.currentIndex * (this.cardWidth + this.gap);
                
                this.wrapper.style.transform = `translateX(-${currentTransform + diffX}px)`;
            }, { passive: true });
            
            this.wrapper.addEventListener('touchend', (e) => {
                if (!isDragging) return;
                
                isDragging = false;
                this.wrapper.style.transition = 'transform 0.3s ease';
                
                const diffX = startX - currentX;
                const threshold = 50;
                
                if (diffX > threshold && this.currentIndex < this.maxIndex) {
                    this.next();
                } else if (diffX < -threshold && this.currentIndex > 0) {
                    this.prev();
                } else {
                    this.updatePosition();
                }
            }, { passive: true });
        }
        
        addMouseSupport() {
            let mouseStartX = 0;
            let mouseCurrentX = 0;
            let isMouseDragging = false;
            
            this.wrapper.addEventListener('mousedown', (e) => {
                mouseStartX = e.clientX;
                isMouseDragging = true;
                this.wrapper.style.transition = 'none';
                this.wrapper.style.cursor = 'grabbing';
            });
            
            this.wrapper.addEventListener('mousemove', (e) => {
                if (!isMouseDragging) return;
                
                mouseCurrentX = e.clientX;
                const diffX = mouseStartX - mouseCurrentX;
                const currentTransform = this.currentIndex * (this.cardWidth + this.gap);
                
                this.wrapper.style.transform = `translateX(-${currentTransform + diffX}px)`;
            });
            
            this.wrapper.addEventListener('mouseup', (e) => {
                if (!isMouseDragging) return;
                
                isMouseDragging = false;
                this.wrapper.style.transition = 'transform 0.3s ease';
                this.wrapper.style.cursor = 'grab';
                
                const diffX = mouseStartX - mouseCurrentX;
                const threshold = 50;
                
                if (diffX > threshold && this.currentIndex < this.maxIndex) {
                    this.next();
                } else if (diffX < -threshold && this.currentIndex > 0) {
                    this.prev();
                } else {
                    this.updatePosition();
                }
            });
            
            this.wrapper.addEventListener('mouseleave', () => {
                if (isMouseDragging) {
                    isMouseDragging = false;
                    this.wrapper.style.transition = 'transform 0.3s ease';
                    this.wrapper.style.cursor = 'grab';
                    this.updatePosition();
                }
            });
        }
        
        prev() {
            if (this.currentIndex > 0) {
                this.currentIndex--;
                this.updatePosition();
                this.updateButtons();
            }
        }
        
        next() {
            if (this.currentIndex < this.maxIndex) {
                this.currentIndex++;
                this.updatePosition();
                this.updateButtons();
            }
        }
        
        updatePosition() {
            const translateX = this.currentIndex * (this.cardWidth + this.gap);
            this.wrapper.style.transform = `translateX(-${translateX}px)`;
        }
        
        updateButtons() {
            if (this.prevBtn) {
                this.prevBtn.disabled = this.currentIndex === 0;
            }
            if (this.nextBtn) {
                this.nextBtn.disabled = this.currentIndex >= this.maxIndex;
            }
        }
    }
    
    /**
     * Lazy loading optimizasyonu
     */
    function initLazyLoading() {
        // Intersection Observer API ile lazy loading
        if ('IntersectionObserver' in window) {
            const imageObserver = new IntersectionObserver(function(entries, observer) {
                entries.forEach(function(entry) {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        if (img.dataset.src) {
                            img.src = img.dataset.src;
                            img.classList.remove('lazy');
                            img.classList.add('loaded');
                            observer.unobserve(img);
                        }
                    }
                });
            }, {
                rootMargin: '50px 0px',
                threshold: 0.01
            });
            
            // Lazy loading için img etiketlerini bul
            const lazyImages = document.querySelectorAll('img[data-src]');
            lazyImages.forEach(function(img) {
                imageObserver.observe(img);
            });
        }
    }
    
    /**
     * Mobil optimizasyonları
     */
    function initMobileOptimizations() {
        // Viewport height düzeltmesi (iOS Safari için)
        function setViewportHeight() {
            const vh = window.innerHeight * 0.01;
            document.documentElement.style.setProperty('--vh', vh + 'px');
        }
        
        setViewportHeight();
        window.addEventListener('resize', setViewportHeight);
        window.addEventListener('orientationchange', function() {
            setTimeout(setViewportHeight, 100);
        });
        
        // Touch feedback
        const touchElements = document.querySelectorAll('button, .btn, .movie-poster, .series-poster, .content-poster, .platform-card, .category-card');
        
        touchElements.forEach(function(element) {
            element.addEventListener('touchstart', function() {
                this.classList.add('touch-active');
            }, { passive: true });
            
            element.addEventListener('touchend', function() {
                const self = this;
                setTimeout(function() {
                    self.classList.remove('touch-active');
                }, 150);
            }, { passive: true });
            
            element.addEventListener('touchcancel', function() {
                this.classList.remove('touch-active');
            }, { passive: true });
        });
        
        // Smooth scroll
        const smoothScrollLinks = document.querySelectorAll('a[href^="#"]');
        smoothScrollLinks.forEach(function(link) {
            link.addEventListener('click', function(e) {
                const targetId = this.getAttribute('href');
                if (targetId === '#') return;
                
                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    e.preventDefault();
                    targetElement.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
        
        // Form optimizasyonları
        const forms = document.querySelectorAll('form');
        forms.forEach(function(form) {
            const inputs = form.querySelectorAll('input, textarea, select');
            
            inputs.forEach(function(input) {
                // Input focus optimizasyonu
                input.addEventListener('focus', function() {
                    // iOS için viewport ayarı
                    if (window.innerWidth <= 768) {
                        setTimeout(function() {
                            input.scrollIntoView({
                                behavior: 'smooth',
                                block: 'center'
                            });
                        }, 300);
                    }
                });
                
                // Input blur optimizasyonu
                input.addEventListener('blur', function() {
                    // Klavye kapatıldığında viewport'u düzelt
                    setTimeout(function() {
                        window.scrollTo(0, 0);
                    }, 100);
                });
            });
        });
        
        // Performance optimizasyonu
        let ticking = false;
        
        function updateOnScroll() {
            // Scroll event optimizasyonu
            ticking = false;
        }
        
        function requestTick() {
            if (!ticking) {
                requestAnimationFrame(updateOnScroll);
                ticking = true;
            }
        }
        
        window.addEventListener('scroll', requestTick, { passive: true });
        
        // Resize optimizasyonu
        let resizeTimeout;
        window.addEventListener('resize', function() {
            clearTimeout(resizeTimeout);
            resizeTimeout = setTimeout(function() {
                // Resize işlemleri
                setViewportHeight();
            }, 250);
        });
    }
    
    /**
     * Pull-to-refresh işlevi
     */
    function handlePullToRefresh() {
        // Pull-to-refresh animasyonu
        const refreshIndicator = document.createElement('div');
        refreshIndicator.className = 'pull-to-refresh-indicator';
        refreshIndicator.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Yenileniyor...';
        refreshIndicator.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            background: var(--primary);
            color: white;
            text-align: center;
            padding: 10px;
            z-index: 9999;
            transform: translateY(-100%);
            transition: transform 0.3s ease;
        `;
        
        document.body.appendChild(refreshIndicator);
        
        // Animasyonu başlat
        setTimeout(function() {
            refreshIndicator.style.transform = 'translateY(0)';
        }, 10);
        
        // Sayfayı yenile
        setTimeout(function() {
            window.location.reload();
        }, 1000);
    }
    
    /**
     * Mobil cihaz tespiti
     */
    function isMobile() {
        return window.innerWidth <= 768 || /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    }
    
    /**
     * Touch cihaz tespiti
     */
    function isTouchDevice() {
        return 'ontouchstart' in window || navigator.maxTouchPoints > 0;
    }
    
    /**
     * iOS tespiti
     */
    function isIOS() {
        return /iPad|iPhone|iPod/.test(navigator.userAgent);
    }
    
    /**
     * Android tespiti
     */
    function isAndroid() {
        return /Android/.test(navigator.userAgent);
    }
    
    // Global fonksiyonları window objesine ekle
    window.ToroFilmMobile = {
        isMobile: isMobile,
        isTouchDevice: isTouchDevice,
        isIOS: isIOS,
        isAndroid: isAndroid,
        openMobileMenu: function() {
            const mainNav = document.getElementById('main-nav');
            const overlay = document.getElementById('mobile-menu-overlay');
            const menuToggle = document.getElementById('mobile-menu-toggle');
            
            if (mainNav && overlay && menuToggle) {
                mainNav.classList.add('active');
                overlay.classList.add('active');
                menuToggle.classList.add('active');
                document.body.style.overflow = 'hidden';
            }
        },
        closeMobileMenu: function() {
            const mainNav = document.getElementById('main-nav');
            const overlay = document.getElementById('mobile-menu-overlay');
            const menuToggle = document.getElementById('mobile-menu-toggle');
            
            if (mainNav && overlay && menuToggle) {
                mainNav.classList.remove('active');
                overlay.classList.remove('active');
                menuToggle.classList.remove('active');
                document.body.style.overflow = '';
            }
        }
    };
    
})();
