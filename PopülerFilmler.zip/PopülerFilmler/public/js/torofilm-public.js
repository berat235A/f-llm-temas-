/**
    *   Load More Results v1.0.0
    * Author: Cenk Çalgan
    * 
    * Options:
    * - tag (object):
    *       - name (string)
    *       - class (string)
    * - displayedItems (int)
    *   - showItems (int)
    * - button (object):
    *       - class (string)
    *       - text (string)
*/

/**
 * Advanced Swiper Mode with Enhanced Features
 */
function initSliders() {
    console.log('🚀 Gelişmiş Swiper Modu başlatılıyor...');
    
    // Movies slider için gelişmiş Swiper
    const moviesContainer = document.getElementById('moviesSwiper');
    if (moviesContainer) {
        // Swiper.js kütüphanesi yüklü mü kontrol et
        if (typeof Swiper !== 'undefined') {
            console.log('✅ Swiper.js kütüphanesi yüklendi ve hazır!');
            const moviesSwiper = new Swiper("#moviesSwiper", {
                // Temel ayarlar - Güncellenmiş
                slidesPerView: 'auto',
                spaceBetween: 15,
                freeMode: {
                    enabled: true,
                    sticky: true,
                },
                grabCursor: true,
                centeredSlides: false,
                loop: false,
                
                // Touch ve click ayarları - İyileştirilmiş
                allowTouchMove: true,
                preventClicks: false,
                preventClicksPropagation: false,
                touchStartPreventDefault: false,
                touchMoveStopPropagation: false,
                touchRatio: 1.5,
                touchAngle: 45,
                simulateTouch: true,
                
                // Pagination ayarları - Güncellenmiş
                pagination: {
                    el: ".swiper-pagination",
                    type: "bullets",
                    clickable: true,
                    dynamicBullets: true,
                },
                
                // Navigation ayarları - İyileştirilmiş
                navigation: {
                    nextEl: ".swiper-button-next",
                    prevEl: ".swiper-button-prev",
                },
                
                // Autoplay - Güncellenmiş
                autoplay: {
                    delay: 4000,
                    disableOnInteraction: false,
                    pauseOnMouseEnter: true,
                    stopOnLastSlide: false,
                },
                
                // Responsive breakpoints - Filmlerin dışarıya taşmaması için düzeltilmiş
                breakpoints: {
                    320: {
                        slidesPerView: 2.2,
                        spaceBetween: 12,
                        freeMode: {
                            enabled: true,
                            sticky: false,
                        },
                        centeredSlides: false,
                        slidesOffsetBefore: 10,
                        slidesOffsetAfter: 10,
                    },
                    480: {
                        slidesPerView: 2.8,
                        spaceBetween: 15,
                        slidesOffsetBefore: 15,
                        slidesOffsetAfter: 15,
                    },
                    640: {
                        slidesPerView: 3.2,
                        spaceBetween: 18,
                        slidesOffsetBefore: 20,
                        slidesOffsetAfter: 20,
                    },
                    768: {
                        slidesPerView: 3.5,
                        spaceBetween: 20,
                        slidesOffsetBefore: 25,
                        slidesOffsetAfter: 25,
                    },
                    1024: {
                        slidesPerView: 4.2,
                        spaceBetween: 22,
                        slidesOffsetBefore: 30,
                        slidesOffsetAfter: 30,
                    },
                    1200: {
                        slidesPerView: 5,
                        spaceBetween: 25,
                        slidesOffsetBefore: 35,
                        slidesOffsetAfter: 35,
                    },
                    1400: {
                        slidesPerView: 6,
                        spaceBetween: 30,
                        slidesOffsetBefore: 40,
                        slidesOffsetAfter: 40,
                    }
                },
                
                // Event listeners
                on: {
                    init: function () {
                        console.log('✅ Movies Swiper başarıyla başlatıldı');
                        // Pagination'ı göster
                        const pagination = this.pagination.el;
                        if (pagination) {
                            pagination.style.display = 'block';
                        }
                        
                        // Click event handling
                        this.slides.forEach((slide, index) => {
                            slide.addEventListener('click', function(e) {
                                // Eğer Swiper'ın touch event'i aktifse, link'e gitme
                                if (moviesSwiper.touchEventsData && moviesSwiper.touchEventsData.isTouched) {
                                    e.preventDefault();
                                    return false;
                                }
                            });
                        });
                    },
                    slideChange: function () {
                        // Slide değiştiğinde özel işlemler
                        console.log('Slide değişti:', this.activeIndex);
                    },
                    reachEnd: function () {
                        console.log('Son slide\'a ulaşıldı');
                    },
                    reachBeginning: function () {
                        console.log('İlk slide\'a ulaşıldı');
                    },
                    touchStart: function () {
                        console.log('Touch başladı');
                    },
                    touchEnd: function () {
                        console.log('Touch bitti');
                    }
                }
            });
            
            // Swiper instance'ını global olarak sakla
            window.moviesSwiper = moviesSwiper;
            
            // Keyboard navigation ekle
            document.addEventListener('keydown', function(e) {
                if (e.key === 'ArrowLeft') {
                    moviesSwiper.slidePrev();
                } else if (e.key === 'ArrowRight') {
                    moviesSwiper.slideNext();
                }
            });
            
        } else {
            // Fallback: Basit scroll implementasyonu
            console.log('Swiper.js bulunamadı, basit scroll kullanılıyor...');
            const moviesWrapper = moviesContainer.querySelector('.swiper-wrapper');
            if (moviesWrapper) {
                moviesWrapper.style.display = 'flex';
                moviesWrapper.style.overflowX = 'auto';
                moviesWrapper.style.scrollBehavior = 'smooth';
                moviesWrapper.style.gap = '20px';
                moviesWrapper.style.padding = '10px 0';
                moviesWrapper.style.scrollbarWidth = 'none';
                moviesWrapper.style.msOverflowStyle = 'none';
                
                const nextBtn = moviesContainer.querySelector('.swiper-button-next');
                const prevBtn = moviesContainer.querySelector('.swiper-button-prev');
                
                if (nextBtn) {
                    nextBtn.addEventListener('click', function(e) {
                        e.preventDefault();
                        moviesWrapper.scrollLeft += 221;
                    });
                }
                
                if (prevBtn) {
                    prevBtn.addEventListener('click', function(e) {
                        e.preventDefault();
                        moviesWrapper.scrollLeft -= 221;
                    });
                }
            }
        }
    }
    
    // Series slider için gelişmiş Swiper
    const seriesContainer = document.getElementById('seriesSwiper');
    if (seriesContainer) {
        if (typeof Swiper !== 'undefined') {
            console.log('✅ Swiper.js kütüphanesi Series için hazır!');
            const seriesSwiper = new Swiper("#seriesSwiper", {
                // Temel ayarlar
                slidesPerView: 'auto',
                spaceBetween: 20,
                freeMode: {
                    enabled: true,
                    sticky: true,
                },
                grabCursor: true,
                centeredSlides: false,
                loop: false,
                
                // Touch ve click ayarları
                allowTouchMove: true,
                preventClicks: false,
                preventClicksPropagation: false,
                touchStartPreventDefault: false,
                touchMoveStopPropagation: false,
                
                // Pagination ayarları
                pagination: {
                    el: ".swiper-pagination",
                    type: "fraction",
                    formatFractionCurrent: function (number) {
                        return number;
                    },
                    formatFractionTotal: function (number) {
                        return number;
                    },
                },
                
                // Navigation ayarları
                navigation: {
                    nextEl: ".swiper-button-next",
                    prevEl: ".swiper-button-prev",
                },
                
                // Autoplay (isteğe bağlı)
                autoplay: {
                    delay: 6000,
                    disableOnInteraction: false,
                    pauseOnMouseEnter: true,
                },
                
                // Responsive breakpoints
                breakpoints: {
                    320: {
                        slidesPerView: 2,
                        spaceBetween: 10,
                        freeMode: {
                            enabled: true,
                            sticky: false,
                        }
                    },
                    480: {
                        slidesPerView: 2.5,
                        spaceBetween: 12,
                    },
                    768: {
                        slidesPerView: 3,
                        spaceBetween: 15,
                    },
                    1024: {
                        slidesPerView: 4,
                        spaceBetween: 20,
                    },
                    1200: {
                        slidesPerView: 5,
                        spaceBetween: 20,
                    },
                    1400: {
                        slidesPerView: 6,
                        spaceBetween: 25,
                    }
                },
                
                // Event listeners
                on: {
                    init: function () {
                        console.log('✅ Series Swiper başarıyla başlatıldı');
                        // Pagination'ı göster
                        const pagination = this.pagination.el;
                        if (pagination) {
                            pagination.style.display = 'block';
                        }
                    },
                    slideChange: function () {
                        console.log('Series slide değişti:', this.activeIndex);
                    }
                }
            });
            
            // Swiper instance'ını global olarak sakla
            window.seriesSwiper = seriesSwiper;
            
            // Series için keyboard navigation ekle
            document.addEventListener('keydown', function(e) {
                if (e.key === 'ArrowLeft' && e.ctrlKey) {
                    seriesSwiper.slidePrev();
                } else if (e.key === 'ArrowRight' && e.ctrlKey) {
                    seriesSwiper.slideNext();
                }
            });
        } else {
            // Fallback: Basit scroll implementasyonu
            const seriesWrapper = seriesContainer.querySelector('.swiper-wrapper');
            if (seriesWrapper) {
                seriesWrapper.style.display = 'flex';
                seriesWrapper.style.overflowX = 'auto';
                seriesWrapper.style.scrollBehavior = 'smooth';
                seriesWrapper.style.gap = '20px';
                seriesWrapper.style.padding = '10px 0';
                seriesWrapper.style.scrollbarWidth = 'none';
                seriesWrapper.style.msOverflowStyle = 'none';
                
                const nextBtn = seriesContainer.querySelector('.swiper-button-next');
                const prevBtn = seriesContainer.querySelector('.swiper-button-prev');
                
                if (nextBtn) {
                    nextBtn.addEventListener('click', function(e) {
                        e.preventDefault();
                        seriesWrapper.scrollLeft += 221;
                    });
                }
                
                if (prevBtn) {
                    prevBtn.addEventListener('click', function(e) {
                        e.preventDefault();
                        seriesWrapper.scrollLeft -= 221;
                    });
                }
            }
        }
    }
}

(function ($) {
    'use strict';
    $.fn.loadMoreResults = function (options) {
        var defaults = {
            tag: {
                'name': 'tt',
                'class': 'tt-at'
            },
            displayedItems: 5,
            showItems: 5,
            button: {
                'class': 'btn-load-more',
                text: 'Load More'
            }
        };
        var opts = $.extend(true, {}, defaults, options);
        var alphaNumRE = /^[A-Za-z][-_A-Za-z0-9]+$/;
        var numRE = /^[0-9]+$/;
        $.each(opts, function validateOptions(key, val) {
            if (key === 'tag') {
                formatCheck(key, val, 'name', 'string');
                formatCheck(key, val, 'class', 'string');
            }
            if (key === 'displayedItems') {
                formatCheck(key, val, null, 'number');
            }
            if (key === 'showItems') {
                formatCheck(key, val, null, 'number');
            }
            if (key === 'button') {
                formatCheck(key, val, 'class', 'string');
            }
        });
        function formatCheck(key, val, prop, typ) {
            if (prop !== null && typeof prop !== 'object') {
                if (typeof val[prop] !== typ || String(val[prop]).match(typ == 'string' ? alphaNumRE : numRE) === null) {
                    opts[key][prop] = defaults[key][prop];
                }
            } else {
                if (typeof val !== typ || String(val).match(typ == 'string' ? alphaNumRE : numRE) === null) {
                    opts[key] = defaults[key];
                }
            }
        };
        return this.each(function (index, element) {
            var $list = $(element),
                    lc = $list.find(' > ' + opts.tag.name + '.' + opts.tag.class).length,
                    dc = parseInt(opts.displayedItems),
                    sc = parseInt(opts.showItems);
            console.log(lc);
            console.log(opts.tag.name);
            console.log(opts.tag.class);
            console.log($list);
            if(lc > 10){
                $list.find(' > ' + opts.tag.name + '.' + opts.tag.class + ':lt(' + dc + ')');
                $list.find(' > ' + opts.tag.name + '.' + opts.tag.class + ':gt(' + (dc - 1) + ')').css("display", "none");
                $('.loadactor').append('<tt><a href="javascript:void(0)" class="Button normal btn-view ' + opts.button.class + '">' + opts.button.text + '</a></tt>');
                $list.parent().on("click", ".btn-view", function (e) {
                    e.preventDefault();
                    dc = (dc + sc <= lc) ? dc + sc : lc;
                    $list.find(' > ' + opts.tag.name + '.' + opts.tag.class + ':lt(' + dc + ')').fadeIn();
                    if (dc == lc) {
                        $(this).hide();
                    }
                }); 
            }
        });
    };
})(jQuery);
jQuery(document).ready(function($){
    var templateUrl = object_name.templateUrl;

    $(document).on('click', '.rtg', function(event) {
        event.preventDefault();
        var ide = $(this).attr('tab');
        $('.rtg').addClass('inactive').removeClass('active');
        $(this).addClass('active').removeClass('inactive');
        $('.lrt').removeClass('active');
        $('#' + ide).addClass('active');
    });

    
    $('body').click(function(evt){    
        if(evt.target.id == "res-sj")
          return;
        if(evt.target.id  == 'res-sj_h')
            return;
       //For descendants of menu_content being clicked, remove this check if you do not want to put constraint on descendants.
       if($(evt.target).closest('#res-sj').length)
          return;   
        if($(evt.target).closest('#res-sj_h').length)
          return;  
        $('#res-sj').empty().removeClass('on').hide();         
        $('#res-sj_h').empty().removeClass('on').hide();         
      //Do processing of click event here for every element except with id menu_content
    });
    /* TAB VIDEOS */
    $('.aa-tbs-video a').on('click', function(event) {
        event.preventDefault();
        $('.video-player iframe').removeAttr('src');
        var ide = $(this).attr('href');
        var datas = $(ide).find('iframe').data('src');
        $(ide).find('iframe').attr('src', datas);
    });
    /*ADD TO FAVORITE*/
    $('body').on('click', '#add-to-favorito', function(event) {
        event.preventDefault();
        var $this = $(this);
        var post_id = $(this).data('id'),
            status  = $(this).attr('data-status');
        $('#mdl-favorites .anm-b').empty();
        $.ajax({
            url         : torofilm_Public.url,
            method      : 'POST',
            data        : {
                action      : 'action_add_favorito',
                post_id     : post_id,
                status      : status
            }, 
            success: function( data ) {
                console.log(data);
                if(status == 'favorito') {
                    $this.find('i').addClass('far');
                    $this.attr('data-status', 'nofavorito');
                    $('#mdl-favorites .anm-b').append('<p class="msg-w"><i class="fa-exclamation-circle"></i>'+torofilm_Public.remove_favorite+'</p>');
                } else if(status == 'nofavorito') {
                    $this.find('i').removeClass('far');
                    $this.attr('data-status', 'favorito');
                    $('#mdl-favorites .anm-b').append('<p class="msg-s"><i class="fa-check-circle"></i>'+torofilm_Public.add_favorite+'</p>');
                }
                setTimeout(()=>{
                    $('.msg-s').remove();
                    $('.msg-w').remove();
                    $('body').removeClass('mdl-on');
                    $('#mdl-favorites').removeClass('on');
                }, 1000);
            }
        });
    });
    $('body').on('click', '#add-to-favorito-s', function(event) {
        event.preventDefault();
        var $this = $(this);
        var post_id = $(this).data('id'),
            status  = $(this).attr('data-status');
        $('#mdl-favorites .anm-b').empty();
        $.ajax({
            url         : torofilm_Public.url,
            method      : 'POST',
            data        : {
                action      : 'action_add_favorito_s',
                post_id     : post_id,
                status      : status
            }, 
            success: function( data ) {
                console.log(data);
                if(status == 'favorito') {
                    $this.find('i').addClass('far');
                    $this.attr('data-status', 'nofavorito');
                    $('#mdl-favorites .anm-b').append('<p class="msg-w"><i class="fa-exclamation-circle"></i>'+torofilm_Public.remove_favorite+'</p>');
                } else if(status == 'nofavorito') {
                    $this.find('i').removeClass('far');
                    $this.attr('data-status', 'favorito');
                    $('#mdl-favorites .anm-b').append('<p class="msg-s"><i class="fa-check-circle"></i>'+torofilm_Public.add_favorite+'</p>');
                }
                setTimeout(()=>{
                    $('.msg-s').remove();
                    $('.msg-w').remove();
                    $('body').removeClass('mdl-on');
                    $('#mdl-favorites').removeClass('on');
                }, 1000);
            }
        });
    });
    /* TABS AJAX */
    $('.ax-tbs a').on('click', function(e) {
        var $this = $(this),
            limit = $(this).data('limit'),
            post  = $(this).data('post'),
            cate  = $(this).data('category'),
            mode  = $(this).data('mode'),
            ide   = $(this).attr('href');
        if($(ide).find('ul').length != 0 ) {
            return;
        }
        $.ajax({
            url     : torofilm_Public.url,
            method     : 'POST',
            data     : {
                action: 'action_tr_movie_category',
                limit : limit,
                post  : post,
                cate  : cate,
                mode  : mode 
            }, 
            beforeSend: function(){
                if($(ide).find('ul').length == 0 || $(ide).find('p').length==0) {
                    var html = '<div style="width:100%; display:flex; justify-content:center"><i id="sl-home" class="fas fa-spinner"></i></div>';
                    $(ide).append(html);
                }
            },
            success: function( data ) {
                $(ide).html(data);
            }
        });
    });
   /*Responsive*/
    //$('.user-bx').clone().prependTo('#menu').addClass('shw hddc');
    /*Dropdown*/
    $('.aa-drp').each(function() {
        var $AADrpdwn = $(this);
        $('.aa-lnk', $AADrpdwn).click(function(e){
          e.preventDefault();
          $AADrpdDv = $('.aa-cnt', $AADrpdwn);
          $AADrpdDv.parent('.aa-drp').toggleClass('on');
          $('.aa-cnt').not($AADrpdDv).parent('.aa-drp').removeClass('on');
          return false;
        });
    });
    $(document).on('click', function(e){
        if ($(e.target).closest('.aa-cnt').length === 0) {
            $('.aa-cnt').parent('.aa-drp').removeClass('on');
        }
    });
    /*Toggle*/
    $('.aa-tgl').on('click', function(){
        var shwhdd = $(this).attr('data-tgl');
        $('#'+shwhdd).toggleClass('on');
        $(this).toggleClass('on');
    });
    /*Modal*/


    /* Trailer */
    $('.aa-mdl').on('click', function(){
        var shwhddb = $(this).attr('data-mdl');
        $('#'+shwhddb).toggleClass('on');
        $('body').toggleClass('mdl-on');
        $(this).toggleClass('on');

        if( $('#mdl-trailer').hasClass('on') ){
            $('.video-trailer').html(torofilm_Public.trailer);
        } else {
            $('.video-trailer').empty();
        }

    });


    $(document).keyup(function(e){
        if (e.keyCode === 27) {
            $('body').removeClass('mdl-on');
            $('.mdl').removeClass('on');
        }
    });
    /*Accordion*/
    $('.aa-crd').find('.aa-crd-lnk').click(function(){
        $(this).toggleClass('on');
        $('.aa-crd-lnk').not($(this)).removeClass('on');
    });
    /*Tabs*/
    $('.aa-tbs a').click(function(e){
        if($(this).parent().parent().hasClass('cat-t')) {
            return;
        }
      e.preventDefault();
        var $this = $(this),
            tabgroup = '#'+$this.parents('.aa-tbs').data('tbs'),
            others = $this.closest('li').siblings().children('a'),
            target = $this.attr('href');
        others.removeClass('on');
        $this.addClass('on');
        $(tabgroup).children().removeClass('on');
        $(target).addClass('on');
    });
    /*Slider*/
    $('.slider').owlCarousel({
        loop:false,
        margin:32,
        items:1
    });
    /*Carousel*/
    $('.carousel').owlCarousel({
        loop:false,
        margin:8,
        nav:false,
        dots:true,
        navText: ["<i class='fa-chevron-left'></i>","<i class='fa-chevron-right'></i>"],
        responsive:{
            0:{
                items:2
            },
            576:{
                items:3
            },
            768:{
                items:4
            },
            1200:{
                items:6,
                dots:false,
                nav:true
            },
            1600:{
                items:8,
                dots:false,
                nav:true
            }
        }
    });
    /*Input*/
    $('input, textarea').each(function() {
        $(this).on('focus', function() {
            $(this).parent().addClass('on');
        });
        $(this).on('blur', function() {
            if ($(this).val().length == 0) {
                $(this).parent().removeClass('on');
            }
        });
        if ($(this).val() != '') $(this).parent().addClass('on');
    });
    /*Buscador Sugerido*/
    $('#tr_live_search').on('keyup', function(event) {
        var $this = $(this);
        jQuery(this).attr('autocomplete','off');
        var searchTerm = $(this).val();
        if (searchTerm.length > 2){
            $.ajax({
                url     : torofilm_Public.url,
                type    : 'POST',
                data: {
                    action  : 'action_tr_search_suggest',
                    nonce   : torofilm_Public.nonce,
                    term    : searchTerm
                },
                beforeSend: function(){
                    $('#sl-home').removeClass('fa-search').addClass('fas').addClass('fa-spinner').addClass('fa-pulse');
                    $('#res-sj').empty();
                    $this.next().next().removeClass('on');
                },
                success:function(data){
                    $('#sl-home').addClass('fa-search').removeClass('fas').removeClass('fa-spinner').removeClass('fa-pulse');
                    console.log(data);
                    $this.next().next().fadeIn().html(data);
                    $this.next().next().addClass('on');
                },
                error: function(){
                    $('#sl-home').addClass('fa-search').removeClass('fas').removeClass('fa-spinner').removeClass('fa-pulse');
                    $this.next().next().removeClass('on');
                    $this.next().next().hide();
                }
            });
        } else {
            $('#res-sj').empty();
            $this.next().next().removeClass('on');
            $this.next().next().hide();
        }
    }).keyup();
    /*BUSCCDOR SUGERIDO MORE LOAD*/
    $('body').on('click', '#more-shm', function(event) {
        event.preventDefault();
        $('#form-shs').submit();
    });
    /*Buscador Sugerido*/
    $('#tr_live_search_h').on('keyup', function(event) {
        var $this = $(this);
        jQuery(this).attr('autocomplete','off');
        var searchTerm = $(this).val();
        if (searchTerm.length > 2){
            $.ajax({
                url     : torofilm_Public.url,
                type    : 'POST',
                data: {
                    action  : 'action_tr_search_suggest_h',
                    nonce   : torofilm_Public.nonce,
                    term    : searchTerm
                },
                beforeSend: function(){
                    $('#sl-home_h').removeClass('fa-search').addClass('fas').addClass('fa-spinner').addClass('fa-pulse');
                    $('#res-sj_h').empty();
                    $this.next().next().removeClass('on');
                },
                success:function(data){
                    $('#sl-home_h').addClass('fa-search').removeClass('fas').removeClass('fa-spinner').removeClass('fa-pulse');
                    console.log(data);
                    $this.next().next().fadeIn().html(data);
                    $this.next().next().addClass('on');
                },
                error: function(){
                    $('#sl-home_h').addClass('fa-search').removeClass('fas').removeClass('fa-spinner').removeClass('fa-pulse');
                    $this.next().next().removeClass('on');
                    $this.next().next().hide();
                }
            });
        } else {
            $('#res-sj_h').empty();
            $this.next().next().removeClass('on');
            $this.next().next().hide();
        }
    }).keyup();
    /*BUSCCDOR SUGERIDO MORE LOAD*/
    $('body').on('click', '#more-shm-h', function(event) {
        event.preventDefault();
        $('#search').submit();
    });
    /**
     * Formulario Login Header
     * @since 1.0.0
     */
    $('#form-login-user').on('submit', function(event) {
        event.preventDefault();
        var name = $('#form-login-name').val(),
            pass = $('#form-login-pass').val();
        $('.error-login').remove();
        $.ajax({
            url         : torofilm_Public.url,
            method      : 'POST',
            dataType    : 'json',
            data        : {
                action      : 'action_peli_login_header',
                name        : name,
                pass        : pass
            }, 
            success: function( data ) {
                console.log(data);
                if(data.error == 'false') {
                    location.reload();
                } else {
                    console.log('error en login');
                    $('#form-login-user .mdl-bd').append('<p class="error-login">Access error</p>');
                }
            },
            error: function(data){
               //Ocurrió un error
               console.log('error 500');
                $('#form-login-user .mdl-bd').append('<p class="error-login">'+ torofilm_Public.access_error +'</p>');
            },
        });
    });
    /**
     * Formulario Register Header
     * @since 1.0.0
     */
    $('#form-register-user').on('submit', function(event) {
        event.preventDefault();
        var name = $('#form-register-names').val(),
            pass = $('#form-register-passs').val(),
            email = $('#form-register-emails').val();
        $.ajax({
            url         : torofilm_Public.url,
            method      : 'POST',
            dataType    : 'json',
            data        : {
                action      : 'action_peli_register_header',
                name        : name,
                pass        : pass,
                email       : email
            }, 
            success: function( data ) {
                if(data.error == 'false') {
                    setTimeout(function(){ 
                        $.ajax({
                            url     : torofilm_Public.url,
                            method     : 'POST',
                            dataType    : 'json',
                            data     : {
                                action      : 'action_peli_login_header',
                                name        : name,
                                pass        : pass
                            }, 
                            success: function( data ) {
                                if(data.error == 'false') {
                                    location.reload();
                                } else {
                                    console.log('error en login');
                                }
                            }
                        });
                    }, 500);
                } else {
                    console.log('error en login');
                }
            },
            error: function(data){
               console.log('error 500');
            },
        });
    });
    if($("#edit-user-perfil-pais").length > 0) {
        $("#edit-user-perfil-pais").countrySelect({
            // onlyCountries: ['us', 'gb', 'ch', 'ca', 'do'],
            // responsiveDropdown: true,
            preferredCountries: ['pe', 'mx', 'ar', 'co', 'cl', 'ec', 'es', 'bo', 'uy', 'py'],
        });
    }
    /*EDITOR DE PERIL DE USER*/
    $('#editor-user-perfil').on('submit', function(e) {
        e.preventDefault();
        var formData = new FormData($('#editor-user-perfil')[0]);
        $.ajax
        ({
            type       : 'POST',
            url        : templateUrl + '/helpers/edit-author.php',
            dataType   : 'json',
            data       : formData,
            cache      : false,
            contentType: false,
            processData: false
        })
        .done(function(data){
            var html = '';
            if(data.mensaje == 'error_image'){
                html += '<p id="msg-alert-confirmation" style="margin-top: 10px;" class="msg-w"><i class="fa-check-circle"></i>'+torofilm_Public.warning+'</p>';
            } else {
                html += '<p id="msg-alert-confirmation" style="margin-top: 10px;" class="msg-s"><i class="fa-check-circle"></i>'+torofilm_Public.saved+'</p>';
            }
            $('#editor-user-perfil').append(html);
            setTimeout(function(){ 
                $('#msg-alert-confirmation').fadeOut(500);
            }, 2000);
            setTimeout(function(){ 
                $('#msg-alert-confirmation').remove();
            }, 2600);
        })
        .fail(function(data){
             var html = '';
            html += '<p id="msg-alert-confirmation" style="margin-top: 10px;" class="msg-w"><i class="fa-check-circle"></i>'+torofilm_Public.error_upload+'</p>';
            $('#editor-user-perfil').append(html);
            setTimeout(function(){ 
                $('#msg-alert-confirmation').fadeOut(500);
            }, 2000);
            setTimeout(function(){ 
                $('#msg-alert-confirmation').remove();
            }, 2600);
        })
    });
    $('#editor-user-pass').on('submit', function(event) {
        event.preventDefault();
        var pass        = $('#editor-user-pass-password').val(),
            passRepeat  = $('#editor-user-pass-repeat').val();
        if( pass == '' && passRepeat == '') {
            return;
        }
        if( pass !== passRepeat ) {
            var html = '';
            html += '<p id="error-tpt" style="margin-top: 10px;" class="msg-d"><i class="fa-exclamation-triangle"></i> Las contraseñas no coinciden</p>';
            $('#editor-user-pass').append(html);
            setTimeout(function(){ 
                $('#error-tpt').fadeOut(500);
            }, 2000);
            setTimeout(function(){ 
                $('#error-tpt').remove();
            }, 2600);
            return;
        }
        $.ajax({
            url     : torofilm_Public.url,
            method     : 'POST',
            data     : {
                action    : 'action_editor_user_perfil',
                pass      : pass,
                passRepeat: passRepeat
            }, 
            success: function( data ) {
                var html = '';
                html += '<p id="msg-alert-confirmation" style="margin-top: 10px;" class="msg-s"><i class="fa-exclamation-circle"></i>Datos guardados correctamente</p>';
                $('#editor-user-pass').append(html);
                setTimeout(function(){ 
                    $('#msg-alert-confirmation').fadeOut(500);
                }, 2000);
                setTimeout(function(){ 
                    $('#msg-alert-confirmation').remove();
                }, 2600);
            }
        });
    });
    $('.sel-temp a').on('click', function(event) {
        event.preventDefault();
        var $this = $(this);
        var text_season = $(this).attr('data-season');
        var post = $(this).attr('data-post');
        $('.n_s').text(text_season);
        $('#episode_by_temp').empty();
        $this.parent().parent().parent().removeClass('on');
        $.ajax({
            url     : torofilm_Public.url,
            method     : 'POST',
            data     : {
                action    : 'action_select_season',
                season    : text_season,
                post      : post
            }, 
            beforeSend: function(){
                var html = '<li style="flex:100%; max-width: 100%;"><div style="width:100%; display:flex; justify-content:center"><i id="sl-home" class="fas fa-spinner"></i></div></li>';
                $('#episode_by_temp').append(html);
            },
            success: function( data ) {
                $('#episode_by_temp').html(data);
            }
        });
    });
    $('.loadactor').loadMoreResults({
        displayedItems: 10,
        showItems: 10,
        button: {
          'text': 'View more',
          'class': 'abt'
        },
        tag: {
            'name': 'tt',
            'class': 'tt-at'
        }
    });
    /*changue link modal register login*/
    $('#to-register').on('click', function(event) {
        event.preventDefault();
        $('.mdl').removeClass('on');
        $('#mdl-signup').addClass('on');
    });
    $('#to-login').on('click', function(event) {
        event.preventDefault();
        $('.mdl').removeClass('on');
        $('#mdl-login').addClass('on');
    });
    $('#playback').on('click', function(event) {
        event.preventDefault();
        if (this.dataset.href !== undefined) {
            if (this.dataset.target !== undefined) {
                window.open(this.dataset.href, 'blank');
            } else {
                window.location = this.dataset.href;
            }
        }
        var count = 0;
        var interval = setInterval(function() {
            count++;
            if (count == 5) {
                $('#playback-time').html('Loading...');
                var $tgt = $(event.target.parentNode);
                $tgt.show().delay(0).fadeOut();
                clearInterval(interval);
            } else {
                $('#playback-time').html(5 - count + ' Loading player...');
            }
        }, 1000);
    });
    
    // Modal System
    initModalSystem();
});

function initModalSystem() {
    const modal = document.getElementById('contentModal');
    const modalTitle = document.getElementById('modalTitle');
    const modalBody = document.getElementById('modalBody');
    const modalViewBtn = document.getElementById('modalViewBtn');
    const closeBtn = document.getElementById('modalClose');
    const closeBtn2 = document.getElementById('modalCloseBtn');
    
    if (!modal) return;
    
    // Modal açma butonları
    document.addEventListener('click', function(e) {
        if (e.target.closest('.content-modal-btn')) {
            e.preventDefault();
            e.stopPropagation();
            const btn = e.target.closest('.content-modal-btn');
            const contentId = btn.getAttribute('data-content-id');
            openContentModal(contentId);
        }
    });
    
    // Modal kapatma
    function closeModal() {
        modal.classList.remove('active');
        document.body.style.overflow = '';
    }
    
    closeBtn.addEventListener('click', closeModal);
    closeBtn2.addEventListener('click', closeModal);
    
    // Modal overlay'e tıklayınca kapat
    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            closeModal();
        }
    });
    
    // ESC tuşu ile kapat
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && modal.classList.contains('active')) {
            closeModal();
        }
    });
    
    // İçerik modalını aç
    function openContentModal(contentId) {
        // Basit modal içeriği (AJAX olmadan)
        const contentCard = document.querySelector(`[data-content-id="${contentId}"]`);
        if (!contentCard) return;
        
        const title = contentCard.querySelector('h3').textContent;
        const year = contentCard.querySelector('.year') ? contentCard.querySelector('.year').textContent : '';
        const type = contentCard.querySelector('.type').textContent;
        const poster = contentCard.querySelector('img');
        const permalink = contentCard.querySelector('.lnk-blk').href;
        
        modalTitle.textContent = title;
        modalViewBtn.href = permalink;
        
        // Modal içeriği oluştur
        let modalHtml = `
            <div class="content-details">
                <div class="content-poster-large">
                    ${poster ? `<img src="${poster.src}" alt="${title}">` : `<div class="no-poster"><i class="fa fa-film"></i></div>`}
                </div>
                <div class="content-info-large">
                    <h1>${title}</h1>
                    <div class="content-meta-large">
                        ${year ? `<div class="meta-item"><i class="fa fa-calendar"></i> ${year}</div>` : ''}
                        <div class="meta-item"><i class="fa fa-${type === 'Film' ? 'film' : 'tv'}"></i> ${type}</div>
                    </div>
                    <div class="content-description">
                        Bu ${type.toLowerCase()} hakkında daha fazla bilgi için detay sayfasını ziyaret edin.
                    </div>
                    <div class="platforms-available">
                        <h3>Mevcut Platformlar</h3>
                        <div class="platforms-list" id="modalPlatforms">
                            <!-- Platformlar buraya yüklenecek -->
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        modalBody.innerHTML = modalHtml;
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
        
        // Platform bilgilerini yükle
        loadContentPlatforms(contentId);
    }
    
    // İçerik platformlarını yükle
    function loadContentPlatforms(contentId) {
        // Basit platform listesi (gerçek uygulamada AJAX ile veritabanından alınır)
        const platforms = [
            { id: 'netflix', name: 'Netflix', color: '#E50914', icon: 'fa-play', logo: '' },
            { id: 'prime', name: 'Prime Video', color: '#00A8E1', icon: 'fa-play', logo: '' },
            { id: 'hbo', name: 'HBO Max', color: '#8B5CF6', icon: 'fa-play', logo: '' },
            { id: 'disney', name: 'Disney+', color: '#113CCF', icon: 'fa-play', logo: '' }
        ];
        
        const platformsContainer = document.getElementById('modalPlatforms');
        if (!platformsContainer) return;
        
        // Rastgele 2-3 platform seç
        const shuffled = platforms.sort(() => 0.5 - Math.random());
        const selectedPlatforms = shuffled.slice(0, Math.floor(Math.random() * 2) + 2);
        
        let platformsHtml = '';
        selectedPlatforms.forEach(platform => {
            platformsHtml += `
                <a href="#" class="platform-badge">
                    ${platform.logo ? 
                        `<img src="${platform.logo}" alt="${platform.name}" style="width: 20px; height: 20px; object-fit: contain; margin-right: 8px;">` : 
                        `<i class="fa ${platform.icon}" style="color: ${platform.color};"></i>`
                    }
                    ${platform.name}
                </a>
            `;
        });
        
        platformsContainer.innerHTML = platformsHtml;
    }
}
/*!
 * headroom.js v0.5.0 - Give your page some headroom. Hide your header until you need it
 * Copyright (c) 2014 Nick Williams - http://wicky.nillia.ms/headroom.js
 * License: MIT
 */
!function(a,b){"use strict";function c(a){this.callback=a,this.ticking=!1}function d(a){if(arguments.length<=0)throw new Error("Missing arguments in extend function");var b,c,e=a||{};for(c=1;c<arguments.length;c++){var f=arguments[c]||{};for(b in f)e[b]="object"==typeof e[b]?d(e[b],f[b]):e[b]||f[b]}return e}function e(a,b){b=d(b,e.options),this.lastKnownScrollY=0,this.elem=a,this.debouncer=new c(this.update.bind(this)),this.tolerance=b.tolerance,this.classes=b.classes,this.offset=b.offset,this.initialised=!1,this.onPin=b.onPin,this.onUnpin=b.onUnpin,this.onTop=b.onTop,this.onNotTop=b.onNotTop}var f={bind:!!function(){}.bind,classList:"classList"in b.documentElement,rAF:!!(a.requestAnimationFrame||a.webkitRequestAnimationFrame||a.mozRequestAnimationFrame)};a.requestAnimationFrame=a.requestAnimationFrame||a.webkitRequestAnimationFrame||a.mozRequestAnimationFrame,c.prototype={constructor:c,update:function(){this.callback&&this.callback(),this.ticking=!1},requestTick:function(){this.ticking||(requestAnimationFrame(this.rafCallback||(this.rafCallback=this.update.bind(this))),this.ticking=!0)},handleEvent:function(){this.requestTick()}},e.prototype={constructor:e,init:function(){return e.cutsTheMustard?(this.elem.classList.add(this.classes.initial),setTimeout(this.attachEvent.bind(this),100),this):void 0},destroy:function(){var b=this.classes;this.initialised=!1,a.removeEventListener("scroll",this.debouncer,!1),this.elem.classList.remove(b.unpinned,b.pinned,b.top,b.initial)},attachEvent:function(){this.initialised||(this.lastKnownScrollY=this.getScrollY(),this.initialised=!0,a.addEventListener("scroll",this.debouncer,!1),this.debouncer.handleEvent())},unpin:function(){var a=this.elem.classList,b=this.classes;(a.contains(b.pinned)||!a.contains(b.unpinned))&&(a.add(b.unpinned),a.remove(b.pinned),this.onUnpin&&this.onUnpin.call(this))},pin:function(){var a=this.elem.classList,b=this.classes;a.contains(b.unpinned)&&(a.remove(b.unpinned),a.add(b.pinned),this.onPin&&this.onPin.call(this))},top:function(){var a=this.elem.classList,b=this.classes;a.contains(b.top)||(a.add(b.top),a.remove(b.notTop),this.onTop&&this.onTop.call(this))},notTop:function(){var a=this.elem.classList,b=this.classes;a.contains(b.notTop)||(a.add(b.notTop),a.remove(b.top),this.onNotTop&&this.onNotTop.call(this))},getScrollY:function(){return void 0!==a.pageYOffset?a.pageYOffset:(b.documentElement||b.body.parentNode||b.body).scrollTop},getViewportHeight:function(){return a.innerHeight||b.documentElement.clientHeight||b.body.clientHeight},getDocumentHeight:function(){var a=b.body,c=b.documentElement;return Math.max(a.scrollHeight,c.scrollHeight,a.offsetHeight,c.offsetHeight,a.clientHeight,c.clientHeight)},isOutOfBounds:function(a){var b=0>a,c=a+this.getViewportHeight()>this.getDocumentHeight();return b||c},toleranceExceeded:function(a){return Math.abs(a-this.lastKnownScrollY)>=this.tolerance},shouldUnpin:function(a,b){var c=a>this.lastKnownScrollY,d=a>=this.offset;return c&&d&&b},shouldPin:function(a,b){var c=a<this.lastKnownScrollY,d=a<=this.offset;return c&&b||d},update:function(){var a=this.getScrollY(),b=this.toleranceExceeded(a);this.isOutOfBounds(a)||(a<=this.offset?this.top():this.notTop(),this.shouldUnpin(a,b)?this.unpin():this.shouldPin(a,b)&&this.pin(),this.lastKnownScrollY=a)}},e.options={tolerance:0,offset:0,classes:{pinned:"headroom--pinned",unpinned:"headroom--unpinned",top:"headroom--top",notTop:"headroom--not-top",initial:"headroom"}},e.cutsTheMustard="undefined"!=typeof f&&f.rAF&&f.bind&&f.classList,a.Headroom=e}(window,document);
(function() {
    new Headroom(document.querySelector(".hd"), {
        tolerance: 10,
        offset : 205,
        classes: {
          initial: "pfx",
          pinned: "pfxa",
          unpinned: "pfxb"
        }
    }).init();
}());

/**
 * Ana Sayfa Animasyonları ve İnteraktif Özellikler
 */
function initHomeAnimations() {
    // Scroll animasyonları
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
            }
        });
    }, observerOptions);

    // Animasyon yapılacak elementleri gözlemle
    const animateElements = document.querySelectorAll('.section, .trending-movie-card, .trending-series-card, .category-card');
    animateElements.forEach(el => {
        observer.observe(el);
    });

    // Trend kartları için hover efektleri
    const trendingCards = document.querySelectorAll('.trending-movie-card, .trending-series-card');
    trendingCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-10px) scale(1.02)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
        });
    });

    // Kategori kartları için ripple efekti
    const categoryCards = document.querySelectorAll('.category-card');
    categoryCards.forEach(card => {
        card.addEventListener('click', function(e) {
            const ripple = document.createElement('span');
            const rect = this.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height);
            const x = e.clientX - rect.left - size / 2;
            const y = e.clientY - rect.top - size / 2;
            
            ripple.style.width = ripple.style.height = size + 'px';
            ripple.style.left = x + 'px';
            ripple.style.top = y + 'px';
            ripple.classList.add('ripple');
            
            this.appendChild(ripple);
            
            setTimeout(() => {
                ripple.remove();
            }, 600);
        });
    });

    // Parallax efekti için hero section
    const heroSection = document.querySelector('.hero-section');
    if (heroSection) {
        window.addEventListener('scroll', () => {
            const scrolled = window.pageYOffset;
            const rate = scrolled * -0.5;
            heroSection.style.transform = `translateY(${rate}px)`;
        });
    }

    // Smooth scroll için linkler
    const smoothLinks = document.querySelectorAll('a[href^="#"]');
    smoothLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// CSS animasyonları için stil ekle
function addAnimationStyles() {
    const style = document.createElement('style');
    style.textContent = `
        .section, .trending-movie-card, .trending-series-card, .category-card {
            opacity: 0;
            transform: translateY(30px);
            transition: all 0.6s ease;
        }
        
        .animate-in {
            opacity: 1 !important;
            transform: translateY(0) !important;
        }
        
        .ripple {
            position: absolute;
            border-radius: 50%;
            background: rgba(3, 193, 239, 0.3);
            transform: scale(0);
            animation: ripple-animation 0.6s linear;
            pointer-events: none;
        }
        
        @keyframes ripple-animation {
            to {
                transform: scale(4);
                opacity: 0;
            }
        }
        
        .trending-movie-card, .trending-series-card {
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .category-card {
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
    `;
    document.head.appendChild(style);
}

/**
 * Dizi Takip Sistemi
 */
function initSeriesTracking() {
    // Takip et/etme butonu
    document.addEventListener('click', function(e) {
        if (e.target.closest('.track-toggle-btn')) {
            e.preventDefault();
            const btn = e.target.closest('.track-toggle-btn');
            const seriesId = btn.getAttribute('data-series-id');
            const isTracked = btn.classList.contains('tracked');
            
            toggleSeriesTracking(seriesId, !isTracked, btn);
        }
    });
    
    // Sezon değiştirme
    document.addEventListener('change', function(e) {
        if (e.target.classList.contains('season-select')) {
            const select = e.target;
            const seriesId = select.getAttribute('data-series-id');
            const season = select.value;
            
            updateSeriesProgress(seriesId, 'season', season);
        }
    });
    
    // Bölüm değiştirme
    document.addEventListener('change', function(e) {
        if (e.target.classList.contains('episode-select')) {
            const select = e.target;
            const seriesId = select.getAttribute('data-series-id');
            const episode = select.value;
            
            updateSeriesProgress(seriesId, 'episode', episode);
        }
    });
    
    // İzledim olarak işaretle
    document.addEventListener('click', function(e) {
        if (e.target.closest('.mark-watched-btn')) {
            e.preventDefault();
            const btn = e.target.closest('.mark-watched-btn');
            const seriesId = btn.getAttribute('data-series-id');
            
            markAsWatched(seriesId);
        }
    });
    
    // Sıfırla
    document.addEventListener('click', function(e) {
        if (e.target.closest('.reset-progress-btn')) {
            e.preventDefault();
            const btn = e.target.closest('.reset-progress-btn');
            const seriesId = btn.getAttribute('data-series-id');
            
            resetProgress(seriesId);
        }
    });
}

function toggleSeriesTracking(seriesId, track, btn) {
    const formData = new FormData();
    formData.append('action', 'toggle_series_tracking');
    formData.append('series_id', seriesId);
    formData.append('track', track ? '1' : '0');
    formData.append('nonce', ajax_object.nonce);
    
    fetch(ajax_object.ajax_url, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            if (track) {
                btn.classList.add('tracked');
                btn.innerHTML = '<i class="fa fa-check"></i> Takip Ediliyor';
                showTrackingWidget(seriesId);
            } else {
                btn.classList.remove('tracked');
                btn.innerHTML = '<i class="fa fa-plus"></i> Takip Et';
                hideTrackingWidget(seriesId);
            }
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

function updateSeriesProgress(seriesId, type, value) {
    const formData = new FormData();
    formData.append('action', 'update_series_progress');
    formData.append('series_id', seriesId);
    formData.append('type', type);
    formData.append('value', value);
    formData.append('nonce', ajax_object.nonce);
    
    fetch(ajax_object.ajax_url, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            updateProgressBar(seriesId);
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

function markAsWatched(seriesId) {
    const formData = new FormData();
    formData.append('action', 'mark_series_watched');
    formData.append('series_id', seriesId);
    formData.append('nonce', ajax_object.nonce);
    
    fetch(ajax_object.ajax_url, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

function resetProgress(seriesId) {
    if (confirm('İlerlemenizi sıfırlamak istediğinizden emin misiniz?')) {
        const formData = new FormData();
        formData.append('action', 'reset_series_progress');
        formData.append('series_id', seriesId);
        formData.append('nonce', ajax_object.nonce);
        
        fetch(ajax_object.ajax_url, {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
    }
}

function showTrackingWidget(seriesId) {
    // Tracking widget'ını göster
    const widget = document.querySelector('.series-tracking-widget');
    if (widget) {
        const progress = widget.querySelector('.tracking-progress');
        if (progress) {
            progress.style.display = 'block';
        }
    }
}

function hideTrackingWidget(seriesId) {
    // Tracking widget'ını gizle
    const widget = document.querySelector('.series-tracking-widget');
    if (widget) {
        const progress = widget.querySelector('.tracking-progress');
        if (progress) {
            progress.style.display = 'none';
        }
    }
}

function updateProgressBar(seriesId) {
    // Progress bar'ı güncelle
    const progressFill = document.querySelector('.progress-fill');
    if (progressFill) {
        const seasonSelect = document.querySelector('.season-select');
        const totalSeasons = seasonSelect.options.length - 1;
        const currentSeason = parseInt(seasonSelect.value);
        
        const percentage = totalSeasons > 0 ? (currentSeason / totalSeasons) * 100 : 0;
        progressFill.style.width = percentage + '%';
    }
}

// Sayfa yüklendiğinde başlat
document.addEventListener('DOMContentLoaded', function() {
    addAnimationStyles();
    initHomeAnimations();
    
    // Slider'ı hemen başlat
    setTimeout(function() {
        initSliders();
    }, 100);
    
    initSeriesTracking();
});

// Window yüklendiğinde de dene
window.addEventListener('load', function() {
    setTimeout(function() {
        initSliders();
    }, 500);
});

// Resize olayında da dene
window.addEventListener('resize', function() {
    setTimeout(function() {
        initSliders();
    }, 200);
});