<form  class="search full" method="get" action="<?php echo get_home_url(); ?>">
	<input  type="text" name="s" placeholder="<?php echo lang_torofilm('Search', 'txt_search'); ?>">
	<button type="submit" class="btn npd lnk">
		<i id="sl_home_h" class="fa-search"></i>
	</button>
</form>