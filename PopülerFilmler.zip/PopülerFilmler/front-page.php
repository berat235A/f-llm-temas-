<?php get_header(); ?>
<div class="bd">
	<?php get_template_part( 'public/partials/template/home', 'search' ); ?>
	
	<!-- Hero Section -->
	<div class="hero-section">
		<div class="hero-content">
			<div class="hero-logo">
				<h1 class="hero-title">Dizipal</h1>
				<p class="hero-subtitle">En güncel ve popüler dizi ve filmleri takip edebileceğiniz platform</p>
			</div>
			<div class="hero-stats">
				<div class="stat-item">
					<span class="stat-number"><?php echo wp_count_posts('series')->publish; ?></span>
					<span class="stat-label">Dizi</span>
				</div>
				<div class="stat-item">
					<span class="stat-number"><?php echo wp_count_posts('movies')->publish; ?></span>
					<span class="stat-label">Film</span>
				</div>
				<div class="stat-item">
					<span class="stat-number"><?php echo wp_count_posts()->publish; ?></span>
					<span class="stat-label">Toplam İçerik</span>
				</div>
			</div>
		</div>
		<div class="hero-background">
			<div class="hero-overlay"></div>
		</div>
	</div>

	<div class="dfxc">
		<main class="main-site">
			<!-- Platformlar Section -->
			<section class="section platforms-section">
				<header class="section-header">
					<h2 class="section-title">
						<i class="fa fa-tv"></i>
						Platformlar
					</h2>
				</header>
				<div class="platforms-grid">
					<?php
					$platforms = get_option('torofilm_platforms', array());
					
					// Eğer admin panelden platform eklenmemişse varsayılan platformları göster
					if (empty($platforms)) {
						$default_platforms = array(
							'netflix' => array('name' => 'Netflix', 'color' => '#E50914', 'icon' => 'fa-play'),
							'prime' => array('name' => 'Prime', 'color' => '#00A8E1', 'icon' => 'fa-play'),
							'hbo' => array('name' => 'HBO Max', 'color' => '#8B5CF6', 'icon' => 'fa-play'),
							'disney' => array('name' => 'Disney+', 'color' => '#113CCF', 'icon' => 'fa-play'),
							'apple' => array('name' => 'Apple TV+', 'color' => '#000000', 'icon' => 'fa-play'),
							'exxen' => array('name' => 'Exxen', 'color' => '#FF6B35', 'icon' => 'fa-play'),
							'tabii' => array('name' => 'Tabii', 'color' => '#00D4AA', 'icon' => 'fa-play'),
							'gain' => array('name' => 'Gain', 'color' => '#FFD700', 'icon' => 'fa-play')
						);
						$platforms = $default_platforms;
					}
					
					foreach ($platforms as $platform_id => $platform) {
						$platform_name = $platform['name'];
						$platform_color = $platform['color'];
						$platform_icon = $platform['icon'];
						$platform_logo = isset($platform['logo']) ? $platform['logo'] : '';
						$platform_url = isset($platform['url']) ? $platform['url'] : '';
						?>
						<div class="platform-card" data-platform="<?php echo esc_attr($platform_id); ?>">
							<div class="platform-icon" style="background: <?php echo esc_attr($platform_color); ?>">
								<?php if ($platform_logo): ?>
									<img src="<?php echo esc_url($platform_logo); ?>" alt="<?php echo esc_attr($platform_name); ?>" class="platform-logo">
								<?php else: ?>
									<i class="fa <?php echo esc_attr($platform_icon); ?>"></i>
								<?php endif; ?>
							</div>
							<span class="platform-name"><?php echo esc_html($platform_name); ?></span>
							<a href="<?php echo home_url('/platform/' . $platform_id . '/'); ?>" class="platform-link"></a>
						</div>
					<?php } ?>
				</div>
			</section>

			<!-- Popüler Filmler Section - Güncellenmiş -->
			<section class="section popular-movies-section">
				<header class="section-header">
					<div class="rw alg-cr jst-sb">
						<h2 class="section-title">
							<i class="fa fa-fire"></i>
							Popüler Filmler
						</h2>
						<a href="<?php echo get_post_type_archive_link('movies'); ?>" class="btn lnk more">
							<span>Tümünü Gör</span> 
							<i class="fa fa-arrow-right"></i>
						</a>
					</div>
				</header>
				<div class="slideshow-container movies-slider-container">
					<div class="swiper movies-swiper" id="moviesSwiper">
						<div class="swiper-wrapper">
							<?php
							$args = array(
								'post_type' => 'movies',
								'posts_per_page' => 25, // Daha fazla film göster
								'orderby' => 'meta_value_num',
								'meta_key' => 'views',
								'order' => 'DESC',
								'meta_query' => array(
									array(
										'key' => 'views',
										'value' => 0,
										'compare' => '>'
									)
								)
							);
							$movies_query = new WP_Query($args);
							if ($movies_query->have_posts()) :
								while ($movies_query->have_posts()) : $movies_query->the_post();
									echo '<div class="swiper-slide">';
									get_template_part('public/partials/template/movies', 'slider');
									echo '</div>';
								endwhile;
							endif;
							wp_reset_query(); ?>
						</div>
						<!-- Navigation buttons -->
						<div class="swiper-button-next" aria-label="Sonraki filmler"></div>
						<div class="swiper-button-prev" aria-label="Önceki filmler"></div>
						<!-- Pagination -->
						<div class="swiper-pagination" aria-label="Film sayfası göstergesi"></div>
					</div>
				</div>
			</section>

			<!-- Yeni Eklenen Filmler Section -->
			<section class="section new-movies-section">
				<header class="section-header">
					<div class="rw alg-cr jst-sb">
						<h2 class="section-title">
							<i class="fa fa-plus-circle"></i>
							Yeni Eklenen Filmler
						</h2>
						<a href="<?php echo get_post_type_archive_link('movies'); ?>" class="btn lnk more">Tümünü Gör <i class="fa fa-arrow-right"></i></a>
					</div>
				</header>
				<div class="movies-grid">
					<?php
					$new_movies_args = array(
						'post_type' => 'movies',
						'posts_per_page' => 12,
						'orderby' => 'date',
						'order' => 'DESC'
					);
					$new_movies_query = new WP_Query($new_movies_args);
					if ($new_movies_query->have_posts()) :
						while ($new_movies_query->have_posts()) : $new_movies_query->the_post();
							$poster_hotlink = get_post_meta(get_the_ID(), 'poster_hotlink', true);
							$poster_field = get_post_meta(get_the_ID(), 'field_poster', true);
							$year = get_post_meta(get_the_ID(), 'field_release_year', true);
							$rating = get_post_meta(get_the_ID(), 'rating', true);
							
							// Poster URL'sini belirle
							$poster_url = '';
							if ($poster_field) {
								$poster_url = wp_get_attachment_image_src($poster_field, 'medium')[0];
							} elseif ($poster_hotlink) {
								if (filter_var($poster_hotlink, FILTER_VALIDATE_URL) === FALSE) {
									$poster_url = '//image.tmdb.org/t/p/w342' . $poster_hotlink;
								} else {
									$poster_url = $poster_hotlink;
								}
							}
							?>
							<div class="movie-card">
								<div class="movie-poster">
									<?php if ($poster_url): ?>
										<img src="<?php echo esc_url($poster_url); ?>" alt="<?php the_title(); ?>" loading="lazy">
									<?php else: ?>
										<div class="no-poster">
											<i class="fa fa-film"></i>
										</div>
									<?php endif; ?>
									<div class="movie-overlay">
										<div class="movie-info">
											<h3><?php the_title(); ?></h3>
											<div class="movie-meta">
												<?php if ($year) echo '<span class="year">' . $year . '</span>'; ?>
												<?php if ($rating) echo '<span class="rating">★ ' . $rating . '</span>'; ?>
											</div>
										</div>
									</div>
								</div>
								<a href="<?php the_permalink(); ?>" class="lnk-blk"></a>
							</div>
						<?php 
						endwhile;
					endif;
					wp_reset_query(); ?>
				</div>
			</section>

			<!-- Diziler Slider Section -->
			<section class="section series-slider-section">
				<header class="section-header">
					<div class="rw alg-cr jst-sb">
						<h2 class="section-title">Son Eklenen Diziler</h2>
						<a href="<?php echo get_post_type_archive_link('series'); ?>" class="btn lnk more fa-plus">Tümünü Gör</a>
					</div>
				</header>
				<div class="series-slider-container">
					<div class="swiper series-swiper" id="seriesSwiper">
						<div class="swiper-wrapper">
							<?php
							$args = array(
								'post_type' => 'series',
								'posts_per_page' => 20,
								'orderby' => 'date',
								'order' => 'DESC'
							);
							$series_query = new WP_Query($args);
							if ($series_query->have_posts()) :
								while ($series_query->have_posts()) : $series_query->the_post();
									echo '<div class="swiper-slide">';
									get_template_part('public/partials/template/series', 'slider');
									echo '</div>';
								endwhile;
							endif;
							wp_reset_query(); ?>
						</div>
						<div class="swiper-button-next"></div>
						<div class="swiper-button-prev"></div>
						<div class="swiper-pagination"></div>
					</div>
				</div>
			</section>

			<!-- Son Bölümler Section - Template ile -->
			<section class="section episodes-section">
				<header class="section-header">
					<div class="rw alg-cr jst-sb">
						<h2 class="section-title">
							<i class="fa fa-play-circle"></i>
							Son Bölümler
						</h2>
						<a href="<?php echo home_url('/bolumler/'); ?>" class="btn lnk more">
							<span>Tümünü Gör</span> 
							<i class="fa fa-arrow-right"></i>
						</a>
					</div>
				</header>
				<div class="episodes-grid">
					<?php 
					$episodes = get_terms('episodes', array(
						'orderby' => 'id',
						'order' => 'DESC',
						'hide_empty' => 0,
						'number' => 8 // Daha az bölüm göster
					));
					
					if ($episodes && !is_wp_error($episodes)) {
						foreach ($episodes as $episode) {
							// Bölüm verilerini global değişkenlere ata
							global $episode_data;
							$episode_data = array(
								'episode' => $episode,
								'air_date' => get_term_meta($episode->term_id, 'air_date', true),
								'series_id' => get_term_meta($episode->term_id, 'serie_id', true),
								'season_number' => get_term_meta($episode->term_id, 'season_number', true),
								'episode_number' => get_term_meta($episode->term_id, 'episode_number', true)
							);
							
							// Template dosyasını dahil et
							get_template_part('public/partials/template/episodes', 'slider');
						}
					} else {
						echo '<div class="no-episodes">';
						echo '<p>Henüz bölüm bulunmuyor.</p>';
						echo '</div>';
					}
					?>
				</div>
			</section>

			<!-- Trend Filmler Section -->
			<section class="section trending-movies-section">
				<header class="section-header">
					<div class="rw alg-cr jst-sb">
						<h2 class="section-title">
							<i class="fa fa-fire trending-icon"></i>
							Trend Filmler
						</h2>
						<a href="<?php echo get_post_type_archive_link('movies'); ?>" class="btn lnk more">Tümü <i class="fa fa-chevron-right"></i></a>
					</div>
				</header>
				<div class="trending-movies-grid">
					<?php
					$trending_movies_args = array(
						'post_type' => 'movies',
						'posts_per_page' => 5,
						'meta_key' => 'views',
						'orderby' => 'meta_value_num',
						'order' => 'DESC',
						'meta_query' => array(
							array(
								'key' => 'views',
								'value' => 0,
								'compare' => '>',
								'type' => 'NUMERIC'
							)
						)
					);
					$trending_movies_query = new WP_Query($trending_movies_args);
					if ($trending_movies_query->have_posts()) :
						$counter = 1;
						while ($trending_movies_query->have_posts()) : $trending_movies_query->the_post(); 
							$poster_hotlink = get_post_meta(get_the_ID(), 'poster_hotlink', true);
							$poster_field = get_post_meta(get_the_ID(), 'field_poster', true);
							$year = get_post_meta(get_the_ID(), 'field_release_year', true);
							$rating = get_post_meta(get_the_ID(), 'rating', true);
							$views = get_post_meta(get_the_ID(), 'views', true);
							$views_count = $views ? number_format($views) : '0';
							
							// Poster URL'sini belirle
							$poster_url = '';
							if ($poster_field) {
								$poster_url = wp_get_attachment_image_src($poster_field, 'medium')[0];
							} elseif ($poster_hotlink) {
								if (filter_var($poster_hotlink, FILTER_VALIDATE_URL) === FALSE) {
									$poster_url = '//image.tmdb.org/t/p/w342' . $poster_hotlink;
								} else {
									$poster_url = $poster_hotlink;
								}
							}
							?>
							<div class="trending-movie-card" data-rank="<?php echo $counter; ?>">
								<div class="trending-poster">
									<?php if ($poster_url): ?>
										<img src="<?php echo esc_url($poster_url); ?>" alt="<?php the_title(); ?>" loading="lazy">
									<?php else: ?>
										<div class="no-poster">
											<i class="fa fa-film"></i>
											<span><?php the_title(); ?></span>
										</div>
									<?php endif; ?>
									<div class="trending-rank"><?php echo $counter; ?></div>
									<div class="trending-views">
										<i class="fa fa-eye"></i>
										<span><?php echo $views_count; ?></span>
									</div>
									<div class="trending-overlay">
										<div class="trending-info">
											<h3><?php the_title(); ?></h3>
											<div class="trending-meta">
												<?php if ($year) echo '<span class="year">' . $year . '</span>'; ?>
												<?php if ($rating) echo '<span class="rating">★ ' . $rating . '</span>'; ?>
												<span class="views-count">
													<i class="fa fa-eye"></i>
													<?php echo $views_count; ?> görüntülenme
												</span>
											</div>
										</div>
									</div>
								</div>
								<a href="<?php the_permalink(); ?>" class="lnk-blk"></a>
							</div>
						<?php 
						$counter++;
						endwhile;
					endif;
					wp_reset_query(); ?>
				</div>
			</section>
			
			<!-- En Son Eklenen İçerikler Section -->
			<section class="section latest-content-section">
				<header class="section-header">
					<div class="rw alg-cr jst-sb">
						<h2 class="section-title">
							<i class="fa fa-clock-o"></i>
							En Son Eklenen İçerikler
						</h2>
						<a href="<?php echo home_url('/'); ?>" class="btn lnk more">Tümünü Gör <i class="fa fa-arrow-right"></i></a>
					</div>
				</header>
				<div class="latest-content-grid">
					<?php
					$latest_args = array(
						'post_type' => array('movies', 'series'),
						'posts_per_page' => 12,
						'orderby' => 'date',
						'order' => 'DESC'
					);
					$latest_query = new WP_Query($latest_args);
					if ($latest_query->have_posts()) :
						while ($latest_query->have_posts()) : $latest_query->the_post();
							$poster_hotlink = get_post_meta(get_the_ID(), 'poster_hotlink', true);
							$poster_field = get_post_meta(get_the_ID(), 'field_poster', true);
							$year = get_post_meta(get_the_ID(), 'field_release_year', true);
							$rating = get_post_meta(get_the_ID(), 'rating', true);
							$post_type = get_post_type();
							
							// Poster URL'sini belirle
							$poster_url = '';
							if ($poster_field) {
								$poster_url = wp_get_attachment_image_src($poster_field, 'medium')[0];
							} elseif ($poster_hotlink) {
								if (filter_var($poster_hotlink, FILTER_VALIDATE_URL) === FALSE) {
									$poster_url = '//image.tmdb.org/t/p/w342' . $poster_hotlink;
								} else {
									$poster_url = $poster_hotlink;
								}
							}
							?>
							<div class="latest-content-card" data-content-id="<?php echo get_the_ID(); ?>" data-content-type="<?php echo $post_type; ?>">
								<div class="content-poster">
									<?php if ($poster_url): ?>
										<img src="<?php echo esc_url($poster_url); ?>" alt="<?php the_title(); ?>" loading="lazy">
									<?php else: ?>
										<div class="no-poster">
											<i class="fa fa-<?php echo $post_type == 'movies' ? 'film' : 'tv'; ?>"></i>
										</div>
									<?php endif; ?>
									<div class="content-badge">
										<span class="badge-new">Yeni</span>
										<?php if ($rating): ?>
											<span class="badge-rating"><?php echo $rating; ?></span>
										<?php endif; ?>
									</div>
								</div>
								<div class="content-info">
									<h3><?php the_title(); ?></h3>
									<div class="content-meta">
										<?php if ($year) echo '<span class="year">' . $year . '</span>'; ?>
										<span class="type"><?php echo $post_type == 'movies' ? 'Film' : 'Dizi'; ?></span>
									</div>
								</div>
								<button class="content-modal-btn" data-content-id="<?php echo get_the_ID(); ?>">
									<i class="fa fa-info-circle"></i>
								</button>
								<a href="<?php the_permalink(); ?>" class="lnk-blk"></a>
							</div>
						<?php 
						endwhile;
					endif;
					wp_reset_query(); ?>
				</div>
			</section>

			<!-- Kategoriler Section -->
			<section class="section categories-section">
				<header class="section-header">
					<div class="rw alg-cr jst-sb">
						<h2 class="section-title">
							<i class="fa fa-th-large"></i>
							Türler
						</h2>
					</div>
				</header>
				<div class="categories-grid">
					<?php
					$categories = get_categories(array(
						'orderby' => 'count',
						'order' => 'DESC',
						'number' => 12,
						'hide_empty' => true
					));
					
					$category_icons = array(
						'aksiyon' => 'fa-bolt',
						'komedi' => 'fa-smile-o',
						'drama' => 'fa-heart',
						'korku' => 'fa-moon-o',
						'bilim-kurgu' => 'fa-rocket',
						'romantik' => 'fa-heart-o',
						'gerilim' => 'fa-eye',
						'belgesel' => 'fa-camera',
						'fantastik' => 'fa-magic',
						'macera' => 'fa-compass',
						'suç' => 'fa-gavel',
						'gizem' => 'fa-search'
					);
					
					foreach ($categories as $category) {
						$icon = isset($category_icons[$category->slug]) ? $category_icons[$category->slug] : 'fa-film';
						?>
						<div class="category-card">
							<div class="category-icon">
								<i class="fa <?php echo $icon; ?>"></i>
							</div>
							<div class="category-info">
								<h3><?php echo $category->name; ?></h3>
								<p><?php echo $category->count; ?> içerik</p>
							</div>
							<a href="<?php echo get_category_link($category->term_id); ?>" class="lnk-blk"></a>
						</div>
					<?php } ?>
				</div>
			</section>

			<!-- Trend Diziler Section -->
			<section class="section trending-series-section">
				<header class="section-header">
					<div class="rw alg-cr jst-sb">
						<h2 class="section-title">
							<i class="fa fa-tv trending-icon"></i>
							Trend Diziler
						</h2>
						<a href="<?php echo get_post_type_archive_link('series'); ?>" class="btn lnk more">Tümü <i class="fa fa-chevron-right"></i></a>
					</div>
				</header>
				<div class="trending-series-grid">
					<?php
					$trending_series_args = array(
						'post_type' => 'series',
						'posts_per_page' => 5,
						'meta_key' => 'views',
						'orderby' => 'meta_value_num',
						'order' => 'DESC',
						'meta_query' => array(
							array(
								'key' => 'views',
								'value' => 0,
								'compare' => '>',
								'type' => 'NUMERIC'
							)
						)
					);
					$trending_series_query = new WP_Query($trending_series_args);
					if ($trending_series_query->have_posts()) :
						$counter = 1;
						while ($trending_series_query->have_posts()) : $trending_series_query->the_post(); 
							$poster_hotlink = get_post_meta(get_the_ID(), 'poster_hotlink', true);
							$poster_field = get_post_meta(get_the_ID(), 'field_poster', true);
							$year = get_post_meta(get_the_ID(), 'field_release_year', true);
							$rating = get_post_meta(get_the_ID(), 'rating', true);
							$views = get_post_meta(get_the_ID(), 'views', true);
							$views_count = $views ? number_format($views) : '0';
							
							// Poster URL'sini belirle
							$poster_url = '';
							if ($poster_field) {
								$poster_url = wp_get_attachment_image_src($poster_field, 'medium')[0];
							} elseif ($poster_hotlink) {
								if (filter_var($poster_hotlink, FILTER_VALIDATE_URL) === FALSE) {
									$poster_url = '//image.tmdb.org/t/p/w342' . $poster_hotlink;
								} else {
									$poster_url = $poster_hotlink;
								}
							}
							?>
							<div class="trending-series-card" data-rank="<?php echo $counter; ?>">
								<div class="trending-poster">
									<?php if ($poster_url): ?>
										<img src="<?php echo esc_url($poster_url); ?>" alt="<?php the_title(); ?>" loading="lazy">
									<?php else: ?>
										<div class="no-poster">
											<i class="fa fa-tv"></i>
											<span><?php the_title(); ?></span>
										</div>
									<?php endif; ?>
									<div class="trending-rank"><?php echo $counter; ?></div>
									<div class="trending-views">
										<i class="fa fa-eye"></i>
										<span><?php echo $views_count; ?></span>
									</div>
									<div class="trending-overlay">
										<div class="trending-info">
											<h3><?php the_title(); ?></h3>
											<div class="trending-meta">
												<?php if ($year) echo '<span class="year">' . $year . '</span>'; ?>
												<?php if ($rating) echo '<span class="rating">★ ' . $rating . '</span>'; ?>
												<span class="views-count">
													<i class="fa fa-eye"></i>
													<?php echo $views_count; ?> görüntülenme
												</span>
											</div>
										</div>
									</div>
								</div>
								<a href="<?php the_permalink(); ?>" class="lnk-blk"></a>
							</div>
						<?php 
						$counter++;
						endwhile;
					endif;
					wp_reset_query(); ?>
				</div>
			</section>
		</main>
		<?php get_sidebar(); ?>
	</div>
</div>

<!-- Modal System -->
<div class="modal-overlay" id="contentModal">
	<div class="modal-content">
		<div class="modal-header">
			<h2 class="modal-title" id="modalTitle">İçerik Detayları</h2>
			<button class="modal-close" id="modalClose">
				<i class="fa fa-times"></i>
			</button>
		</div>
		<div class="modal-body" id="modalBody">
			<!-- Modal içeriği buraya yüklenecek -->
		</div>
		<div class="modal-actions">
			<button class="btn-modal btn-modal-secondary" id="modalCloseBtn">
				<i class="fa fa-times"></i>
				Kapat
			</button>
			<a href="#" class="btn-modal btn-modal-primary" id="modalViewBtn" target="_blank">
				<i class="fa fa-external-link"></i>
				Detaylı Görüntüle
			</a>
		</div>
	</div>
</div>

<?php get_footer(); ?>
