<?php
defined( 'ABSPATH' ) or die( 'Oops!');
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
<div id="tmdbFilm">
    <div class="container">
        <div id="apiDiv">
            <div id="popuparea">
                <div id="message"></div>
                <ul id="pagination"></ul>
            </div>
        </div>
    </div>
    <form method="post">
        <h1>TMDB Film Ekle</h1>
        <table>
            <tr>
                <td>
                    <input type="text" id="searchInput" placeholder="Film Ara" />
                    <div id="submit">Ara</div>
                </td>
            </tr>
            <tr>
                <td>
                    <input placeholder="Film ID*" type="text" id="filmid" name="id" />
                </td>
            </tr>
            <tr>
                <td>
                    <textarea placeholder="Film İçeriği (İsteğe Bağlı)" name="content" style="width: 446px; height: 100px;"></textarea>
                </td>
            </tr>
            <tr>
                <td>
                    <label>Dil Seçin:</label>
                    <select name="dil" id="dil">
                        <option selected="selected"> Girilmedi </option>
                        <option> Turkce Dublaj </option>
                        <option> Turkce Altyazi </option>
                        <option> Turkce Altyazi-Dublaj </option>
                        <option> Ingilizce Altyazi </option>
                        <option> Altyazisiz </option>
						<option> Yerli Film </option>
                    </select>
                </td>
            </tr>
            <tr>
                <td>
                    <label>Yazı Durumunu Seçin:</label>
                    <select name="status" id="status">
                        <option selected="selected">Taslaklara Kaydet</option>
                        <option>Yayınla</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td colspan="2">
                    <input type="submit" name="submit" value="Filmi Ekle" />
                </td>
            </tr>
        </table>
    </form>
	<?php
	if(isset($_POST["submit"]) && empty($_POST["id"])) 
	{
		echo "<div id='errror'>Film ID girdiğinizden emin olun.</div>";
	} 
	elseif(isset($_POST["submit"]) && empty(get_option("filmplus_tmdb_id"))) 
	{
		echo "<div id='errror'>Api key girdiğinizden emin olun.</div>";
	} 
	elseif(!empty($_POST["id"]) && get_option("filmplus_tmdb_id") ) 
	{
		include_once(get_template_directory() . '/plugins/tmdb-film-botu/tmdb/get-films.php');
	} 
	?>
</div>