$(document).ready(function() {
	var tmdb_id = tmdb_ajax.tmdb_id;
	var no_thumbnail = tmdb_ajax.no_thumbnail;
    $("#submit").click(function(e) {
        $('#popuparea').fadeIn();
        var validate = Validate();
        $("#message").html(validate);
        if (validate.length == 0) {
            CallAPI(1);
        }
    });
    $("#message").on("click", ".add", function() {
		var resourceId = $(this).attr("resourceId");
		var currentValue = $('#filmid').val();
		if($(this).text() === "Kaldır") {
			var newValue = removeValue(currentValue, resourceId);
			$('#filmid').val(newValue);
			$(this).text("Seç");
		} else {
			if (currentValue.indexOf(resourceId) < 0) {
				if (currentValue === "") {
					$('#filmid').val(resourceId);
				} else {
					$('#filmid').val(currentValue + "," + resourceId);
				}
			}
			$(this).text("Kaldır");
		}
    });
    $("#message").on("click", "#kapat", function() {
        $('#popuparea').fadeOut();
    });
    $("#message").on("click", "#sec", function() {
		$(".add").each(function(){
			var currentValue = $('#filmid').val();
			var resourceId = $(this).attr("resourceId");
			if (currentValue.indexOf(resourceId) < 0) {
				if (currentValue === "") {
					$('#filmid').val(currentValue + resourceId);
				} else {
					$('#filmid').val(currentValue + "," + resourceId);
				}
			}
			$(this).text("Kaldır");
		});
    });
    $("#message").on("click", "#kaldir", function() {
		$(".add").each(function(){
			var currentValue = $('#filmid').val();
			var resourceId = $(this).attr("resourceId");
			var newValue = removeValue(currentValue, resourceId);
			$('#filmid').val(newValue);
			$(this).text("Seç");
		});
    });
	$("#message").on("click", ".info", function() {
		$(".field").remove();
		var resourceId = $(this).attr("resourceid");
		$("#modal" +resourceId).fadeIn();
        $.ajax({
			url: "https://api.themoviedb.org/3/movie/"+resourceId+"?language=tr-TR",
            data: {
                "api_key": tmdb_id
            },
            dataType: "json",
            success: function(result, status, xhr) {
				$("#modal" +resourceId).append('<div class="field"><span>Özet: </span>'+result["overview"]+'</div');
				var genres = [];
				for (i = 0; i < result["genres"].length; i++) {
					genres.push(result["genres"][i]["name"]);
				}
				genres.sort();
				$("#modal" +resourceId).append('<div class="field"><span>Tür: </span>' + genres.join(', ') + '</div>');
				$("#modal" +resourceId).append('<div class="field"><span>Yapım Yılı: </span>' + result["release_date"].substring(0, 4) + '</div>');
            },
        });
        $.ajax({
			url: "https://api.themoviedb.org/3/movie/"+resourceId+"/credits?",
            data: {
                "api_key": tmdb_id
            },
            dataType: "json",
            success: function(result, status, xhr) {
				var cast = [];
				for (i = 0; i < 5; i++) {
					cast.push(result["cast"][i]["name"]);
				}
				cast.sort();
				$("#modal" +resourceId).append('<div class="field"><span>Oyuncular: </span>' + cast.join(', ') + '</div>');
				for (i = 0; i < result["crew"].length; i++) {
					if (result["crew"][i]["job"] == 'Director') {
						$("#modal" +resourceId).append('<div class="field"><span>Yönetmen: </span>' + result["crew"][i]["name"] + '</div>')
					}
				}
            },
        });
	});
	$("#message").on("click", ".kapat", function() {
		$(".modal").fadeOut();
	});
    function CallAPI(page) {
        $.ajax({
            url: "https://api.themoviedb.org/3/search/movie?language=tr-TR&query=" + $("#searchInput").val() + "&page=" + page + "&include_adult=false",
            data: {
                "api_key": tmdb_id
            },
            dataType: "json",
            success: function(result, status, xhr) {
                $('#popuparea').show();
                var resultHtml = $("<div class=\"resultDiv\"><span id=\"sec\" class=\"Btn left\">Tümünü Seç</span><span id=\"kaldir\" class=\"Btn left2\">Tümünü Kaldır</span><span id=\"kapat\" class=\"Btn\">Kapat</span>");
                for (i = 0; i < result["results"].length; i++) {
                    var image = result["results"][i]["poster_path"] == null ? no_thumbnail : "https://image.tmdb.org/t/p/w500/" + result["results"][i]["poster_path"];
                    resultHtml.append("<div class=\"result\">" + "<img src=\"" + image + "\" />" + "<p><a>" + result["results"][i]["title"] + "</a></p><div class='info' resourceId=\"" + result["results"][i]["id"] + "\">Detay</div><div class='add' resourceId=\"" + result["results"][i]["id"] + "\">Seç</div></div>");
					resultHtml.append('<div class="modal" id="modal'+result['results'][i]['id'] +'"><div class="kapat">Kapat</div><div class="title">'+result['results'][i]['title']+' ('+result['results'][i]['original_title']+')</div></div>');
                }
                resultHtml.append("</div>");
                $("#message").html(resultHtml);
                if (result["total_results"] < 21) {
                    $("#pagination").hide();
                } else {
                    $("#pagination").show();
                }
                Paging(result["total_pages"]);
            },
            error: function(xhr, status, error) {
                $("#message").html("Hata!")
            }
        });
    }
    function Validate() {
        var errorMessage = "";
        if ($("#searchInput").val() == "") {
            $('#popuparea').hide();
        }
        return errorMessage;
    }
    function Paging(totalPage) {
        var obj = $("#pagination").twbsPagination({
            totalPages: totalPage,
            visiblePages: 5,
            onPageClick: function(event, page) {
                CallAPI(page);
            }
        });
    }
	function removeValue(list, value) {
		return list.replace(new RegExp(",?" + value + ",?"), function (match) {
			var first_comma = match.charAt(0) === ",",
				second_comma;
			if (first_comma && (second_comma = match.charAt(match.length - 1) === ",")) {
				return ",";
			}
			return "";
		});
	}
    $('#submit').click(function() {
        $('#pagination').twbsPagination('destroy');
        $('#pagination').twbsPagination($.extend(opts, {
            startPage: $('#pagination').data('currentPage')
        }));
    });
});