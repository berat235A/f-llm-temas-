<?php 
global $x_title , $original_title , $x_yapimyili;
$id_string = $_POST["id"];
$id_array = explode(",", $id_string);
foreach ($id_array as $id) {
	$url = "https://api.themoviedb.org/3/movie/".$id."?api_key=".get_option("filmplus_tmdb_id")."&language=tr-TR";
	$url2 = "https://api.themoviedb.org/3/movie/".$id."/credits?api_key=".get_option("filmplus_tmdb_id")."";
	$url3 = "https://api.themoviedb.org/3/movie/".$id."/videos?api_key=".get_option("filmplus_tmdb_id")."&language=en-US";
	$url4 = "https://api.themoviedb.org/3/movie/".$id."/images?api_key=".get_option("filmplus_tmdb_id")."";
	$json = getJson($url);
	$date = $json['release_date'];
	$uzunluk = strlen($date);
	$x_yapimyili = substr($date, 0, ($uzunluk - 6));
	$baglan = file_get_contents("https://www.imdb.com/title/".$json['imdb_id']."/");
	preg_match_all('@<span itemprop="ratingValue">(.*?)</span>@si',$baglan,$imdbpuan);
	$json2 = getJson($url2);
	$json3 = getJson($url3);
	$json4 = getJson($url4);
	$wp_upload_dir = wp_upload_dir();
	$title = sanitize_title($json['title']);
	for($i=0;$i<count($json['genres']) ; $i++)
	{
		$json['genres'][$i]['name'] = str_replace('-',' ',$json['genres'][$i]['name']);
		if(category_exists($json['genres'][$i]['name']) == "") 
		{
			wp_insert_category(array('cat_name' => $json['genres'][$i]['name']));
		}	
	}
	$ids = array();
	for($i=0;$i<count($json['genres']) ; $i++)
	{
		$ids[$i] = get_category_id($json['genres'][$i]['name']);
	}
	$cts = array();
	for($i=0;$i<count($json['production_countries']) ; $i++)
	{
		$cts[$i] = $json['production_countries'][$i]['iso_3166_1']; 
	}
	$cast = array();
	for($i=0;$i<5 ; $i++)
	{
		$cast[$i] = $json2['cast'][$i]['name']; 
	}
	$crew = array();
	for($i=0;$i<count($json2['crew']) ; $i++)
	{
		if($json2['crew'][$i]['job'] == "Director")
		$crew[$i] = $json2['crew'][$i]['name'];
	}
	if(count($json4['backdrops']) < 8) $counter = count($json4['backdrops']);
	else $counter = 8;
	$film_poster = array();
	for($i=0; $i<$counter; $i++)
	{
		array_push($film_poster, $json4['backdrops'][$i]['file_path']);
	}
	$x_title = $json['title'];
	$original_title = $json['original_title'];
	$filmplus_tmdb_title = get_option('filmplus_tmdb_title');
	$filmplus_tmdb_seo_title = get_option('filmplus_tmdb_seo_title');
	$filmplus_tmdb_seo_desc = get_option('filmplus_tmdb_seo_desc');
	$filmplus_tmdb_seo_url = get_option('filmplus_tmdb_seo_url');
	if( $_POST["status"] == 'Taslaklara Kaydet')
	{
		echo '<p><h2>Film Taslaklara Kaydedildi!</h2> ('.$x_title.')</p>';
		$poststatus = "draft";
	}
	else
	{
		echo '<p><h2>Film Yayımlandı!</h2> ('.$x_title.')</p>';
		$poststatus = "publish";
	}
	$my_post = array(
		'post_title'    => tmdbSeo($filmplus_tmdb_title),
		'post_name' => sanitize_title(tmdbSeo($filmplus_tmdb_seo_url)),
		'post_type'     => 'movies',
		'post_content'  => $_POST["content"],    
		'post_status'   => $poststatus,
		'post_author'   => 1,
	);
	$post_id = wp_insert_post( $my_post );
	
	// Tema ile uyumlu meta field'lar
	update_post_meta($post_id, 'field_release_year', $x_yapimyili);
	update_post_meta($post_id, 'rating', $imdbpuan[1][0]);
	update_post_meta($post_id, 'poster_hotlink', $json['poster_path']);
	update_post_meta($post_id, 'field_overview', $json['overview']);
	update_post_meta($post_id, 'field_original_title', $json['original_title']);
	update_post_meta($post_id, 'field_runtime', $json['runtime']);
	update_post_meta($post_id, 'field_budget', $json['budget']);
	update_post_meta($post_id, 'field_revenue', $json['revenue']);
	update_post_meta($post_id, 'field_imdb_id', $json['imdb_id']);
	update_post_meta($post_id, 'field_dil', $_POST["dil"]);
	
	// Eski meta field'lar (geriye uyumluluk için)
	update_post_meta($post_id, 'filmadi', $json['original_title']);
	update_post_meta($post_id, 'dil', $_POST["dil"]);
	update_post_meta($post_id, 'ozet', $json['overview']);
	update_post_meta($post_id, 'imdb', $imdbpuan[1][0]);
	if(!empty($json3['results']['0']['key'])) {
		update_post_meta($post_id, 'youtube', 'https://www.youtube.com/watch?v='.$json3['results']['0']['key'].'');
	}
	if(get_option('filmplus_seo_field') == 'On' && !empty($filmplus_tmdb_seo_title))
	{
		update_post_meta($post_id, 'filmplus_seotitle', tmdbSeo($filmplus_tmdb_seo_title));
	}
	if(get_option('filmplus_seo_field') == 'On' && !empty($filmplus_tmdb_seo_desc))
	{
		update_post_meta($post_id, 'filmplus_seodescription', tmdbSeo($filmplus_tmdb_seo_desc));
	}
	for($i=0; $i<count($film_poster); $i++){
		add_post_meta( $post_id, 'film_poster', $film_poster[$i] );
	}
	wp_set_object_terms($post_id, $cast, 'oyuncu' );
	wp_set_object_terms($post_id, $crew, 'yonetmen' );
	wp_set_object_terms($post_id, tmdbCountry($cts), 'ulke' );
	wp_set_object_terms($post_id, $x_yapimyili, 'yil' );
	wp_set_post_terms($post_id, $ids, 'category');
	set_post_thumbnail( $post_id, tmdb_insert_attachment_from_url('https://image.tmdb.org/t/p/w300_and_h450_bestv2/'.$json['poster_path'].'' , ''.$title.'.jpg'));
}
?>