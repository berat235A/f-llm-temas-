<?php
defined( 'ABSPATH' ) or die( 'No access!');
?>
<h1>Themoviedb.org Film Botu</h1>
<br/>
<h2>Nasıl Kullanılır?</h2>
<li>Öncelikle botu kullanmak için bir api anahtarına ihtiyacınız var. "themoviedb.org" adresinden aldığınız api anahtarını FilmPlus paneldeki "TMDB Bot Ayarları >> Api Ayarları" kısmına girin.</li>
<li>Daha sonra yandaki "Film Ekle" sekmesinden dilediğiniz filmi aratarak ekleyebilirsiniz.</li>
<br/>
<h2>Api Anahtarı Nasıl Alınır?</h2>
<li>Öncelikle <a href="https://www.themoviedb.org/account/signup" target="_blank" style="text-decoration:underline">buraya tıklayarak</a> "themoviedb.org" adresine kaydolun.</li> 
<li>Daha sonra üye girişi yapın ve "Avatarınıza Tıklayın >> Ayarlar >> API >> Request an API Key" adımlarını takip ederek yeni bir api anahtarı alın.</li>
<li>Detayları <a href="https://developers.themoviedb.org/3/getting-started/introduction" target="_blank" style="text-decoration:underline">buradan</a> görebilirsiniz.