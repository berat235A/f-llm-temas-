<?php

defined( 'ABSPATH' ) or die( 'Oops!' );

/*
  Plugin Name: TMDB Film Botu
  Description: Bu eklenti ile Themoviedb.org adresindeki filmleri tüm bilgileriyle beraber sitenize ekleyebilirsiniz.
  Version:     3.0.0
  Author:      FCS
  Author URI:  https://www.fcsthemes.com/
  Text Domain: tmdb-film-botu
 */
 
define( 'TMDB_PATH', get_template_directory_uri() . '/plugins/tmdb-film-botu/tmdb' );

function theme_options_panel(){
	add_menu_page('TMDB Film Botu', 'TMDB Film Botu', 'manage_options', 'tmdb-film-botu', 'tmdb_theme_func', TMDB_PATH.'/images/tmdb-icon.png');
	add_submenu_page( 'tmdb-film-botu', 'Film Ekle', 'Film Ekle', 'manage_options', 'tmdb-film-ekle', 'tmdb_theme_func_tab');
}
add_action('admin_menu', 'theme_options_panel');
 
function tmdb_theme_func(){
	include_once(get_template_directory() . '/plugins/tmdb-film-botu/tmdb/tmdb.php');
}

function tmdb_theme_func_tab(){
	include_once(get_template_directory() . '/plugins/tmdb-film-botu/tmdb/add-films.php');
}

function tmdb_backend_assets() {
	wp_enqueue_script('bootstrap-js', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js', null, null, true);
	wp_enqueue_script('twbsPagination-js', TMDB_PATH . '/js/jquery.twbsPagination.js', null, null, true);
	wp_enqueue_style( 'tmdb-style', TMDB_PATH . '/css/style.css');
    wp_register_script ('tmdb', TMDB_PATH . '/js/tmdb.js', null, null, true);
    wp_localize_script (
        'tmdb',
        'tmdb_ajax',
        array(
            'tmdb_id' => get_option('filmplus_tmdb_id'),
			'no_thumbnail' => TMDB_PATH.'/images/no-thumbnail.png',
        )
    );
    wp_enqueue_script('tmdb');
}
add_action('admin_enqueue_scripts', 'tmdb_backend_assets');

function c_get($url) {
	$ch = @curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	$head[] = "Connection: keep-alive";
	$head[] = "Keep-Alive: 300";
	$head[] = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
	$head[] = "Accept-Language: en-us,en;q=0.5";
	curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36');
	curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_REFERER,$url);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($ch, CURLOPT_TIMEOUT, 60);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array('Expect:'));
	$page = curl_exec($ch);
	curl_close($ch);
	return $page;
}

function tmdb_insert_attachment_from_url($url, $title , $parent_post_id = null) {
	if( !class_exists( 'WP_Http' ) )
		include_once( ABSPATH . WPINC . '/class-http.php' );
	$http = new WP_Http();
	$response = $http->request( $url );
	$upload = wp_upload_bits($title, null, $response['body'] );
	if( !empty( $upload['error'] ) ) {
		return false;
	}
	$file_path = $upload['file'];
	$file_name = basename( $file_path );
	$file_type = wp_check_filetype( $file_name, null );
	$attachment_title = sanitize_file_name( pathinfo( $file_name, PATHINFO_FILENAME ) );
	$wp_upload_dir = wp_upload_dir();
	$post_info = array(
		'guid'           => $wp_upload_dir['url'] . '/' . $file_name,
		'post_mime_type' => $file_type['type'],
		'post_title'     => $attachment_title,
		'post_content'   => '',
		'post_status'    => 'inherit',
	);
	$attach_id = wp_insert_attachment( $post_info, $file_path, $parent_post_id );
	require_once( ABSPATH . 'wp-admin/includes/image.php' );
	$attach_data = wp_generate_attachment_metadata( $attach_id, $file_path );
	wp_update_attachment_metadata( $attach_id,  $attach_data );
	return $attach_id;
}

function getJson($url){
	$page = c_get($url);
	$pos = strpos($page, '{');
	$dataget = substr($page, $pos);
	return json_decode($dataget, 1);
}

function get_category_id($cat_name){
	$term = get_term_by('name', $cat_name, 'category');
	return $term->term_id;
}

function tmdbCountry($string){
	$search = array('US', 'GB', 'TR', 'CA','AR','AU','AT','BE','BR','CN','CO','DK','FR','DE','IN','IT','JP','MX','NL','RU','ES','TH','UA','KR','SE','NZ','BG','AE','BG','BY','CH','CZ','FI','HK','HU','IE','IR','KH','LB','LT','LU','MA','MM','MW','NO','NZ','PE','PH','PO','PT','RO','SU','TW','ZA');
	$replace = array('ABD', 'İngiltere', 'Türkiye', 'Kanada','Arjantin','Avustralya','Avusturya','Belçika','Brezilya','Çin','Kolombiya','Danimarka','Fransa','Almanya','Hindistan','İtalya','Japonya','Meksika','Hollanda','Rusya','İspanya','Tayland','Ukrayna','Güney Kore','İsveç','Yeni Zelanda','Bulgaristan','Birleşik Arap Emirlikleri','Bulgaristan','Beyaz Rusya','İsviçre','Çek Cumhuriyeti','Finlandiya','Hong Kong','Macaristan','İrlanda','İran','Kamboçya','Lübnan','Litvanya','Lüksemburg','Fas','Burma','Malavi','Norveç','Yeni Zelanda','Peru','Filipinler','Polonya','Portekiz','Romanya','Sovyetler Birliği','Tayvan','Zambiya');
	return str_replace($search, $replace, $string);		
}

function tmdbSeo($string){
	global $x_title , $original_title , $x_yapimyili;
	$search = array('{title}', '{original_title}', '{yapim_yili}');
	$replace = array($x_title , $original_title , $x_yapimyili);
	return str_replace($search, $replace, $string);		
}