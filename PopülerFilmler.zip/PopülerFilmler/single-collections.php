<?php
/**
 * Koleksiyon detay sayfası template
 */

get_header(); ?>

<div class="TPost">
    <div class="Container">
        <div class="TPMvCn">
            <article class="TPost A">
                <header class="Container">
                    <div class="TPMvCn">
                        <div class="Title">
                            <h1 class="Title"><?php the_title(); ?></h1>
                        </div>
                        
                        <?php if (has_excerpt()) : ?>
                        <div class="Description">
                            <?php the_excerpt(); ?>
                        </div>
                        <?php endif; ?>
                        
                        <div class="Info">
                            <div class="Vote">
                                <div class="post-ratings">
                                    <i class="fa fa-star"></i>
                                    <span class="rating"><?php echo get_post_meta(get_the_ID(), '_collection_rating', true) ?: '0'; ?></span>
                                </div>
                            </div>
                            
                            <div class="Share">
                                <div class="social-share">
                                    <span><?php _e('Paylaş:', 'torofilm'); ?></span>
                                    <a href="#" class="share-facebook" data-url="<?php the_permalink(); ?>" data-title="<?php the_title(); ?>">
                                        <i class="fa fa-facebook"></i>
                                    </a>
                                    <a href="#" class="share-twitter" data-url="<?php the_permalink(); ?>" data-title="<?php the_title(); ?>">
                                        <i class="fa fa-twitter"></i>
                                    </a>
                                    <a href="#" class="share-whatsapp" data-url="<?php the_permalink(); ?>" data-title="<?php the_title(); ?>">
                                        <i class="fa fa-whatsapp"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </header>
                
                <div class="TPost C">
                    <div class="Container">
                        <div class="TPMvCn">
                            <div class="Description">
                                <?php the_content(); ?>
                            </div>
                            
                            <?php
                            // Koleksiyon öğelerini al
                            $collection_items = TOROFILM_Collections::get_collection_items(get_the_ID());
                            
                            if (!empty($collection_items)) :
                            ?>
                            <div class="CollectionItems">
                                <h3><?php _e('Koleksiyon İçeriği', 'torofilm'); ?></h3>
                                <div class="MoviesList">
                                    <div class="Top">
                                        <h2><?php _e('İçerikler', 'torofilm'); ?></h2>
                                    </div>
                                    
                                    <div class="MovieList Rows A04 B03 C02 D02 E01">
                                        <?php foreach ($collection_items as $item) : ?>
                                        <article class="TPost C">
                                            <div class="Image">
                                                <figure class="Objf TpMvPlay AAIco-play_arrow">
                                                    <a href="<?php echo get_permalink($item->ID); ?>">
                                                        <?php echo TOROFLIX_Movies::image($item->ID, 'thumbnail'); ?>
                                                    </a>
                                                </figure>
                                                
                                                <div class="Title">
                                                    <h3 class="Title">
                                                        <a href="<?php echo get_permalink($item->ID); ?>">
                                                            <?php echo get_the_title($item->ID); ?>
                                                        </a>
                                                    </h3>
                                                </div>
                                                
                                                <div class="Info">
                                                    <span class="Date"><?php echo TOROFLIX_Movies::year($item->ID); ?></span>
                                                    
                                                    <?php if (get_post_type($item->ID) == 'movies') : ?>
                                                    <span class="Duration"><?php echo TOROFLIX_Movies::duration($item->ID); ?></span>
                                                    <?php else : ?>
                                                    <span class="Seasons">
                                                        <?php 
                                                        $seasons = TOROFLIX_Movies::number_seasons_serie($item->ID);
                                                        echo $seasons . ' ' . ($seasons == 1 ? __('Sezon', 'torofilm') : __('Sezon', 'torofilm'));
                                                        ?>
                                                    </span>
                                                    <?php endif; ?>
                                                    
                                                    <span class="Views">
                                                        <i class="fa fa-eye"></i>
                                                        <?php echo TOROFLIX_Movies::views($item->ID); ?>
                                                    </span>
                                                    
                                                    <span class="Rating">
                                                        <i class="fa fa-star"></i>
                                                        <?php echo get_post_meta($item->ID, 'rating', true) ?: '0'; ?>
                                                    </span>
                                                </div>
                                                
                                                <div class="Description">
                                                    <p><?php echo wp_trim_words(get_the_excerpt($item->ID), 20); ?></p>
                                                </div>
                                            </div>
                                        </article>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>
                            <?php else : ?>
                            <div class="NoItems">
                                <p><?php _e('Bu koleksiyonda henüz içerik bulunmuyor.', 'torofilm'); ?></p>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </article>
        </div>
    </div>
</div>

<style>
.CollectionItems {
    margin-top: 30px;
}

.CollectionItems h3 {
    margin-bottom: 20px;
    color: #fff;
    font-size: 24px;
}

.NoItems {
    text-align: center;
    padding: 40px;
    color: #999;
    font-style: italic;
}

.social-share {
    display: flex;
    align-items: center;
    gap: 10px;
}

.social-share span {
    margin-right: 10px;
    color: #fff;
}

.social-share a {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 35px;
    height: 35px;
    border-radius: 50%;
    color: #fff;
    text-decoration: none;
    transition: all 0.3s ease;
}

.share-facebook { background: #3b5998; }
.share-twitter { background: #1da1f2; }
.share-whatsapp { background: #25d366; }

.social-share a:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.3);
}

.post-ratings {
    display: flex;
    align-items: center;
    gap: 5px;
    color: #ffd700;
}

.post-ratings .fa-star {
    font-size: 18px;
}

.post-ratings .rating {
    font-weight: bold;
    font-size: 16px;
}
</style>

<script>
jQuery(document).ready(function($) {
    // Sosyal medya paylaşım
    $('.share-facebook').on('click', function(e) {
        e.preventDefault();
        var url = $(this).data('url');
        var title = $(this).data('title');
        window.open('https://www.facebook.com/sharer/sharer.php?u=' + encodeURIComponent(url), 'facebook-share', 'width=600,height=400');
    });
    
    $('.share-twitter').on('click', function(e) {
        e.preventDefault();
        var url = $(this).data('url');
        var title = $(this).data('title');
        window.open('https://twitter.com/intent/tweet?url=' + encodeURIComponent(url) + '&text=' + encodeURIComponent(title), 'twitter-share', 'width=600,height=400');
    });
    
    $('.share-whatsapp').on('click', function(e) {
        e.preventDefault();
        var url = $(this).data('url');
        var title = $(this).data('title');
        window.open('https://wa.me/?text=' + encodeURIComponent(title + ' ' + url), 'whatsapp-share', 'width=600,height=400');
    });
});
</script>

<?php get_footer(); ?>
