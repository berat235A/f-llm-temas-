<?php
global $wpdb;

$_details = wp_get_theme('torofilm');

#Version
define('TOROFILM_VERSION',  $_details['Version']);
$dir_path = (substr(get_template_directory(),     -1) === '/') ? get_template_directory()     : get_template_directory()     . '/';
$dir_uri  = (substr(get_template_directory_uri(), -1) === '/') ? get_template_directory_uri() : get_template_directory_uri() . '/';
define('TOROFILM_DIR_PATH', $dir_path);
define('TOROFILM_DIR_URI',  $dir_uri);
#Toroplay Origin
define('TR_GRABBER_MOVIES', 1); // Activate module movies
define('TR_GRABBER_SERIES', 1); // Activate module series
define('TR_MINIFY', true);

#Clase General
function activate_torofilm()
{
    require_once TOROFILM_DIR_PATH . 'includes/class-torofilm-activator.php';
    TOROFILM_Activator::activate();
}
add_action('after_switch_theme', 'activate_torofilm');
require_once TOROFILM_DIR_PATH . 'includes/class-torofilm-master.php';
require_once TOROFILM_DIR_PATH . 'includes/class-torofilm-video-hosting.php';

// Admin classes
if (is_admin()) {
    require_once TOROFILM_DIR_PATH . 'admin/class-torofilm-video-admin.php';
    require_once TOROFILM_DIR_PATH . 'admin/class-torofilm-tmdb-admin.php';
}
function run_torofilm_master()
{
    $bcpg_master = new TOROFILM_Master;
    $bcpg_master->run();
}
run_torofilm_master();
function add_menuclass($ulclass)
{
    $a = 'How are you?';
    if (strpos($ulclass, 'dfx fwp jst-cr') !== false) {
        return preg_replace('/<a/', '<a class="btn lin sm rnd light"', $ulclass, -1);
    } else {
        return $ulclass;
    }
}
add_filter('wp_nav_menu', 'add_menuclass');
add_action('pre_get_posts', function ($query) {
    if (!is_admin() && $query->is_main_query()) {
        if (is_category() or is_tax()) {
            $query->set('post_type', array('movies', 'series'));
        }
        if ($query->is_search()) {
            $query->set('post_type', array('movies', 'series'));
        }
    }
});
function pagination12($prev = 'PREV', $next = 'NEXT')
{
    $categories = wp_count_terms('episodes');
    global $wp_query, $wp_rewrite;
    $wp_query->query_vars['paged'] > 1 ? $current = $wp_query->query_vars['paged'] : $current = 1;
    $pagination = array(
        'base' => @add_query_arg('paged', '%#%'),
        'format' => '',
        'total' => ceil($categories / 60),
        'current' => $current,
        'prev_text' => $prev,
        'next_text' => $next,
        'type' => 'plain'
    );
    if ($wp_rewrite->using_permalinks())
        $pagination['base'] = user_trailingslashit(trailingslashit(remove_query_arg('s', get_pagenum_link(1))) . 'page/%#%/', 'paged');
    if (!empty($wp_query->query_vars['s']))
        $pagination['add_args'] = array('s' => get_query_var('s'));
    echo paginate_links($pagination);
};
load_theme_textdomain('torofilm', get_template_directory() . '/languages');
if (!isset($content_width)) $content_width = 900;
add_action('after_switch_theme', 'flush_rewrite_rules');

// Mobil CSS dosyasını yükle
function torofilm_enqueue_mobile_styles() {
    wp_enqueue_style(
        'torofilm-mobile',
        get_template_directory_uri() . '/public/css/torofilm-mobile.css',
        array('torofilm-public'),
        TOROFILM_VERSION,
        'screen and (max-width: 768px)'
    );
}
add_action('wp_enqueue_scripts', 'torofilm_enqueue_mobile_styles');

// Swiper.js kütüphanesini yükle (Yerel dosyalardan)
function torofilm_enqueue_swiper() {
    wp_enqueue_style(
        'swiper-css',
        get_template_directory_uri() . '/public/css/swiper-bundle.min.css',
        array(),
        '11.0.0'
    );
    
    wp_enqueue_script(
        'swiper-js',
        get_template_directory_uri() . '/public/js/swiper-bundle.min.js',
        array(),
        '11.0.0',
        true
    );
}
add_action('wp_enqueue_scripts', 'torofilm_enqueue_swiper');

// Mobil JavaScript dosyasını yükle
function torofilm_enqueue_mobile_scripts() {
    wp_enqueue_script(
        'torofilm-mobile',
        get_template_directory_uri() . '/public/js/torofilm-mobile.js',
        array('jquery', 'swiper-js'),
        TOROFILM_VERSION,
        true
    );
}
add_action('wp_enqueue_scripts', 'torofilm_enqueue_mobile_scripts');

// Platform URL rewrite rules
function add_platform_rewrite_rules() {
    add_rewrite_rule('^platform/([^/]+)/?$', 'index.php?platform_id=$matches[1]', 'top');
    add_rewrite_rule('^platform/([^/]+)/page/([0-9]+)/?$', 'index.php?platform_id=$matches[1]&paged=$matches[2]', 'top');
}
add_action('init', 'add_platform_rewrite_rules');

// Force flush rewrite rules on theme activation
function flush_platform_rewrite_rules() {
    add_platform_rewrite_rules();
    flush_rewrite_rules();
}
add_action('after_switch_theme', 'flush_platform_rewrite_rules');

// Add platform_id query var
function add_platform_query_vars($vars) {
    $vars[] = 'platform_id';
    return $vars;
}
add_filter('query_vars', 'add_platform_query_vars');

// Template redirect for platform pages
function platform_template_redirect() {
    $platform_id = get_query_var('platform_id');
    if ($platform_id) {
        // Platform var mı kontrol et
        $platforms = get_option('torofilm_platforms', array());
        if (isset($platforms[$platform_id])) {
            $template = locate_template('page-platform.php');
            if ($template) {
                include $template;
                exit;
            }
        } else {
            // Platform bulunamadı, 404 sayfasına yönlendir
            global $wp_query;
            $wp_query->set_404();
            status_header(404);
            get_template_part('404');
            exit;
        }
    }
}
add_action('template_redirect', 'platform_template_redirect');

// AJAX handler for adding content to platform
function handle_add_content_to_platform() {
    // Nonce kontrolü
    if (!wp_verify_nonce($_POST['nonce'], 'add_content_nonce')) {
        wp_die('Güvenlik hatası!');
    }
    
    // Kullanıcı yetkisi kontrolü
    if (!current_user_can('edit_posts')) {
        wp_die('Yetkiniz yok!');
    }
    
    $platform_id = sanitize_text_field($_POST['platform_id']);
    $content_type = sanitize_text_field($_POST['content_type']);
    $content_title = sanitize_text_field($_POST['content_title']);
    $content_year = sanitize_text_field($_POST['content_year']);
    $content_description = sanitize_textarea_field($_POST['content_description']);
    $content_poster = esc_url_raw($_POST['content_poster']);
    $content_rating = floatval($_POST['content_rating']);
    $content_genres = sanitize_text_field($_POST['content_genres']);
    
    // Başlık kontrolü
    if (empty($content_title)) {
        wp_send_json_error('Başlık gereklidir!');
        return;
    }
    
    // İçerik türü kontrolü
    if (!in_array($content_type, ['movies', 'series'])) {
        wp_send_json_error('Geçersiz içerik türü!');
        return;
    }
    
    // Aynı başlıkta içerik var mı kontrol et
    $existing_post = get_page_by_title($content_title, OBJECT, $content_type);
    if ($existing_post) {
        wp_send_json_error('Bu başlıkta bir içerik zaten mevcut!');
        return;
    }
    
    // Post oluştur
    $post_data = array(
        'post_title' => $content_title,
        'post_content' => $content_description,
        'post_status' => 'publish',
        'post_type' => $content_type,
        'post_author' => get_current_user_id()
    );
    
    $post_id = wp_insert_post($post_data);
    
    if ($post_id && !is_wp_error($post_id)) {
        // Meta verilerini kaydet
        if (!empty($content_year)) {
            update_post_meta($post_id, 'field_release_year', $content_year);
        }
        
        if (!empty($content_poster)) {
            update_post_meta($post_id, 'poster_hotlink', $content_poster);
        }
        
        if (!empty($content_rating)) {
            update_post_meta($post_id, 'rating', $content_rating);
        }
        
        // Platform bilgisini kaydet
        update_post_meta($post_id, '_torofilm_platforms', array($platform_id));
        
        // Türleri kaydet
        if (!empty($content_genres)) {
            $genres = array_map('trim', explode(',', $content_genres));
            foreach ($genres as $genre) {
                if (!empty($genre)) {
                    $term = wp_insert_term($genre, 'category');
                    if (!is_wp_error($term)) {
                        wp_set_post_terms($post_id, array($term['term_id']), 'category', true);
                    }
                }
            }
        }
        
        // Varsayılan meta veriler
        update_post_meta($post_id, 'views', 0);
        
        wp_send_json_success('İçerik başarıyla eklendi!');
    } else {
        wp_send_json_error('İçerik eklenirken hata oluştu!');
    }
}
add_action('wp_ajax_add_content_to_platform', 'handle_add_content_to_platform');
add_action('wp_ajax_nopriv_add_content_to_platform', 'handle_add_content_to_platform');


function lang_torofilm($text, $id_text)
{
	$text_database = get_option($id_text);
	if ($text_database) {
		$text = $text_database;
	} else {
		$text = __($text, 'torofilm');
	}
	return $text;
}

// Koleksiyonlar için rewrite rules
function add_collections_rewrite_rules() {
    add_rewrite_rule('^koleksiyonlar/?$', 'index.php?post_type=collections', 'top');
    add_rewrite_rule('^koleksiyon/([^/]+)/?$', 'index.php?collections=$matches[1]', 'top');
}
add_action('init', 'add_collections_rewrite_rules');

// Koleksiyonlar için query vars
function add_collections_query_vars($vars) {
    $vars[] = 'collections';
    return $vars;
}
add_filter('query_vars', 'add_collections_query_vars');

// Koleksiyonlar için template redirect
function collections_template_redirect() {
    if (is_post_type_archive('collections')) {
        $template = locate_template('archive-collections.php');
        if ($template) {
            include $template;
            exit;
        }
    }
}
add_action('template_redirect', 'collections_template_redirect');

// Koleksiyonlar için admin menü sıralaması
function collections_admin_menu_order($menu_order) {
    $new_order = array();
    
    foreach ($menu_order as $index => $item) {
        if ($item == 'edit.php?post_type=collections') {
            $new_order[] = $item;
        }
    }
    
    return $new_order;
}
add_filter('custom_menu_order', '__return_true');
add_filter('menu_order', 'collections_admin_menu_order');

// Koleksiyonlar için özel sütunlar
function collections_admin_columns($columns) {
    $new_columns = array();
    $new_columns['cb'] = $columns['cb'];
    $new_columns['title'] = $columns['title'];
    $new_columns['collection_items'] = __('İçerik Sayısı', 'torofilm');
    $new_columns['collection_type'] = __('Tür', 'torofilm');
    $new_columns['featured'] = __('Öne Çıkan', 'torofilm');
    $new_columns['date'] = $columns['date'];
    
    return $new_columns;
}
add_filter('manage_collections_posts_columns', 'collections_admin_columns');

function collections_admin_column_content($column, $post_id) {
    switch ($column) {
        case 'collection_items':
            $items = get_post_meta($post_id, '_collection_items', true);
            $count = is_array($items) ? count($items) : 0;
            echo $count . ' ' . ($count == 1 ? __('İçerik', 'torofilm') : __('İçerik', 'torofilm'));
            break;
            
        case 'collection_type':
            $type = get_post_meta($post_id, '_collection_type', true);
            switch ($type) {
                case 'movies':
                    echo __('Filmler', 'torofilm');
                    break;
                case 'series':
                    echo __('Diziler', 'torofilm');
                    break;
                default:
                    echo __('Karışık', 'torofilm');
            }
            break;
            
        case 'featured':
            $featured = get_post_meta($post_id, '_collection_featured', true);
            echo $featured ? '<span style="color: #ffd700;">★</span>' : '—';
            break;
    }
}
add_action('manage_collections_posts_custom_column', 'collections_admin_column_content', 10, 2);

// Koleksiyonlar için sıralama
function collections_admin_sortable_columns($columns) {
    $columns['collection_items'] = 'collection_items';
    $columns['collection_type'] = 'collection_type';
    $columns['featured'] = 'featured';
    return $columns;
}
add_filter('manage_edit-collections_sortable_columns', 'collections_admin_sortable_columns');

function collections_admin_orderby($query) {
    if (!is_admin() || !$query->is_main_query()) {
        return;
    }
    
    $orderby = $query->get('orderby');
    
    if ('collection_items' == $orderby) {
        $query->set('meta_key', '_collection_items');
        $query->set('orderby', 'meta_value_num');
    } elseif ('featured' == $orderby) {
        $query->set('meta_key', '_collection_featured');
        $query->set('orderby', 'meta_value_num');
    }
}
add_action('pre_get_posts', 'collections_admin_orderby');

// Koleksiyonlar için menü linki ekle
function add_collections_to_menu($items, $args) {
    if ($args->theme_location == 'primary') {
        $collections_link = '<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-collections">';
        $collections_link .= '<a href="' . get_post_type_archive_link('collections') . '">';
        $collections_link .= '<i class="fa fa-folder-open"></i> ' . __('Koleksiyonlar', 'torofilm');
        $collections_link .= '</a>';
        $collections_link .= '</li>';
        
        // Menünün sonuna ekle
        $items .= $collections_link;
    }
    return $items;
}
add_filter('wp_nav_menu_items', 'add_collections_to_menu', 10, 2);

// Koleksiyonlar için breadcrumb
function collections_breadcrumb($breadcrumb) {
    if (is_post_type_archive('collections')) {
        $breadcrumb = '<a href="' . home_url() . '">' . __('Ana Sayfa', 'torofilm') . '</a> > ';
        $breadcrumb .= __('Koleksiyonlar', 'torofilm');
    } elseif (is_singular('collections')) {
        $breadcrumb = '<a href="' . home_url() . '">' . __('Ana Sayfa', 'torofilm') . '</a> > ';
        $breadcrumb .= '<a href="' . get_post_type_archive_link('collections') . '">' . __('Koleksiyonlar', 'torofilm') . '</a> > ';
        $breadcrumb .= get_the_title();
    }
    return $breadcrumb;
}
add_filter('torofilm_breadcrumb', 'collections_breadcrumb');

// Koleksiyonlar için özel meta description
function collections_meta_description($description) {
    if (is_post_type_archive('collections')) {
        $description = __('En sevdiğiniz filmleri ve dizileri keşfedin. Özel koleksiyonlarımızda binlerce içerik sizi bekliyor.', 'torofilm');
    } elseif (is_singular('collections')) {
        $items = get_post_meta(get_the_ID(), '_collection_items', true);
        $count = is_array($items) ? count($items) : 0;
        $description = get_the_excerpt() . ' ' . sprintf(__('Bu koleksiyonda %d içerik bulunuyor.', 'torofilm'), $count);
    }
    return $description;
}
add_filter('wpseo_metadesc', 'collections_meta_description');
add_filter('aioseo_description', 'collections_meta_description');

// AJAX: Seçili öğelerin detaylarını al
function get_selected_items_details() {
    if (!wp_verify_nonce($_POST['nonce'], 'get_items_details')) {
        wp_die('Güvenlik hatası!');
    }
    
    $items = sanitize_text_field($_POST['items']);
    $item_ids = array_filter(explode(',', $items));
    
    $results = array();
    
    foreach ($item_ids as $item_id) {
        $post = get_post($item_id);
        if ($post && in_array($post->post_type, array('movies', 'series'))) {
            $results[] = array(
                'id' => $post->ID,
                'title' => $post->post_title,
                'type' => $post->post_type == 'movies' ? __('Film', 'torofilm') : __('Dizi', 'torofilm'),
                'thumbnail' => TOROFLIX_Movies::image($post->ID, 'thumbnail')
            );
        }
    }
    
    wp_send_json_success($results);
}
add_action('wp_ajax_get_selected_items_details', 'get_selected_items_details');
add_action('wp_ajax_nopriv_get_selected_items_details', 'get_selected_items_details');

// AJAX: Platformdan koleksiyon oluştur
function create_collection_from_platform() {
    if (!wp_verify_nonce($_POST['nonce'], 'create_collection_nonce')) {
        wp_die('Güvenlik hatası!');
    }
    
    if (!current_user_can('edit_posts')) {
        wp_die('Yetkiniz yok!');
    }
    
    $platform_id = sanitize_text_field($_POST['platform_id']);
    $collection_title = sanitize_text_field($_POST['collection_title']);
    $collection_description = sanitize_textarea_field($_POST['collection_description']);
    $collection_type = sanitize_text_field($_POST['collection_type']);
    $collection_featured = intval($_POST['collection_featured']);
    $collection_sort_order = sanitize_text_field($_POST['collection_sort_order']);
    $collection_items = sanitize_text_field($_POST['collection_items']);
    
    // Başlık kontrolü
    if (empty($collection_title)) {
        wp_send_json_error('Koleksiyon başlığı gereklidir!');
        return;
    }
    
    // Aynı başlıkta koleksiyon var mı kontrol et
    $existing_post = get_page_by_title($collection_title, OBJECT, 'collections');
    if ($existing_post) {
        wp_send_json_error('Bu başlıkta bir koleksiyon zaten mevcut!');
        return;
    }
    
    // Koleksiyon oluştur
    $post_data = array(
        'post_title' => $collection_title,
        'post_content' => $collection_description,
        'post_status' => 'publish',
        'post_type' => 'collections',
        'post_author' => get_current_user_id()
    );
    
    $post_id = wp_insert_post($post_data);
    
    if ($post_id && !is_wp_error($post_id)) {
        // Meta verilerini kaydet
        $items = array_filter(explode(',', $collection_items));
        update_post_meta($post_id, '_collection_items', $items);
        update_post_meta($post_id, '_collection_type', $collection_type);
        update_post_meta($post_id, '_collection_featured', $collection_featured);
        update_post_meta($post_id, '_collection_sort_order', $collection_sort_order);
        
        // Seçili öğelerin platform bilgilerini güncelle
        foreach ($items as $item_id) {
            $item_platforms = get_post_meta($item_id, '_torofilm_platforms', true);
            if (!is_array($item_platforms)) {
                $item_platforms = array();
            }
            if (!in_array($platform_id, $item_platforms)) {
                $item_platforms[] = $platform_id;
                update_post_meta($item_id, '_torofilm_platforms', $item_platforms);
            }
        }
        
        wp_send_json_success(array(
            'message' => 'Koleksiyon başarıyla oluşturuldu!',
            'collection_id' => $post_id,
            'collection_url' => get_permalink($post_id)
        ));
    } else {
        wp_send_json_error('Koleksiyon oluşturulurken hata oluştu!');
    }
}
add_action('wp_ajax_create_collection_from_platform', 'create_collection_from_platform');
add_action('wp_ajax_nopriv_create_collection_from_platform', 'create_collection_from_platform');

// AJAX: Platform içeriklerini al (Admin)
function get_platform_content() {
    if (!wp_verify_nonce($_POST['nonce'], 'get_platform_content')) {
        wp_die('Güvenlik hatası!');
    }
    
    if (!current_user_can('manage_options')) {
        wp_die('Yetkiniz yok!');
    }
    
    $platform_id = sanitize_text_field($_POST['platform_id']);
    $content_type = sanitize_text_field($_POST['content_type']);
    
    $args = array(
        'post_type' => $content_type,
        'posts_per_page' => -1,
        'post_status' => 'publish',
        'meta_query' => array(
            array(
                'key' => '_torofilm_platforms',
                'value' => $platform_id,
                'compare' => 'LIKE'
            )
        )
    );
    
    $posts = get_posts($args);
    $results = array();
    
    foreach ($posts as $post) {
        $poster_url = '';
        $poster_hotlink = get_post_meta($post->ID, 'poster_hotlink', true);
        $poster_field = get_post_meta($post->ID, 'field_poster', true);
        
        if ($poster_field) {
            $poster_url = wp_get_attachment_image_src($poster_field, 'thumbnail')[0];
        } elseif ($poster_hotlink) {
            if (filter_var($poster_hotlink, FILTER_VALIDATE_URL) === FALSE) {
                $poster_url = '//image.tmdb.org/t/p/w185' . $poster_hotlink;
            } else {
                $poster_url = $poster_hotlink;
            }
        } else {
            $poster_url = TOROFILM_DIR_URI . 'public/img/cnt/dvr300.png';
        }
        
        $results[] = array(
            'id' => $post->ID,
            'title' => $post->post_title,
            'year' => get_post_meta($post->ID, 'field_release_year', true) ?: get_post_meta($post->ID, 'field_date', true) ?: 'N/A',
            'rating' => get_post_meta($post->ID, 'rating', true) ?: 'N/A',
            'poster' => $poster_url
        );
    }
    
    wp_send_json_success($results);
}
add_action('wp_ajax_get_platform_content', 'get_platform_content');

// AJAX: Admin panelinden platforma içerik ekle
function add_content_to_platform_admin() {
    if (!wp_verify_nonce($_POST['nonce'], 'add_content_admin')) {
        wp_die('Güvenlik hatası!');
    }
    
    if (!current_user_can('manage_options')) {
        wp_die('Yetkiniz yok!');
    }
    
    $platform_id = sanitize_text_field($_POST['platform_id']);
    $content_type = sanitize_text_field($_POST['content_type']);
    $content_title = sanitize_text_field($_POST['content_title']);
    $content_year = sanitize_text_field($_POST['content_year']);
    $content_description = sanitize_textarea_field($_POST['content_description']);
    $content_poster = esc_url_raw($_POST['content_poster']);
    $content_rating = floatval($_POST['content_rating']);
    $content_genres = sanitize_text_field($_POST['content_genres']);
    
    // Başlık kontrolü
    if (empty($content_title)) {
        wp_send_json_error('Başlık gereklidir!');
        return;
    }
    
    // İçerik türü kontrolü
    if (!in_array($content_type, ['movies', 'series'])) {
        wp_send_json_error('Geçersiz içerik türü!');
        return;
    }
    
    // Aynı başlıkta içerik var mı kontrol et
    $existing_post = get_page_by_title($content_title, OBJECT, $content_type);
    if ($existing_post) {
        wp_send_json_error('Bu başlıkta bir içerik zaten mevcut!');
        return;
    }
    
    // Post oluştur
    $post_data = array(
        'post_title' => $content_title,
        'post_content' => $content_description,
        'post_status' => 'publish',
        'post_type' => $content_type,
        'post_author' => get_current_user_id()
    );
    
    $post_id = wp_insert_post($post_data);
    
    if ($post_id && !is_wp_error($post_id)) {
        // Meta verilerini kaydet
        if (!empty($content_year)) {
            update_post_meta($post_id, 'field_release_year', $content_year);
        }
        
        if (!empty($content_poster)) {
            update_post_meta($post_id, 'poster_hotlink', $content_poster);
        }
        
        if (!empty($content_rating)) {
            update_post_meta($post_id, 'rating', $content_rating);
        }
        
        // Platform bilgisini kaydet
        update_post_meta($post_id, '_torofilm_platforms', array($platform_id));
        
        // Türleri kaydet
        if (!empty($content_genres)) {
            $genres = array_map('trim', explode(',', $content_genres));
            foreach ($genres as $genre) {
                if (!empty($genre)) {
                    $term = wp_insert_term($genre, 'category');
                    if (!is_wp_error($term)) {
                        wp_set_post_terms($post_id, array($term['term_id']), 'category', true);
                    }
                }
            }
        }
        
        // Varsayılan meta veriler
        update_post_meta($post_id, 'views', 0);
        
        wp_send_json_success('İçerik başarıyla eklendi!');
    } else {
        wp_send_json_error('İçerik eklenirken hata oluştu!');
    }
}
add_action('wp_ajax_add_content_to_platform_admin', 'add_content_to_platform_admin');

// AJAX: Platformdan içerik kaldır
function remove_content_from_platform() {
    if (!wp_verify_nonce($_POST['nonce'], 'remove_content_platform')) {
        wp_die('Güvenlik hatası!');
    }
    
    if (!current_user_can('manage_options')) {
        wp_die('Yetkiniz yok!');
    }
    
    $content_id = intval($_POST['content_id']);
    $platform_id = sanitize_text_field($_POST['platform_id']);
    
    $platforms = get_post_meta($content_id, '_torofilm_platforms', true);
    
    if (is_array($platforms)) {
        $platforms = array_filter($platforms, function($p) use ($platform_id) {
            return $p !== $platform_id;
        });
        
        if (empty($platforms)) {
            delete_post_meta($content_id, '_torofilm_platforms');
        } else {
            update_post_meta($content_id, '_torofilm_platforms', $platforms);
        }
        
        wp_send_json_success('İçerik platformdan kaldırıldı!');
    } else {
        wp_send_json_error('İçerik bulunamadı!');
    }
}
add_action('wp_ajax_remove_content_from_platform', 'remove_content_from_platform');

// AJAX: Mevcut içerikleri ara
function search_existing_content() {
    if (!wp_verify_nonce($_POST['nonce'], 'search_existing_content')) {
        wp_die('Güvenlik hatası!');
    }
    
    if (!current_user_can('manage_options')) {
        wp_die('Yetkiniz yok!');
    }
    
    $content_type = sanitize_text_field($_POST['content_type']);
    $search_query = sanitize_text_field($_POST['search_query']);
    
    $args = array(
        'post_type' => array('movies', 'series'),
        'posts_per_page' => 50,
        'post_status' => 'publish',
        'orderby' => 'title',
        'order' => 'ASC'
    );
    
    // İçerik türü filtresi
    if (!empty($content_type)) {
        $args['post_type'] = $content_type;
    }
    
    // Arama sorgusu
    if (!empty($search_query)) {
        $args['s'] = $search_query;
    }
    
    $posts = get_posts($args);
    $results = array();
    
    foreach ($posts as $post) {
        $poster_url = '';
        $poster_hotlink = get_post_meta($post->ID, 'poster_hotlink', true);
        $poster_field = get_post_meta($post->ID, 'field_poster', true);
        
        if ($poster_field) {
            $poster_url = wp_get_attachment_image_src($poster_field, 'thumbnail')[0];
        } elseif ($poster_hotlink) {
            if (filter_var($poster_hotlink, FILTER_VALIDATE_URL) === FALSE) {
                $poster_url = '//image.tmdb.org/t/p/w185' . $poster_hotlink;
            } else {
                $poster_url = $poster_hotlink;
            }
        } else {
            $poster_url = TOROFILM_DIR_URI . 'public/img/cnt/dvr300.png';
        }
        
        $results[] = array(
            'id' => $post->ID,
            'title' => $post->post_title,
            'type' => $post->post_type,
            'year' => get_post_meta($post->ID, 'field_release_year', true) ?: get_post_meta($post->ID, 'field_date', true) ?: 'N/A',
            'rating' => get_post_meta($post->ID, 'rating', true) ?: 'N/A',
            'poster' => $poster_url
        );
    }
    
    wp_send_json_success($results);
}
add_action('wp_ajax_search_existing_content', 'search_existing_content');

// AJAX: Mevcut içerikleri platforma ekle
function add_existing_content_to_platform() {
    if (!wp_verify_nonce($_POST['nonce'], 'add_existing_content')) {
        wp_die('Güvenlik hatası!');
    }
    
    if (!current_user_can('manage_options')) {
        wp_die('Yetkiniz yok!');
    }
    
    $platform_id = sanitize_text_field($_POST['platform_id']);
    $content_ids = sanitize_text_field($_POST['content_ids']);
    
    if (empty($content_ids)) {
        wp_send_json_error('İçerik seçilmedi!');
        return;
    }
    
    $ids = array_filter(explode(',', $content_ids));
    $added_count = 0;
    $errors = array();
    
    foreach ($ids as $content_id) {
        $content_id = intval($content_id);
        $post = get_post($content_id);
        
        if (!$post || !in_array($post->post_type, array('movies', 'series'))) {
            $errors[] = 'Geçersiz içerik ID: ' . $content_id;
            continue;
        }
        
        $platforms = get_post_meta($content_id, '_torofilm_platforms', true);
        
        if (!is_array($platforms)) {
            $platforms = array();
        }
        
        if (!in_array($platform_id, $platforms)) {
            $platforms[] = $platform_id;
            update_post_meta($content_id, '_torofilm_platforms', $platforms);
            $added_count++;
        }
    }
    
    if ($added_count > 0) {
        $message = $added_count . ' içerik platforma eklendi!';
        if (!empty($errors)) {
            $message .= ' Hatalar: ' . implode(', ', $errors);
        }
        wp_send_json_success($message);
    } else {
        wp_send_json_error('Hiçbir içerik eklenemedi! ' . implode(', ', $errors));
    }
}
add_action('wp_ajax_add_existing_content_to_platform', 'add_existing_content_to_platform');

// Debug: Platform URL'lerini test et
function debug_platform_urls() {
    if (current_user_can('manage_options') && isset($_GET['debug_platforms'])) {
        $platforms = get_option('torofilm_platforms', array());
        echo '<h3>Platform Debug Bilgileri:</h3>';
        echo '<pre>';
        echo 'Platforms: ' . print_r($platforms, true);
        echo 'Query Vars: ' . print_r(get_query_vars(), true);
        echo 'Current URL: ' . home_url($_SERVER['REQUEST_URI']);
        echo '</pre>';
    }
}
add_action('wp_head', 'debug_platform_urls');
