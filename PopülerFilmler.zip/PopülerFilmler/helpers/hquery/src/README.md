# PSR-4 Autoloading

The files in this folder are intended for projects supporting PSR-4 (PHP >= 5.3.0).

The module `../hquery.php` creates namespaced aliases for hQuery classes on first invocation.
