<?php
/**
 * Koleksiyonlar arşiv sayfası template
 */

get_header(); ?>

<div class="TPost">
    <div class="Container">
        <div class="TPMvCn">
            <div class="Top">
                <h1><?php _e('Koleksiyonlar', 'torofilm'); ?></h1>
                <div class="Search">
                    <form role="search" method="get" action="<?php echo home_url('/'); ?>">
                        <input type="search" placeholder="<?php _e('Koleksiyon ara...', 'torofilm'); ?>" value="<?php echo get_search_query(); ?>" name="s" />
                        <input type="hidden" name="post_type" value="collections" />
                        <button type="submit">
                            <i class="fa fa-search"></i>
                        </button>
                    </form>
                </div>
            </div>
            
            <?php
            // Öne çıkan koleksiyonları göster
            $featured_collections = TOROFILM_Collections::get_featured_collections(3);
            
            if (!empty($featured_collections)) :
            ?>
            <div class="FeaturedCollections">
                <h2><?php _e('Öne Çıkan Koleksiyonlar', 'torofilm'); ?></h2>
                <div class="MoviesList">
                    <div class="MovieList Rows A03 B02 C02 D01 E01">
                        <?php foreach ($featured_collections as $collection) : ?>
                        <article class="TPost C">
                            <div class="Image">
                                <figure class="Objf TpMvPlay AAIco-play_arrow">
                                    <a href="<?php echo get_permalink($collection->ID); ?>">
                                        <?php if (has_post_thumbnail($collection->ID)) : ?>
                                            <?php echo get_the_post_thumbnail($collection->ID, 'thumbnail'); ?>
                                        <?php else : ?>
                                            <img src="<?php echo TOROFILM_DIR_URI . 'public/img/cnt/dvr300.png'; ?>" alt="<?php echo get_the_title($collection->ID); ?>" />
                                        <?php endif; ?>
                                    </a>
                                </figure>
                                
                                <div class="Title">
                                    <h3 class="Title">
                                        <a href="<?php echo get_permalink($collection->ID); ?>">
                                            <?php echo get_the_title($collection->ID); ?>
                                        </a>
                                    </h3>
                                </div>
                                
                                <div class="Info">
                                    <span class="Items">
                                        <i class="fa fa-film"></i>
                                        <?php 
                                        $items = get_post_meta($collection->ID, '_collection_items', true);
                                        $count = is_array($items) ? count($items) : 0;
                                        echo $count . ' ' . ($count == 1 ? __('İçerik', 'torofilm') : __('İçerik', 'torofilm'));
                                        ?>
                                    </span>
                                    
                                    <span class="Date">
                                        <i class="fa fa-calendar"></i>
                                        <?php echo get_the_date('d.m.Y', $collection->ID); ?>
                                    </span>
                                </div>
                                
                                <div class="Description">
                                    <p><?php echo wp_trim_words(get_the_excerpt($collection->ID), 15); ?></p>
                                </div>
                            </div>
                        </article>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            
            <div class="AllCollections">
                <h2><?php _e('Tüm Koleksiyonlar', 'torofilm'); ?></h2>
                
                <?php if (have_posts()) : ?>
                <div class="MoviesList">
                    <div class="MovieList Rows A04 B03 C02 D02 E01">
                        <?php while (have_posts()) : the_post(); ?>
                        <article class="TPost C">
                            <div class="Image">
                                <figure class="Objf TpMvPlay AAIco-play_arrow">
                                    <a href="<?php the_permalink(); ?>">
                                        <?php if (has_post_thumbnail()) : ?>
                                            <?php the_post_thumbnail('thumbnail'); ?>
                                        <?php else : ?>
                                            <img src="<?php echo TOROFILM_DIR_URI . 'public/img/cnt/dvr300.png'; ?>" alt="<?php the_title(); ?>" />
                                        <?php endif; ?>
                                    </a>
                                </figure>
                                
                                <div class="Title">
                                    <h3 class="Title">
                                        <a href="<?php the_permalink(); ?>">
                                            <?php the_title(); ?>
                                        </a>
                                    </h3>
                                </div>
                                
                                <div class="Info">
                                    <span class="Items">
                                        <i class="fa fa-film"></i>
                                        <?php 
                                        $items = get_post_meta(get_the_ID(), '_collection_items', true);
                                        $count = is_array($items) ? count($items) : 0;
                                        echo $count . ' ' . ($count == 1 ? __('İçerik', 'torofilm') : __('İçerik', 'torofilm'));
                                        ?>
                                    </span>
                                    
                                    <span class="Date">
                                        <i class="fa fa-calendar"></i>
                                        <?php echo get_the_date('d.m.Y'); ?>
                                    </span>
                                    
                                    <?php 
                                    $collection_type = get_post_meta(get_the_ID(), '_collection_type', true);
                                    if ($collection_type && $collection_type != 'mixed') :
                                    ?>
                                    <span class="Type">
                                        <i class="fa fa-tag"></i>
                                        <?php 
                                        echo $collection_type == 'movies' ? __('Filmler', 'torofilm') : __('Diziler', 'torofilm');
                                        ?>
                                    </span>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="Description">
                                    <p><?php echo wp_trim_words(get_the_excerpt(), 15); ?></p>
                                </div>
                            </div>
                        </article>
                        <?php endwhile; ?>
                    </div>
                </div>
                
                <div class="Pagination">
                    <?php
                    the_posts_pagination(array(
                        'prev_text' => __('Önceki', 'torofilm'),
                        'next_text' => __('Sonraki', 'torofilm'),
                    ));
                    ?>
                </div>
                
                <?php else : ?>
                <div class="NoCollections">
                    <p><?php _e('Henüz koleksiyon bulunmuyor.', 'torofilm'); ?></p>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<style>
.FeaturedCollections {
    margin-bottom: 40px;
}

.FeaturedCollections h2,
.AllCollections h2 {
    color: #fff;
    font-size: 24px;
    margin-bottom: 20px;
    padding-bottom: 10px;
    border-bottom: 2px solid #e50914;
}

.Search {
    margin-bottom: 30px;
}

.Search form {
    display: flex;
    max-width: 400px;
    margin: 0 auto;
}

.Search input[type="search"] {
    flex: 1;
    padding: 12px 15px;
    border: 1px solid #333;
    background: #222;
    color: #fff;
    border-radius: 25px 0 0 25px;
    outline: none;
}

.Search input[type="search"]:focus {
    border-color: #e50914;
}

.Search button {
    padding: 12px 20px;
    background: #e50914;
    color: #fff;
    border: none;
    border-radius: 0 25px 25px 0;
    cursor: pointer;
    transition: background 0.3s ease;
}

.Search button:hover {
    background: #b20710;
}

.Items,
.Date,
.Type {
    display: flex;
    align-items: center;
    gap: 5px;
    font-size: 12px;
    color: #999;
}

.Items i,
.Date i,
.Type i {
    font-size: 10px;
}

.NoCollections {
    text-align: center;
    padding: 60px 20px;
    color: #999;
    font-style: italic;
}

.Pagination {
    margin-top: 40px;
    text-align: center;
}

.Pagination .page-numbers {
    display: inline-block;
    padding: 10px 15px;
    margin: 0 5px;
    background: #333;
    color: #fff;
    text-decoration: none;
    border-radius: 4px;
    transition: background 0.3s ease;
}

.Pagination .page-numbers:hover,
.Pagination .page-numbers.current {
    background: #e50914;
}

.Pagination .page-numbers.prev,
.Pagination .page-numbers.next {
    background: #555;
}

.Pagination .page-numbers.prev:hover,
.Pagination .page-numbers.next:hover {
    background: #e50914;
}
</style>

<?php get_footer(); ?>
